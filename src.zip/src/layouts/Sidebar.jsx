import { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  BarChart3,
  FolderTree,
  FileText,
  Settings,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  X,
} from "lucide-react";

export const Sidebar = ({ sidebarOpen, setSidebarOpen }) => {
  const location = useLocation();

  const [collapsed, setCollapsed] = useState(false);
  const [openMenu, setOpenMenu] = useState("management");
  const [collapsedMenu, setCollapsedMenu] = useState(null);

  /*
   * Management routes
   */
  const isManagementActive =
    location.pathname.startsWith("/admin/users") ||
    location.pathname.startsWith("/admin/all/products") ||
    location.pathname.startsWith("/admin/orders");
  location.pathname.startsWith("/admin/categories");
  /*
   * Analytics routes
   */
  const isAnalyticsActive =
    location.pathname.startsWith("/admin/sales") ||
    location.pathname.startsWith("/admin/reports");

  /*
   * Automatically open the correct submenu
   */
  useEffect(() => {
    if (isManagementActive) {
      setOpenMenu("management");
    } else if (isAnalyticsActive) {
      setOpenMenu("analytics");
    }
  }, [location.pathname, isManagementActive, isAnalyticsActive]);

  /*
   * Toggle submenu
   */
  const toggleMenu = (menu) => {
    setOpenMenu((prev) => (prev === menu ? null : menu));
    setCollapsedMenu(null);
  };

  /*
   * Toggle desktop sidebar
   */
  const toggleSidebar = () => {
    setCollapsed((prev) => !prev);
    setCollapsedMenu(null);
  };

  /*
   * Close mobile sidebar
   */
  const closeMobileSidebar = () => {
    setSidebarOpen(false);
  };

  /*
   * Main navigation styles
   */
  const navLinkClass = ({ isActive }) =>
    `group flex w-full items-center rounded-lg text-sm font-medium transition-all duration-200 ${
      collapsed ? "justify-center px-3 py-3" : "gap-3 px-4 py-3"
    } ${
      isActive
        ? "bg-black text-white shadow-sm dark:bg-white dark:text-black"
        : "text-gray-600 hover:bg-gray-100 hover:text-black dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"
    }`;

  /*
   * Submenu styles
   */
  const submenuClass = ({ isActive }) =>
    `group flex w-full items-center gap-3 rounded-lg px-4 py-2.5 text-sm transition-all duration-200 ${
      isActive
        ? "bg-gray-200 font-medium text-black dark:bg-gray-800 dark:text-white"
        : "text-gray-500 hover:bg-gray-100 hover:text-black dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
    }`;

  /*
   * Parent menu styles
   */
  const parentMenuClass = (isActive) =>
    `flex w-full items-center rounded-lg text-xs font-semibold uppercase tracking-wider transition-all duration-200 ${
      collapsed ? "justify-center px-3 py-3" : "justify-between px-4 py-2.5"
    } ${
      isActive
        ? "bg-gray-200 text-black dark:bg-gray-800 dark:text-white"
        : "text-gray-400 hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-800 dark:hover:text-gray-200"
    }`;

  /*
   * Management submenu
   */
  const managementSubmenu = (
    <div className="mt-2 space-y-1 pl-2">
      <NavLink
        to="/admin/users"
        onClick={closeMobileSidebar}
        className={submenuClass}>
        <Users size={17} />
        <span>Users</span>
      </NavLink>
      <NavLink
        to="/admin/categories"
        onClick={closeMobileSidebar}
        className={submenuClass}>
        <FolderTree size={17} />
        <span>Categories</span>
      </NavLink>
      <NavLink
        to="/admin/all/products"
        onClick={closeMobileSidebar}
        className={submenuClass}>
        <Package size={17} />
        <span>Products</span>
      </NavLink>

      <NavLink
        to="/admin/orders"
        onClick={closeMobileSidebar}
        className={submenuClass}>
        <ShoppingCart size={17} />
        <span>Orders</span>
      </NavLink>
    </div>
  );

  /*
   * Analytics submenu
   */
  const analyticsSubmenu = (
    <div className="mt-2 space-y-1 pl-2">
      <NavLink
        to="/admin/sales"
        onClick={closeMobileSidebar}
        className={submenuClass}>
        <BarChart3 size={17} />
        <span>Sales</span>
      </NavLink>

      <NavLink
        to="/admin/reports"
        onClick={closeMobileSidebar}
        className={submenuClass}>
        <FileText size={17} />
        <span>Reports</span>
      </NavLink>
    </div>
  );

  /*
   * Collapsed Management flyout
   */
  const collapsedManagementSubmenu = (
    <div className="absolute left-full top-0 z-50 ml-3 w-52 rounded-xl border border-gray-200 bg-white p-2 shadow-xl dark:border-gray-700 dark:bg-gray-900">
      <p className="px-3 py-2 text-xs font-semibold uppercase tracking-wider text-gray-400">
        Management
      </p>

      <NavLink
        to="/admin/users"
        onClick={() => {
          setCollapsedMenu(null);
          closeMobileSidebar();
        }}
        className={submenuClass}>
        <Users size={17} />
        <span>Users</span>
      </NavLink>
      <NavLink
        to="/admin/categories"
        onClick={() => {
          setCollapsedMenu(null);
          closeMobileSidebar();
        }}
        className={submenuClass}>
        <FolderTree size={17} />
        <span>Categories</span>
      </NavLink>
      <NavLink
        to="/admin/all/products"
        onClick={() => {
          setCollapsedMenu(null);
          closeMobileSidebar();
        }}
        className={submenuClass}>
        <Package size={17} />
        <span>Products</span>
      </NavLink>

      <NavLink
        to="/admin/orders"
        onClick={() => {
          setCollapsedMenu(null);
          closeMobileSidebar();
        }}
        className={submenuClass}>
        <ShoppingCart size={17} />
        <span>Orders</span>
      </NavLink>
    </div>
  );

  /*
   * Collapsed Analytics flyout
   */
  const collapsedAnalyticsSubmenu = (
    <div className="absolute left-full top-0 z-50 ml-3 w-52 rounded-xl border border-gray-200 bg-white p-2 shadow-xl dark:border-gray-700 dark:bg-gray-900">
      <p className="px-3 py-2 text-xs font-semibold uppercase tracking-wider text-gray-400">
        Analytics
      </p>

      <NavLink
        to="/admin/sales"
        onClick={() => {
          setCollapsedMenu(null);
          closeMobileSidebar();
        }}
        className={submenuClass}>
        <BarChart3 size={17} />
        <span>Sales</span>
      </NavLink>

      <NavLink
        to="/admin/reports"
        onClick={() => {
          setCollapsedMenu(null);
          closeMobileSidebar();
        }}
        className={submenuClass}>
        <FileText size={17} />
        <span>Reports</span>
      </NavLink>
    </div>
  );

  return (
    <>
      {/* ================================================= */}
      {/* DESKTOP SIDEBAR */}
      {/* ================================================= */}

      <aside
        className={`relative hidden min-h-screen flex-shrink-0 border-r border-gray-200 bg-white transition-all duration-300 dark:border-gray-800 dark:bg-gray-950 md:block ${
          collapsed ? "w-20" : "w-64"
        }`}>
        {/* Header */}
        <div
          className={`flex h-20 items-center border-b border-gray-200 px-4 dark:border-gray-800 ${
            collapsed ? "justify-center" : "justify-between"
          }`}>
          {collapsed ? (
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-black text-sm font-bold text-white dark:bg-white dark:text-black">
              N
            </div>
          ) : (
            <div>
              <h2 className="text-xl font-bold tracking-tight text-gray-900 dark:text-white">
                NOVA
              </h2>

              <p className="mt-0.5 text-[10px] font-medium uppercase tracking-widest text-gray-400">
                Admin Panel
              </p>
            </div>
          )}

          {/* Collapse button */}
          <button
            type="button"
            onClick={toggleSidebar}
            className="absolute -right-3 top-7 z-20 flex h-7 w-7 items-center justify-center rounded-full border border-gray-200 bg-white text-gray-600 shadow-sm transition-all duration-200 hover:bg-gray-100 hover:text-black hover:shadow-md dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>
            {collapsed ? <ChevronRight size={15} /> : <ChevronLeft size={15} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="px-3 py-6">
          {/* Main */}
          {!collapsed && (
            <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
              Main
            </p>
          )}

          {/* Dashboard */}
          <NavLink
            to="/admin"
            end
            onClick={() => setCollapsedMenu(null)}
            className={navLinkClass}
            title={collapsed ? "Dashboard" : undefined}>
            <LayoutDashboard size={19} />

            {!collapsed && <span>Dashboard</span>}
          </NavLink>

          {/* Management */}
          <div className="relative mt-6">
            {!collapsed && (
              <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
                Management
              </p>
            )}

            {collapsed ? (
              <>
                <button
                  type="button"
                  onClick={() =>
                    setCollapsedMenu((prev) =>
                      prev === "management" ? null : "management",
                    )
                  }
                  className={parentMenuClass(isManagementActive)}
                  title="Management"
                  aria-label="Management">
                  <Users size={19} />
                </button>

                {collapsedMenu === "management" && collapsedManagementSubmenu}
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => toggleMenu("management")}
                  className={parentMenuClass(isManagementActive)}>
                  <span>Management</span>

                  <ChevronDown
                    size={15}
                    className={`transition-transform duration-200 ${
                      openMenu === "management" ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {openMenu === "management" && managementSubmenu}
              </>
            )}
          </div>

          {/* Analytics */}
          <div className="relative mt-6">
            {!collapsed && (
              <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
                Analytics
              </p>
            )}

            {collapsed ? (
              <>
                <button
                  type="button"
                  onClick={() =>
                    setCollapsedMenu((prev) =>
                      prev === "analytics" ? null : "analytics",
                    )
                  }
                  className={parentMenuClass(isAnalyticsActive)}
                  title="Analytics"
                  aria-label="Analytics">
                  <BarChart3 size={19} />
                </button>

                {collapsedMenu === "analytics" && collapsedAnalyticsSubmenu}
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => toggleMenu("analytics")}
                  className={parentMenuClass(isAnalyticsActive)}>
                  <span>Analytics</span>

                  <ChevronDown
                    size={15}
                    className={`transition-transform duration-200 ${
                      openMenu === "analytics" ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {openMenu === "analytics" && analyticsSubmenu}
              </>
            )}
          </div>

          {/* System */}
          <div className="mt-6">
            {!collapsed && (
              <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
                System
              </p>
            )}

            <NavLink
              to="/admin/settings"
              end
              onClick={() => setCollapsedMenu(null)}
              className={navLinkClass}
              title={collapsed ? "Settings" : undefined}>
              <Settings size={19} />

              {!collapsed && <span>Settings</span>}
            </NavLink>
          </div>
        </nav>

        {/* Desktop Footer */}
        {!collapsed && (
          <div className="absolute bottom-5 left-4 right-4 rounded-lg border border-gray-200 bg-gray-50 px-4 py-3 dark:border-gray-800 dark:bg-gray-900">
            <p className="text-xs font-medium text-gray-700 dark:text-gray-300">
              NOVA Admin
            </p>

            <p className="mt-0.5 text-[11px] text-gray-400">Version 1.0.0</p>
          </div>
        )}
      </aside>

      {/* ================================================= */}
      {/* MOBILE SIDEBAR */}
      {/* ================================================= */}

      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          {/* Overlay */}
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-[2px]"
            onClick={closeMobileSidebar}
          />

          {/* Sidebar */}
          <aside className="relative flex h-full w-[min(18rem,calc(100vw-1rem))] flex-col overflow-y-auto bg-white shadow-2xl dark:bg-gray-950">
            {/* Mobile Header */}
            <div className="flex h-20 flex-shrink-0 items-center justify-between border-b border-gray-200 px-5 dark:border-gray-800">
              <div>
                <h2 className="text-xl font-bold tracking-tight text-gray-900 dark:text-white">
                  NOVA
                </h2>

                <p className="mt-0.5 text-[10px] font-medium uppercase tracking-widest text-gray-400">
                  Admin Panel
                </p>
              </div>

              <button
                type="button"
                onClick={closeMobileSidebar}
                className="rounded-lg p-2 text-gray-500 transition hover:bg-gray-100 hover:text-black dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
                aria-label="Close sidebar">
                <X size={21} />
              </button>
            </div>

            {/* Mobile Navigation */}
            <nav className="px-4 py-6">
              {/* Main */}
              <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
                Main
              </p>

              {/* Dashboard */}
              <NavLink
                to="/admin"
                end
                onClick={closeMobileSidebar}
                className={navLinkClass}>
                <LayoutDashboard size={19} />
                <span>Dashboard</span>
              </NavLink>

              {/* Management */}
              <div className="mt-6">
                <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
                  Management
                </p>

                <button
                  type="button"
                  onClick={() => toggleMenu("management")}
                  className={parentMenuClass(isManagementActive)}>
                  <span>Management</span>

                  <ChevronDown
                    size={15}
                    className={`transition-transform duration-200 ${
                      openMenu === "management" ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {openMenu === "management" && managementSubmenu}
              </div>

              {/* Analytics */}
              <div className="mt-6">
                <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
                  Analytics
                </p>

                <button
                  type="button"
                  onClick={() => toggleMenu("analytics")}
                  className={parentMenuClass(isAnalyticsActive)}>
                  <span>Analytics</span>

                  <ChevronDown
                    size={15}
                    className={`transition-transform duration-200 ${
                      openMenu === "analytics" ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {openMenu === "analytics" && analyticsSubmenu}
              </div>

              {/* System */}
              <div className="mt-6">
                <p className="mb-2 px-4 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
                  System
                </p>

                <NavLink
                  to="/admin/settings"
                  end
                  onClick={closeMobileSidebar}
                  className={navLinkClass}>
                  <Settings size={19} />
                  <span>Settings</span>
                </NavLink>
              </div>
            </nav>

            {/* Mobile Footer */}
            <div className="mt-auto flex-shrink-0 border-t border-gray-200 p-4 dark:border-gray-800">
              <p className="text-xs font-medium text-gray-700 dark:text-gray-300">
                NOVA Admin
              </p>

              <p className="mt-0.5 text-[11px] text-gray-400">Version 1.0.0</p>
            </div>
          </aside>
        </div>
      )}
    </>
  );
};
