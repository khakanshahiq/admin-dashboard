import { useEffect, useRef, useState } from "react";
import {
  Bell,
  ChevronDown,
  Menu,
  Moon,
  Sun,
  User,
  Settings,
  LogOut,
  Check,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

import Hero from "../assets/hero.png";
import SearchBox from "../components/Search";
import { useTheme } from "../context/ThemeContext";
import { useNotifications } from "../context/NotificationContext";
import { useAuth } from "../context/AuthContext";
const Header = ({ setSidebarOpen }) => {
  const [profileOpen, setProfileOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const { logout } = useAuth();
  const profileRef = useRef(null);
  const notificationRef = useRef(null);

  const navigate = useNavigate();

  const { darkMode, toggleTheme } = useTheme();

  const { notifications, unreadCount, markAsRead, markAllAsRead } =
    useNotifications();

  // ==========================================
  // Close dropdowns when clicking outside
  // ==========================================

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setProfileOpen(false);
      }

      if (
        notificationRef.current &&
        !notificationRef.current.contains(event.target)
      ) {
        setNotificationOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // ==========================================
  // Profile Dropdown
  // ==========================================

  const toggleProfile = () => {
    setProfileOpen((prev) => !prev);
    setNotificationOpen(false);
  };

  // ==========================================
  // Notification Dropdown
  // ==========================================

  const toggleNotifications = () => {
    setNotificationOpen((prev) => !prev);
    setProfileOpen(false);
  };

  const handleNotificationClick = (id) => {
    markAsRead(id);
  };

  // ==========================================
  // Profile Actions
  // ==========================================

  const handleProfile = () => {
    setProfileOpen(false);
    navigate("/profile");
  };

  const handleSettings = () => {
    setProfileOpen(false);
    navigate("/settings");
  };

  const handleLogout = () => {
    setProfileOpen(false);
    logout();
    navigate("/login");
  };
  // ==========================================
  // JSX
  // ==========================================

  return (
    <header className="relative flex h-16 items-center justify-between border-b border-gray-200 bg-white px-3 dark:border-gray-800 dark:bg-gray-950 sm:px-6">
      {/* ==========================================
          LEFT SIDE
      ========================================== */}

      <div className="flex min-w-0 items-center gap-2 sm:gap-4">
        {/* Mobile Menu */}

        <button
          type="button"
          onClick={() => setSidebarOpen(true)}
          className="flex shrink-0 items-center justify-center rounded-lg p-2 text-gray-900 transition hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-800 md:hidden"
          aria-label="Open sidebar">
          <Menu size={21} />
        </button>

        {/* Page Title */}

        <h1 className="truncate text-base font-bold tracking-tight text-gray-900 dark:text-white sm:text-xl">
          Dashboard
        </h1>
      </div>

      {/* ==========================================
          RIGHT SIDE
      ========================================== */}

      <div className="flex shrink-0 items-center gap-1 sm:gap-2 md:gap-4">
        {/* ==========================================
            SEARCH
        ========================================== */}

        {/* Hide full search on small mobile screens */}

        <div className="hidden sm:block">
          <SearchBox />
        </div>

        {/* ==========================================
            NOTIFICATIONS
        ========================================== */}

        <div ref={notificationRef} className="relative">
          {/* Notification Button */}

          <button
            type="button"
            onClick={toggleNotifications}
            className="relative flex items-center justify-center rounded-lg p-2 text-gray-900 transition hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-800"
            aria-label="Notifications">
            <Bell size={20} />

            {/* Notification Badge */}

            {unreadCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-black px-1 text-[10px] font-semibold text-white dark:bg-white dark:text-black">
                {unreadCount}
              </span>
            )}
          </button>

          {/* ==========================================
              NOTIFICATION DROPDOWN
          ========================================== */}

          {notificationOpen && (
            <div className="absolute right-0 top-12 z-50 w-[340px] max-w-[calc(100vw-1.5rem)] overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl dark:border-gray-700 dark:bg-gray-900">
              {/* Dropdown Header */}

              <div className="flex items-center justify-between gap-3 border-b border-gray-200 px-4 py-4 dark:border-gray-700 sm:px-5">
                <div className="min-w-0">
                  <h2 className="font-semibold text-gray-900 dark:text-white">
                    Notifications
                  </h2>

                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    {unreadCount > 0
                      ? `${unreadCount} unread notification${
                          unreadCount > 1 ? "s" : ""
                        }`
                      : "You're all caught up"}
                  </p>
                </div>

                {/* Mark All Read */}

                {unreadCount > 0 && (
                  <button
                    type="button"
                    onClick={markAllAsRead}
                    className="shrink-0 text-xs font-medium text-gray-500 transition hover:text-black dark:text-gray-400 dark:hover:text-white">
                    Mark all read
                  </button>
                )}
              </div>

              {/* ==========================================
                  NOTIFICATION LIST
              ========================================== */}

              {notifications.length > 0 ? (
                <div className="max-h-[360px] overflow-y-auto">
                  {notifications.map((notification) => (
                    <button
                      key={notification.id}
                      type="button"
                      onClick={() => handleNotificationClick(notification.id)}
                      className={`flex w-full gap-3 border-b border-gray-100 px-4 py-4 text-left transition last:border-b-0 dark:border-gray-800 sm:px-5 ${
                        notification.read
                          ? "bg-white hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-800"
                          : "bg-gray-50 hover:bg-gray-100 dark:bg-gray-800/50 dark:hover:bg-gray-800"
                      }`}>
                      {/* Status Indicator */}

                      <div className="pt-1.5">
                        <span
                          className={`block h-2.5 w-2.5 rounded-full ${
                            notification.read
                              ? "bg-gray-300 dark:bg-gray-600"
                              : "bg-black dark:bg-white"
                          }`}
                        />
                      </div>

                      {/* Notification Content */}

                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <p
                            className={`text-sm ${
                              notification.read
                                ? "font-medium text-gray-700 dark:text-gray-300"
                                : "font-semibold text-gray-900 dark:text-white"
                            }`}>
                            {notification.title}
                          </p>

                          {/* New Label */}

                          {!notification.read && (
                            <span className="shrink-0 text-[10px] font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400">
                              New
                            </span>
                          )}
                        </div>

                        <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
                          {notification.message}
                        </p>

                        <p className="mt-1.5 text-[11px] text-gray-400 dark:text-gray-500">
                          {notification.time}
                        </p>
                      </div>

                      {/* Read Icon */}

                      {notification.read && (
                        <Check
                          size={15}
                          className="mt-1 shrink-0 text-gray-400"
                        />
                      )}
                    </button>
                  ))}
                </div>
              ) : (
                /* Empty State */

                <div className="px-5 py-10 text-center">
                  <Bell
                    size={28}
                    className="mx-auto text-gray-300 dark:text-gray-600"
                  />

                  <p className="mt-3 text-sm font-medium text-gray-900 dark:text-white">
                    No notifications
                  </p>

                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    You don't have any notifications right now.
                  </p>
                </div>
              )}

              {/* ==========================================
                  VIEW ALL
              ========================================== */}

              <div className="border-t border-gray-200 p-3 text-center dark:border-gray-700">
                <button
                  type="button"
                  onClick={() => {
                    setNotificationOpen(false);
                    navigate("/admin/notifications");
                  }}
                  className="text-sm font-medium text-gray-600 transition hover:text-black dark:text-gray-400 dark:hover:text-white">
                  View all notifications
                </button>
              </div>
            </div>
          )}
        </div>

        {/* ==========================================
            THEME TOGGLE
        ========================================== */}

        {/* IMPORTANT:
            No longer hidden on mobile.
            Users can now switch Light/Dark mode
            directly from mobile. */}

        <button
          type="button"
          onClick={toggleTheme}
          className="flex shrink-0 items-center justify-center rounded-lg p-2 text-gray-900 transition hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-800"
          aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
          title={darkMode ? "Light mode" : "Dark mode"}>
          {darkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>

        {/* ==========================================
            PROFILE
        ========================================== */}

        <div ref={profileRef} className="relative">
          {/* Profile Button */}

          <button
            type="button"
            onClick={toggleProfile}
            className="flex items-center gap-1 rounded-lg p-1.5 text-gray-900 transition hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-800 sm:gap-3"
            aria-label="Open profile menu">
            <img
              src={Hero}
              alt="Admin profile"
              className="h-8 w-8 rounded-full object-cover sm:h-9 sm:w-9"
            />

            {/* Desktop Profile Info */}

            <div className="hidden text-left sm:block">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Admin
              </h2>

              <p className="text-xs text-gray-500 dark:text-gray-400">
                Web Developer
              </p>
            </div>

            {/* Desktop Chevron */}

            <ChevronDown
              size={18}
              className={`hidden text-gray-500 transition-transform duration-200 dark:text-gray-400 sm:block ${
                profileOpen ? "rotate-180" : ""
              }`}
            />
          </button>

          {/* ==========================================
              PROFILE DROPDOWN
          ========================================== */}

          {profileOpen && (
            <div className="absolute right-0 top-12 z-50 w-56 overflow-hidden rounded-xl border border-gray-200 bg-white p-2 shadow-xl dark:border-gray-700 dark:bg-gray-900">
              {/* Profile Info */}

              <div className="border-b border-gray-100 px-3 py-3 dark:border-gray-800">
                <p className="text-sm font-semibold text-gray-900 dark:text-white">
                  Admin
                </p>

                <p className="mt-1 truncate text-xs text-gray-500 dark:text-gray-400">
                  admin@example.com
                </p>
              </div>

              {/* Menu */}

              <div className="py-2">
                {/* Profile */}

                <button
                  type="button"
                  onClick={handleProfile}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-gray-600 transition hover:bg-gray-100 hover:text-black dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white">
                  <User size={17} />
                  <span>My Profile</span>
                </button>

                {/* Settings */}

                <button
                  type="button"
                  onClick={handleSettings}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-gray-600 transition hover:bg-gray-100 hover:text-black dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white">
                  <Settings size={17} />
                  <span>Account Settings</span>
                </button>
              </div>

              {/* Logout */}

              <div className="border-t border-gray-100 pt-2 dark:border-gray-800">
                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-gray-600 transition hover:bg-gray-100 hover:text-black dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white">
                  <LogOut size={17} />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
