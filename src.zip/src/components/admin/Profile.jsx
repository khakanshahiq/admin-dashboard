import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Mail,
  Phone,
  ShieldCheck,
  CalendarDays,
  Edit,
  Camera,
  MapPin,
  User,
  BriefcaseBusiness,
  Save,
  X,
} from "lucide-react";
import Hero from "../../assets/hero.png";

const Profile = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [editing, setEditing] = useState(false);

  const [profile, setProfile] = useState({
    name: "Admin",
    email: "admin@example.com",
    phone: "+92 300 1234567",
    jobTitle: "Web Developer",
    location: "Faisalabad, Pakistan",
    bio: "Passionate web developer focused on building modern and user-friendly digital experiences.",
  });

  const [avatar, setAvatar] = useState(Hero);
  const [saved, setSaved] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setProfile((prev) => ({
      ...prev,
      [name]: value,
    }));

    setSaved(false);
  };

  const handleAvatarChange = (event) => {
    const file = event.target.files?.[0];

    if (!file) return;

    const preview = URL.createObjectURL(file);
    setAvatar(preview);
    setSaved(false);
  };

  const handleSave = (event) => {
    event.preventDefault();

    setEditing(false);
    setSaved(true);

    setTimeout(() => {
      setSaved(false);
    }, 3000);
  };

  const handleCancel = () => {
    setEditing(false);
    setSaved(false);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            My Profile
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Manage your personal information and account details.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate("/admin")}
          className="inline-flex w-fit items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
          <ArrowLeft size={17} />
          <span>Back to Dashboard</span>
        </button>
      </div>

      {/* Success Message */}
      {saved && (
        <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-medium text-green-700 dark:border-green-900/50 dark:bg-green-950/30 dark:text-green-400">
          Profile changes saved successfully.
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Profile Sidebar */}
        <div className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
          <div className="p-6">
            <div className="flex flex-col items-center text-center">
              {/* Avatar */}
              <div className="group relative">
                <img
                  src={avatar}
                  alt={`${profile.name} profile`}
                  className="h-28 w-28 rounded-full object-cover ring-4 ring-gray-100 dark:ring-gray-800"
                />

                {editing && (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 flex items-center justify-center rounded-full bg-black/55 text-white opacity-0 transition group-hover:opacity-100">
                    <Camera size={22} />
                  </button>
                )}

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleAvatarChange}
                  className="hidden"
                />
              </div>

              {editing && (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="mt-3 text-xs font-semibold text-gray-600 hover:text-gray-950 dark:text-gray-400 dark:hover:text-white">
                  Change photo
                </button>
              )}

              <h2 className="mt-4 text-xl font-bold text-gray-950 dark:text-white">
                {profile.name}
              </h2>

              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                {profile.jobTitle}
              </p>

              <span className="mt-4 inline-flex items-center gap-2 rounded-full bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-700 dark:bg-gray-800 dark:text-gray-300">
                <span className="h-2 w-2 rounded-full bg-green-500" />
                Active
              </span>
            </div>

            {/* Contact Information */}
            <div className="mt-7 border-t border-gray-100 pt-6 dark:border-gray-800">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                    <Mail
                      size={17}
                      className="text-gray-600 dark:text-gray-400"
                    />
                  </div>

                  <div className="min-w-0">
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Email
                    </p>

                    <p className="truncate text-sm font-medium text-gray-900 dark:text-white">
                      {profile.email}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                    <Phone
                      size={17}
                      className="text-gray-600 dark:text-gray-400"
                    />
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Phone
                    </p>

                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {profile.phone}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                    <MapPin
                      size={17}
                      className="text-gray-600 dark:text-gray-400"
                    />
                  </div>

                  <div className="min-w-0">
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Location
                    </p>

                    <p className="truncate text-sm font-medium text-gray-900 dark:text-white">
                      {profile.location}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="space-y-6 lg:col-span-2">
          {/* Personal Information */}
          <form
            onSubmit={handleSave}
            className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            {/* Section Header */}
            <div className="flex flex-col gap-4 border-b border-gray-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
              <div>
                <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                  Personal Information
                </h2>

                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Your basic personal and professional information.
                </p>
              </div>

              {!editing ? (
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="inline-flex w-fit items-center gap-2 rounded-lg bg-gray-950 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
                  <Edit size={16} />
                  Edit Profile
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="inline-flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
                    <X size={16} />
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 rounded-lg bg-gray-950 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
                    <Save size={16} />
                    Save
                  </button>
                </div>
              )}
            </div>

            {/* Fields */}
            <div className="grid grid-cols-1 gap-5 p-5 sm:grid-cols-2">
              {/* Full Name */}
              <div>
                <label
                  htmlFor="name"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Full Name
                </label>

                {editing ? (
                  <div className="relative">
                    <User
                      size={17}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />

                    <input
                      id="name"
                      name="name"
                      type="text"
                      value={profile.name}
                      onChange={handleChange}
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-3.5 text-sm text-gray-900 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                    />
                  </div>
                ) : (
                  <p className="rounded-lg bg-gray-50 px-3.5 py-3 text-sm font-medium text-gray-900 dark:bg-gray-950 dark:text-white">
                    {profile.name}
                  </p>
                )}
              </div>

              {/* Email */}
              <div>
                <label
                  htmlFor="email"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Email Address
                </label>

                {editing ? (
                  <div className="relative">
                    <Mail
                      size={17}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />

                    <input
                      id="email"
                      name="email"
                      type="email"
                      value={profile.email}
                      onChange={handleChange}
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-3.5 text-sm text-gray-900 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                    />
                  </div>
                ) : (
                  <p className="rounded-lg bg-gray-50 px-3.5 py-3 text-sm font-medium text-gray-900 dark:bg-gray-950 dark:text-white">
                    {profile.email}
                  </p>
                )}
              </div>

              {/* Phone */}
              <div>
                <label
                  htmlFor="phone"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Phone Number
                </label>

                {editing ? (
                  <div className="relative">
                    <Phone
                      size={17}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />

                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={profile.phone}
                      onChange={handleChange}
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-3.5 text-sm text-gray-900 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                    />
                  </div>
                ) : (
                  <p className="rounded-lg bg-gray-50 px-3.5 py-3 text-sm font-medium text-gray-900 dark:bg-gray-950 dark:text-white">
                    {profile.phone}
                  </p>
                )}
              </div>

              {/* Job Title */}
              <div>
                <label
                  htmlFor="jobTitle"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Job Title
                </label>

                {editing ? (
                  <div className="relative">
                    <BriefcaseBusiness
                      size={17}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />

                    <input
                      id="jobTitle"
                      name="jobTitle"
                      type="text"
                      value={profile.jobTitle}
                      onChange={handleChange}
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-3.5 text-sm text-gray-900 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                    />
                  </div>
                ) : (
                  <p className="rounded-lg bg-gray-50 px-3.5 py-3 text-sm font-medium text-gray-900 dark:bg-gray-950 dark:text-white">
                    {profile.jobTitle}
                  </p>
                )}
              </div>

              {/* Location */}
              <div className="sm:col-span-2">
                <label
                  htmlFor="location"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Location
                </label>

                {editing ? (
                  <div className="relative">
                    <MapPin
                      size={17}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />

                    <input
                      id="location"
                      name="location"
                      type="text"
                      value={profile.location}
                      onChange={handleChange}
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-3.5 text-sm text-gray-900 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                    />
                  </div>
                ) : (
                  <p className="rounded-lg bg-gray-50 px-3.5 py-3 text-sm font-medium text-gray-900 dark:bg-gray-950 dark:text-white">
                    {profile.location}
                  </p>
                )}
              </div>

              {/* Bio */}
              <div className="sm:col-span-2">
                <label
                  htmlFor="bio"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Bio
                </label>

                {editing ? (
                  <textarea
                    id="bio"
                    name="bio"
                    rows="4"
                    value={profile.bio}
                    onChange={handleChange}
                    className="w-full resize-none rounded-lg border border-gray-200 bg-white px-3.5 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                  />
                ) : (
                  <p className="rounded-lg bg-gray-50 px-3.5 py-3 text-sm leading-6 text-gray-700 dark:bg-gray-950 dark:text-gray-300">
                    {profile.bio}
                  </p>
                )}
              </div>
            </div>
          </form>

          {/* Account Details */}
          <div className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                Account Details
              </h2>

              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Information about your NOVA account.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-5 p-5 sm:grid-cols-3">
              {/* Role */}
              <div className="flex items-center gap-3 rounded-lg bg-gray-50 p-4 dark:bg-gray-950">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white dark:bg-gray-900">
                  <ShieldCheck
                    size={19}
                    className="text-gray-600 dark:text-gray-400"
                  />
                </div>

                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Role
                  </p>

                  <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                    Administrator
                  </p>
                </div>
              </div>

              {/* Status */}
              <div className="flex items-center gap-3 rounded-lg bg-gray-50 p-4 dark:bg-gray-950">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white dark:bg-gray-900">
                  <span className="h-3 w-3 rounded-full bg-green-500" />
                </div>

                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Status
                  </p>

                  <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                    Active
                  </p>
                </div>
              </div>

              {/* Joined */}
              <div className="flex items-center gap-3 rounded-lg bg-gray-50 p-4 dark:bg-gray-950">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white dark:bg-gray-900">
                  <CalendarDays
                    size={19}
                    className="text-gray-600 dark:text-gray-400"
                  />
                </div>

                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Joined
                  </p>

                  <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                    January 2026
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Profile Tip */}
          <div className="rounded-xl border border-gray-200 bg-gray-50 p-5 dark:border-gray-800 dark:bg-gray-900/50">
            <div className="flex gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white text-gray-600 dark:bg-gray-800 dark:text-gray-400">
                <User size={17} />
              </div>

              <div>
                <p className="text-sm font-semibold text-gray-900 dark:text-white">
                  Keep your profile up to date
                </p>

                <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
                  A complete profile helps your team identify you quickly and
                  keeps your account information organized.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
