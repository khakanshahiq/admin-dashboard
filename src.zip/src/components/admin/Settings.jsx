import { useState } from "react";
import {
  Moon,
  Sun,
  Bell,
  Mail,
  ShoppingCart,
  Megaphone,
  Lock,
  Globe,
  Clock3,
  Save,
  X,
  Eye,
  EyeOff,
} from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

const Settings = () => {
  const { darkMode, toggleTheme } = useTheme();

  const [notifications, setNotifications] = useState({
    email: true,
    orders: true,
    marketing: false,
  });

  const [preferences, setPreferences] = useState({
    language: "English",
    timezone: "UTC +05:00",
  });

  const [saved, setSaved] = useState(false);
  const [passwordModal, setPasswordModal] = useState(false);

  const [passwordData, setPasswordData] = useState({
    current: "",
    newPassword: "",
    confirm: "",
  });

  const [showPasswords, setShowPasswords] = useState({
    current: false,
    newPassword: false,
    confirm: false,
  });

  const handleNotificationToggle = (key) => {
    setNotifications((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));

    setSaved(false);
  };

  const handlePreferenceChange = (event) => {
    const { name, value } = event.target;

    setPreferences((prev) => ({
      ...prev,
      [name]: value,
    }));

    setSaved(false);
  };

  const handleSave = () => {
    setSaved(true);

    setTimeout(() => {
      setSaved(false);
    }, 3000);
  };

  const handlePasswordChange = (event) => {
    const { name, value } = event.target;

    setPasswordData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const togglePasswordVisibility = (field) => {
    setShowPasswords((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  const handlePasswordSubmit = (event) => {
    event.preventDefault();

    setPasswordModal(false);

    setPasswordData({
      current: "",
      newPassword: "",
      confirm: "",
    });

    setSaved(true);

    setTimeout(() => {
      setSaved(false);
    }, 3000);
  };

  return (
    <>
      <div className="space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            Settings
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Manage your preferences and account settings.
          </p>
        </div>

        {/* Success Message */}
        {saved && (
          <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-medium text-green-700 dark:border-green-900/50 dark:bg-green-950/30 dark:text-green-400">
            Your settings have been saved successfully.
          </div>
        )}

        <div className="space-y-6">
          {/* ========================= */}
          {/* Appearance */}
          {/* ========================= */}

          <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                Appearance
              </h2>

              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Customize how the dashboard looks and feels.
              </p>
            </div>

            <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                  {darkMode ? (
                    <Moon
                      size={19}
                      className="text-gray-600 dark:text-gray-300"
                    />
                  ) : (
                    <Sun
                      size={19}
                      className="text-gray-600 dark:text-gray-300"
                    />
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-gray-950 dark:text-white">
                    Dark Mode
                  </h3>

                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    {darkMode
                      ? "Dark mode is currently enabled."
                      : "Light mode is currently enabled."}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={toggleTheme}
                className={`relative h-6 w-11 shrink-0 rounded-full transition ${
                  darkMode
                    ? "bg-gray-950 dark:bg-white"
                    : "bg-gray-300 dark:bg-gray-700"
                }`}
                aria-label="Toggle dark mode">
                <span
                  className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
                    darkMode
                      ? "translate-x-6 dark:bg-gray-950"
                      : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          </section>

          {/* ========================= */}
          {/* Notifications */}
          {/* ========================= */}

          <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                  <Bell
                    size={19}
                    className="text-gray-600 dark:text-gray-400"
                  />
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                    Notifications
                  </h2>

                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Choose which notifications you want to receive.
                  </p>
                </div>
              </div>
            </div>

            <div className="divide-y divide-gray-100 dark:divide-gray-800">
              <NotificationRow
                icon={<Mail size={18} />}
                title="Email Notifications"
                description="Receive important updates by email."
                enabled={notifications.email}
                onToggle={() => handleNotificationToggle("email")}
              />

              <NotificationRow
                icon={<ShoppingCart size={18} />}
                title="Order Notifications"
                description="Get notified when a new order is received."
                enabled={notifications.orders}
                onToggle={() => handleNotificationToggle("orders")}
              />

              <NotificationRow
                icon={<Megaphone size={18} />}
                title="Marketing Notifications"
                description="Receive promotional and marketing updates."
                enabled={notifications.marketing}
                onToggle={() => handleNotificationToggle("marketing")}
              />
            </div>
          </section>

          {/* ========================= */}
          {/* Regional Preferences */}
          {/* ========================= */}

          <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                Regional Preferences
              </h2>

              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Configure your language and timezone preferences.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-5 p-5 sm:grid-cols-2">
              {/* Language */}
              <div>
                <label
                  htmlFor="language"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Language
                </label>

                <div className="relative">
                  <Globe
                    size={17}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  />

                  <select
                    id="language"
                    name="language"
                    value={preferences.language}
                    onChange={handlePreferenceChange}
                    className="h-11 w-full appearance-none rounded-lg border border-gray-200 bg-white pl-10 pr-4 text-sm text-gray-700 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 dark:focus:border-gray-300">
                    <option>English</option>
                    <option>Urdu</option>
                    <option>Arabic</option>
                    <option>Spanish</option>
                    <option>French</option>
                  </select>
                </div>
              </div>

              {/* Timezone */}
              <div>
                <label
                  htmlFor="timezone"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Timezone
                </label>

                <div className="relative">
                  <Clock3
                    size={17}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  />

                  <select
                    id="timezone"
                    name="timezone"
                    value={preferences.timezone}
                    onChange={handlePreferenceChange}
                    className="h-11 w-full appearance-none rounded-lg border border-gray-200 bg-white pl-10 pr-4 text-sm text-gray-700 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 dark:focus:border-gray-300">
                    <option>UTC +05:00</option>
                    <option>UTC +00:00</option>
                    <option>UTC +01:00</option>
                    <option>UTC +03:00</option>
                    <option>UTC +04:00</option>
                    <option>UTC -05:00</option>
                    <option>UTC -08:00</option>
                  </select>
                </div>
              </div>
            </div>
          </section>

          {/* ========================= */}
          {/* Security */}
          {/* ========================= */}

          <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                Security
              </h2>

              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Manage your account security and password.
              </p>
            </div>

            <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                  <Lock
                    size={18}
                    className="text-gray-600 dark:text-gray-400"
                  />
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-gray-950 dark:text-white">
                    Password
                  </h3>

                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Update your account password regularly.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setPasswordModal(true)}
                className="inline-flex w-fit items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2.5 text-sm font-semibold text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
                <Lock size={16} />
                Change Password
              </button>
            </div>
          </section>

          {/* Save */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleSave}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-gray-950 px-5 text-sm font-semibold text-white transition hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-950/20 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
              <Save size={17} />
              Save Changes
            </button>
          </div>
        </div>
      </div>

      {/* ========================= */}
      {/* Change Password Modal */}
      {/* ========================= */}

      {passwordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white shadow-xl dark:border-gray-800 dark:bg-gray-900">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <div>
                <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                  Change Password
                </h2>

                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Update your account password.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setPasswordModal(false)}
                className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                aria-label="Close">
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handlePasswordSubmit} className="space-y-5 p-5">
              {/* Current Password */}
              <PasswordInput
                label="Current Password"
                name="current"
                value={passwordData.current}
                onChange={handlePasswordChange}
                visible={showPasswords.current}
                onToggle={() => togglePasswordVisibility("current")}
              />

              {/* New Password */}
              <PasswordInput
                label="New Password"
                name="newPassword"
                value={passwordData.newPassword}
                onChange={handlePasswordChange}
                visible={showPasswords.newPassword}
                onToggle={() => togglePasswordVisibility("newPassword")}
              />

              {/* Confirm Password */}
              <PasswordInput
                label="Confirm New Password"
                name="confirm"
                value={passwordData.confirm}
                onChange={handlePasswordChange}
                visible={showPasswords.confirm}
                onToggle={() => togglePasswordVisibility("confirm")}
              />

              <div className="flex flex-col-reverse gap-3 pt-2 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={() => setPasswordModal(false)}
                  className="inline-flex h-11 items-center justify-center rounded-lg border border-gray-200 px-5 text-sm font-semibold text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
                  Cancel
                </button>

                <button
                  type="submit"
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-gray-950 px-5 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
                  <Lock size={16} />
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

/* ================================= */
/* Notification Row */
/* ================================= */

const NotificationRow = ({ icon, title, description, enabled, onToggle }) => {
  return (
    <div className="flex items-center justify-between gap-4 p-5">
      <div className="flex min-w-0 items-center gap-4">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400">
          {icon}
        </div>

        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-gray-950 dark:text-white">
            {title}
          </h3>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {description}
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={onToggle}
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${
          enabled ? "bg-gray-950 dark:bg-white" : "bg-gray-300 dark:bg-gray-700"
        }`}
        aria-label={`Toggle ${title}`}
        aria-pressed={enabled}>
        <span
          className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
            enabled ? "translate-x-6 dark:bg-gray-950" : "translate-x-1"
          }`}
        />
      </button>
    </div>
  );
};

/* ================================= */
/* Password Input */
/* ================================= */

const PasswordInput = ({ label, name, value, onChange, visible, onToggle }) => {
  return (
    <div>
      <label
        htmlFor={name}
        className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
        {label}
      </label>

      <div className="relative">
        <input
          id={name}
          name={name}
          type={visible ? "text" : "password"}
          value={value}
          onChange={onChange}
          required
          className="h-11 w-full rounded-lg border border-gray-200 bg-white px-3.5 pr-11 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
          placeholder="••••••••"
        />

        <button
          type="button"
          onClick={onToggle}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 transition hover:text-gray-900 dark:hover:text-white"
          aria-label={visible ? "Hide password" : "Show password"}>
          {visible ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      </div>
    </div>
  );
};

export default Settings;
