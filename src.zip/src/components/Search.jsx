import { useEffect, useRef, useState } from "react";
import {
  Search,
  X,
  Users,
  Package,
  ShoppingCart,
  Settings,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const SearchBox = () => {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);

  const searchRef = useRef(null);
  const navigate = useNavigate();

  const searchItems = [
    {
      id: 1,
      title: "Users",
      description: "Manage users",
      path: "/users",
      icon: Users,
    },
    {
      id: 2,
      title: "Products",
      description: "Manage products",
      path: "/products",
      icon: Package,
    },
    {
      id: 3,
      title: "Orders",
      description: "Manage orders",
      path: "/orders",
      icon: ShoppingCart,
    },
    {
      id: 4,
      title: "Settings",
      description: "System settings",
      path: "/settings",
      icon: Settings,
    },
  ];

  const filteredItems = searchItems.filter((item) => {
    const searchText = `${item.title} ${item.description}`.toLowerCase();

    return searchText.includes(query.toLowerCase());
  });

  // Close search when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleSelect = (path) => {
    navigate(path);
    setQuery("");
    setOpen(false);
  };

  const clearSearch = () => {
    setQuery("");
  };

  return (
    <div ref={searchRef} className="relative hidden sm:block">
      {/* Search Input */}
      <div className="flex w-64 items-center rounded-full border border-gray-200 bg-gray-50 px-4 py-2 transition focus-within:border-gray-400 focus-within:bg-white dark:border-gray-700 dark:bg-gray-800 dark:focus-within:border-gray-500 dark:focus-within:bg-gray-900 md:w-72">
        <Search
          size={18}
          className="shrink-0 text-gray-500 dark:text-gray-400"
        />

        <input
          type="search"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => {
            if (query) {
              setOpen(true);
            }
          }}
          placeholder="Search..."
          className="w-full bg-transparent px-2 text-sm text-gray-900 outline-none placeholder:text-gray-400 dark:text-white"
        />

        {query && (
          <button
            type="button"
            onClick={clearSearch}
            className="rounded-full p-1 text-gray-400 transition hover:bg-gray-200 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-white"
            aria-label="Clear search">
            <X size={15} />
          </button>
        )}
      </div>

      {/* Search Results */}
      {open && query && (
        <div className="absolute right-0 top-12 z-50 w-80 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl dark:border-gray-700 dark:bg-gray-900">
          {filteredItems.length > 0 ? (
            <>
              <div className="border-b border-gray-100 px-4 py-3 dark:border-gray-800">
                <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">
                  Search Results
                </p>
              </div>

              <div className="p-2">
                {filteredItems.map((item) => {
                  const Icon = item.icon;

                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelect(item.path)}
                      className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left transition hover:bg-gray-100 dark:hover:bg-gray-800">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800">
                        <Icon
                          size={18}
                          className="text-gray-600 dark:text-gray-300"
                        />
                      </div>

                      <div className="min-w-0">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">
                          {item.title}
                        </p>

                        <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                          {item.description}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="px-5 py-8 text-center">
              <Search size={24} className="mx-auto text-gray-400" />

              <p className="mt-3 text-sm font-medium text-gray-900 dark:text-white">
                No results found
              </p>

              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Try searching for users, products or orders.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchBox;
