import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const Chart = () => {
  const data = [
    { month: "Jan", sales: 3200 },
    { month: "Feb", sales: 4100 },
    { month: "Mar", sales: 3800 },
    { month: "Apr", sales: 5200 },
    { month: "May", sales: 6100 },
    { month: "Jun", sales: 5800 },
    { month: "Jul", sales: 7200 },
    { month: "Aug", sales: 6800 },
    { month: "Sep", sales: 7900 },
    { month: "Oct", sales: 8500 },
    { month: "Nov", sales: 9200 },
    { month: "Dec", sales: 10500 },
  ];

  const totalSales = data.reduce((total, item) => total + item.sales, 0);

  const formatCurrency = (value) => {
    return `$${Number(value).toLocaleString()}`;
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) {
      return null;
    }

    return (
      <div className="rounded-lg border border-gray-200 bg-white px-4 py-3 shadow-lg dark:border-gray-700 dark:bg-gray-900">
        <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
          {label}
        </p>

        <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
          {formatCurrency(payload[0].value)}
        </p>

        <p className="mt-0.5 text-xs text-gray-400 dark:text-gray-500">Sales</p>
      </div>
    );
  };

  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
      {/* Header */}
      <div className="flex flex-col gap-4 border-b border-gray-100 p-5 dark:border-gray-800 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Sales Overview
          </h2>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Monthly sales performance for this year.
          </p>
        </div>

        {/* Total Sales */}
        <div className="sm:text-right">
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
            Total Sales
          </p>

          <p className="mt-1 text-xl font-bold tracking-tight text-gray-900 dark:text-white">
            {formatCurrency(totalSales)}
          </p>
        </div>
      </div>

      {/* Chart */}
      <div className="h-[320px] w-full p-4 sm:h-[360px] sm:p-5">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={data}
            margin={{
              top: 10,
              right: 10,
              left: 0,
              bottom: 5,
            }}>
            <CartesianGrid
              strokeDasharray="3 3"
              className="stroke-gray-100 dark:stroke-gray-800"
            />

            <XAxis
              dataKey="month"
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 12 }}
              className="fill-gray-500 dark:fill-gray-400"
            />

            <YAxis
              tickLine={false}
              axisLine={false}
              width={55}
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => `$${value / 1000}k`}
              className="fill-gray-500 dark:fill-gray-400"
            />

            <Tooltip
              content={<CustomTooltip />}
              cursor={{
                stroke: "currentColor",
                strokeWidth: 1,
                strokeDasharray: "4 4",
              }}
            />

            <Line
              type="monotone"
              dataKey="sales"
              stroke="currentColor"
              strokeWidth={2.5}
              dot={{
                r: 3,
                strokeWidth: 2,
              }}
              activeDot={{
                r: 6,
                strokeWidth: 2,
              }}
              className="text-gray-900 dark:text-white"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Chart;
