import Card from "./Card";
import RecentOrders from "./RecentOrders";
import RecentUsers from "./RecentUsers";
import QuickActions from "./QuickActions";
import Chart from "../components/Chart";

const Dashboard = () => {
  const stats = [
    {
      title: "Total Users",
      count: "1,248",
      avg: "↑ 12.5%",
    },
    {
      title: "Products",
      count: "356",
      avg: "↓ 8.5%",
    },
    {
      title: "Orders",
      count: "892",
      avg: "↑ 2.5%",
    },
    {
      title: "Revenue",
      count: "$24,500",
      avg: "↑ 15.5%",
    },
  ];

  const orders = [
    {
      id: "#1001",
      customer: "Ahmed",
      product: "Laptop",
      amount: "$1,200",
      status: "Completed",
    },
    {
      id: "#1002",
      customer: "Ali",
      product: "Phone",
      amount: "$800",
      status: "Pending",
    },
    {
      id: "#1003",
      customer: "Hamza",
      product: "Monitor",
      amount: "$450",
      status: "Shipped",
    },
  ];

  const users = [
    {
      id: 1,
      name: "Ahmed",
      email: "ahmed@email.com",
      role: "Admin",
      status: "Active",
    },
    {
      id: 2,
      name: "Ali",
      email: "ali@email.com",
      role: "User",
      status: "Active",
    },
    {
      id: 3,
      name: "Hamza",
      email: "hamza@email.com",
      role: "User",
      status: "Inactive",
    },
  ];

  return (
    <main className="p-4 sm:p-6">
      {/* Page Header */}
      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
            Dashboard
          </p>

          <h1 className="mt-1 text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">
            Overview
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Here's what's happening with your store today.
          </p>
        </div>

        <p className="text-xs text-gray-400 dark:text-gray-500">
          Last updated just now
        </p>
      </div>

      {/* Statistics */}
      <section aria-label="Statistics">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.title} stat={stat} />
          ))}
        </div>
      </section>

      {/* Sales Chart */}
      <section aria-label="Sales overview">
        <Chart />
      </section>

      {/* Recent Orders */}
      <section aria-label="Recent orders">
        <RecentOrders orders={orders} />
      </section>

      {/* Recent Users + Quick Actions */}
      <section
        aria-label="Recent users and quick actions"
        className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="min-w-0 xl:col-span-2">
          <RecentUsers users={users} />
        </div>

        <div className="min-w-0">
          <QuickActions />
        </div>
      </section>
    </main>
  );
};

export default Dashboard;
