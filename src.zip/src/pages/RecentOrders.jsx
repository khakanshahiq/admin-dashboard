const RecentOrders = ({ orders }) => {
  const getStatusClasses = (status) => {
    switch (status.toLowerCase()) {
      case "completed":
        return "bg-gray-900 text-white dark:bg-white dark:text-gray-900";

      case "pending":
        return "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300";

      case "shipped":
        return "border border-gray-200 bg-white text-gray-700 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300";

      case "cancelled":
        return "border border-gray-300 bg-white text-gray-500 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-400";

      default:
        return "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
      {/* Header */}
      <div className="flex flex-col gap-3 border-b border-gray-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Recent Orders
          </h2>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Latest orders from your store.
          </p>
        </div>

        <button
          type="button"
          className="w-fit text-sm font-medium text-gray-500 transition hover:text-black dark:text-gray-400 dark:hover:text-white">
          View all →
        </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px]">
          {/* Table Head */}
          <thead>
            <tr className="bg-gray-50 dark:bg-gray-800/60">
              <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                Order
              </th>

              <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                Customer
              </th>

              <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                Product
              </th>

              <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                Amount
              </th>

              <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                Status
              </th>
            </tr>
          </thead>

          {/* Table Body */}
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {orders.length > 0 ? (
              orders.map((order) => (
                <tr
                  key={order.id}
                  className="transition-colors hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  {/* Order */}
                  <td className="px-5 py-4">
                    <span className="text-sm font-semibold text-gray-900 dark:text-white">
                      {order.id}
                    </span>
                  </td>

                  {/* Customer */}
                  <td className="px-5 py-4">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {order.customer}
                    </span>
                  </td>

                  {/* Product */}
                  <td className="px-5 py-4">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {order.product}
                    </span>
                  </td>

                  {/* Amount */}
                  <td className="px-5 py-4">
                    <span className="text-sm font-semibold text-gray-900 dark:text-white">
                      {order.amount}
                    </span>
                  </td>

                  {/* Status */}
                  <td className="px-5 py-4">
                    <span
                      className={`inline-flex rounded-full px-3 py-1 text-xs font-medium ${getStatusClasses(
                        order.status,
                      )}`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="px-5 py-12 text-center">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    No orders found
                  </p>

                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    There are no recent orders to display.
                  </p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RecentOrders;
