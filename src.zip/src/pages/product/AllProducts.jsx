import { useMemo, useState } from "react";
import {
  ChevronDown,
  MoreHorizontal,
  Package,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
  X,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const initialProducts = [
  {
    id: 1,
    name: "Wireless Headphones",
    category: "Electronics",
    price: "$129.00",
    stock: 48,
    status: "Active",
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    category: "Electronics",
    price: "$249.00",
    stock: 24,
    status: "Active",
  },
  {
    id: 3,
    name: "Minimal Backpack",
    category: "Fashion",
    price: "$79.00",
    stock: 0,
    status: "Out of stock",
  },
  {
    id: 4,
    name: "Premium Desk Lamp",
    category: "Home",
    price: "$59.00",
    stock: 32,
    status: "Active",
  },
  {
    id: 5,
    name: "Leather Wallet",
    category: "Fashion",
    price: "$45.00",
    stock: 18,
    status: "Draft",
  },
  {
    id: 6,
    name: "Mechanical Keyboard",
    category: "Electronics",
    price: "$149.00",
    stock: 12,
    status: "Active",
  },
  {
    id: 7,
    name: "Ceramic Coffee Mug",
    category: "Home",
    price: "$24.00",
    stock: 65,
    status: "Active",
  },
  {
    id: 8,
    name: "Running Shoes",
    category: "Fashion",
    price: "$119.00",
    stock: 7,
    status: "Low stock",
  },
];

const statusStyles = {
  Active: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",

  Draft: "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400",

  "Out of stock":
    "bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300",

  "Low stock": "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
};

const AllProducts = () => {
  const navigate = useNavigate();

  const [products, setProducts] = useState(initialProducts);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [openMenu, setOpenMenu] = useState(null);
  const [deleteProduct, setDeleteProduct] = useState(null);

  const categories = ["All", "Electronics", "Fashion", "Home"];

  const statuses = ["All", "Active", "Draft", "Low stock", "Out of stock"];

  // -----------------------------------------
  // FILTER PRODUCTS
  // -----------------------------------------
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const searchValue = search.toLowerCase();

      const matchesSearch =
        product.name.toLowerCase().includes(searchValue) ||
        product.category.toLowerCase().includes(searchValue);

      const matchesStatus =
        statusFilter === "All" || product.status === statusFilter;

      const matchesCategory =
        categoryFilter === "All" || product.category === categoryFilter;

      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [products, search, statusFilter, categoryFilter]);

  // -----------------------------------------
  // PRODUCT STATS
  // -----------------------------------------
  const productStats = useMemo(() => {
    return {
      total: products.length,

      active: products.filter((product) => product.status === "Active").length,

      lowStock: products.filter((product) => product.status === "Low stock")
        .length,

      outOfStock: products.filter(
        (product) => product.status === "Out of stock",
      ).length,
    };
  }, [products]);

  // -----------------------------------------
  // ADD PRODUCT
  // -----------------------------------------
  const handleAddProduct = () => {
    navigate("/admin/add/product");
  };

  // -----------------------------------------
  // DELETE PRODUCT
  // -----------------------------------------
  const handleDeleteProduct = () => {
    if (!deleteProduct) return;

    setProducts((currentProducts) =>
      currentProducts.filter((product) => product.id !== deleteProduct.id),
    );

    setDeleteProduct(null);
    setOpenMenu(null);
  };

  return (
    <div className="space-y-6">
      {/* =========================================
          PAGE HEADER
      ========================================= */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            Products
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Manage your products and inventory.
          </p>
        </div>

        <button
          type="button"
          onClick={handleAddProduct}
          className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
          <Plus size={17} />
          Add Product
        </button>
      </div>

      {/* =========================================
          STATS
      ========================================= */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {/* Total */}
        <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
              Total products
            </p>

            <Package size={16} className="text-gray-400" />
          </div>

          <p className="mt-2 text-xl font-bold text-gray-950 dark:text-white">
            {productStats.total}
          </p>
        </div>

        {/* Active */}
        <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
            Active
          </p>

          <p className="mt-2 text-xl font-bold text-gray-950 dark:text-white">
            {productStats.active}
          </p>
        </div>

        {/* Low Stock */}
        <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
            Low stock
          </p>

          <p className="mt-2 text-xl font-bold text-gray-950 dark:text-white">
            {productStats.lowStock}
          </p>
        </div>

        {/* Out Of Stock */}
        <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
            Out of stock
          </p>

          <p className="mt-2 text-xl font-bold text-gray-950 dark:text-white">
            {productStats.outOfStock}
          </p>
        </div>
      </div>

      {/* =========================================
          MAIN CARD
      ========================================= */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        {/* =========================================
            TOOLBAR
        ========================================= */}
        <div className="flex flex-col gap-3 border-b border-gray-200 p-4 dark:border-gray-800 lg:flex-row lg:items-center lg:justify-between">
          {/* Search */}
          <div className="relative w-full lg:max-w-sm">
            <Search
              size={17}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
            />

            <input
              type="text"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search products..."
              className="h-10 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-4 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-col gap-2 sm:flex-row">
            {/* Category */}
            <div className="relative">
              <SlidersHorizontal
                size={15}
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
              />

              <select
                value={categoryFilter}
                onChange={(event) => setCategoryFilter(event.target.value)}
                className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white pl-9 pr-9 text-sm text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 sm:w-40">
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category === "All" ? "All categories" : category}
                  </option>
                ))}
              </select>

              <ChevronDown
                size={15}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
            </div>

            {/* Status */}
            <div className="relative">
              <select
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
                className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-4 pr-9 text-sm text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 sm:w-36">
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status === "All" ? "All statuses" : status}
                  </option>
                ))}
              </select>

              <ChevronDown
                size={15}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
            </div>
          </div>
        </div>

        {/* =========================================
            DESKTOP TABLE
        ========================================= */}
        <div className="hidden overflow-x-auto md:block">
          <table className="w-full min-w-[760px]">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50/70 dark:border-gray-800 dark:bg-gray-950/40">
                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Product
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Category
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Price
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Stock
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Status
                </th>

                <th className="w-16 px-5 py-3.5"></th>
              </tr>
            </thead>

            <tbody>
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <tr
                    key={product.id}
                    className="border-b border-gray-100 transition hover:bg-gray-50 last:border-b-0 dark:border-gray-800 dark:hover:bg-gray-800/40">
                    {/* Product */}
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                          <Package size={18} />
                        </div>

                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                            {product.name}
                          </p>

                          <p className="mt-0.5 text-xs text-gray-400">
                            Product #{String(product.id).padStart(4, "0")}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                      {product.category}
                    </td>

                    {/* Price */}
                    <td className="px-5 py-4 text-sm font-medium text-gray-900 dark:text-white">
                      {product.price}
                    </td>

                    {/* Stock */}
                    <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                      {product.stock}
                    </td>

                    {/* Status */}
                    <td className="px-5 py-4">
                      <span
                        className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${
                          statusStyles[product.status]
                        }`}>
                        {product.status}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="relative px-5 py-4 text-right">
                      <button
                        type="button"
                        onClick={() =>
                          setOpenMenu(
                            openMenu === product.id ? null : product.id,
                          )
                        }
                        className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                        aria-label={`Actions for ${product.name}`}>
                        <MoreHorizontal size={18} />
                      </button>

                      {openMenu === product.id && (
                        <div className="absolute right-5 top-12 z-20 w-32 rounded-lg border border-gray-200 bg-white p-1 text-left shadow-lg dark:border-gray-700 dark:bg-gray-900">
                          {/* View */}
                          <button
                            type="button"
                            onClick={() => {
                              setOpenMenu(null);
                              navigate(`/admin/all/products/${product.id}`);
                            }}
                            className="w-full rounded-md px-3 py-2 text-left text-sm text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
                            View
                          </button>

                          {/* Edit */}
                          <button
                            type="button"
                            onClick={() => {
                              setOpenMenu(null);
                              navigate(`/admin/product/${product.id}/edit`);
                            }}
                            className="w-full rounded-md px-3 py-2 text-left text-sm text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
                            Edit
                          </button>

                          {/* Delete */}
                          <button
                            type="button"
                            onClick={() => {
                              setOpenMenu(null);
                              setDeleteProduct(product);
                            }}
                            className="w-full rounded-md px-3 py-2 text-left text-sm text-red-500 transition hover:bg-red-50 dark:hover:bg-red-950/30">
                            Delete
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="px-5 py-14 text-center">
                    <Package
                      size={28}
                      className="mx-auto text-gray-300 dark:text-gray-600"
                    />

                    <p className="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
                      No products found
                    </p>

                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      Try changing your search or filters.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* =========================================
            MOBILE CARDS
        ========================================= */}
        <div className="divide-y divide-gray-100 md:hidden dark:divide-gray-800">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <div key={product.id} className="p-4">
                {/* Product Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                      <Package size={18} />
                    </div>

                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                        {product.name}
                      </p>

                      <p className="mt-0.5 text-xs text-gray-400">
                        {product.category}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      setOpenMenu(openMenu === product.id ? null : product.id)
                    }
                    className="shrink-0 rounded-lg p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
                    aria-label={`Actions for ${product.name}`}>
                    <MoreHorizontal size={18} />
                  </button>
                </div>

                {/* Product Info */}
                <div className="mt-4 grid grid-cols-3 gap-3">
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Price
                    </p>

                    <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                      {product.price}
                    </p>
                  </div>

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Stock
                    </p>

                    <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                      {product.stock}
                    </p>
                  </div>

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Status
                    </p>

                    <span
                      className={`mt-1 inline-flex rounded-full px-2 py-1 text-[11px] font-medium ${
                        statusStyles[product.status]
                      }`}>
                      {product.status}
                    </span>
                  </div>
                </div>

                {/* Mobile Actions */}
                {openMenu === product.id && (
                  <div className="mt-3 flex gap-2 border-t border-gray-100 pt-3 dark:border-gray-800">
                    {/* View */}
                    <button
                      type="button"
                      onClick={() => {
                        setOpenMenu(null);
                        navigate(`/admin/all/products/${product.id}`);
                      }}
                      className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
                      View
                    </button>

                    {/* Edit */}
                    <button
                      type="button"
                      onClick={() => {
                        setOpenMenu(null);
                        navigate(`/admin/product/${product.id}/edit`);
                      }}
                      className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
                      Edit
                    </button>

                    {/* Delete */}
                    <button
                      type="button"
                      onClick={() => {
                        setOpenMenu(null);
                        setDeleteProduct(product);
                      }}
                      className="flex-1 rounded-lg border border-red-200 px-3 py-2 text-xs font-medium text-red-500 transition hover:bg-red-50 dark:border-red-900/50 dark:hover:bg-red-950/30">
                      Delete
                    </button>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="px-5 py-14 text-center">
              <Package
                size={28}
                className="mx-auto text-gray-300 dark:text-gray-600"
              />

              <p className="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
                No products found
              </p>

              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Try changing your search or filters.
              </p>
            </div>
          )}
        </div>

        {/* =========================================
            FOOTER
        ========================================= */}
        <div className="flex flex-col gap-3 border-t border-gray-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Showing{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {filteredProducts.length}
            </span>{" "}
            of{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {products.length}
            </span>{" "}
            products
          </p>

          <div className="flex items-center gap-1">
            <button
              type="button"
              disabled
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-400 dark:border-gray-700">
              Previous
            </button>

            <button
              type="button"
              className="rounded-lg bg-gray-950 px-3 py-2 text-xs font-semibold text-white dark:bg-white dark:text-gray-950">
              1
            </button>

            <button
              type="button"
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
              2
            </button>

            <button
              type="button"
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
              Next
            </button>
          </div>
        </div>
      </div>

      {/* =========================================
          DELETE CONFIRMATION MODAL
      ========================================= */}
      {deleteProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white shadow-2xl dark:border-gray-800 dark:bg-gray-900">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 p-6">
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-500 dark:bg-red-950/40">
                  <Trash2 size={20} />
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                    Delete product?
                  </h2>

                  <p className="mt-1 text-sm leading-5 text-gray-500 dark:text-gray-400">
                    Are you sure you want to delete{" "}
                    <span className="font-medium text-gray-800 dark:text-gray-200">
                      {deleteProduct.name}
                    </span>
                    ?
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setDeleteProduct(null)}
                className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                aria-label="Close delete confirmation">
                <X size={18} />
              </button>
            </div>

            {/* Warning */}
            <div className="mx-6 rounded-lg border border-red-100 bg-red-50 px-4 py-3 dark:border-red-900/40 dark:bg-red-950/20">
              <p className="text-xs leading-5 text-red-600 dark:text-red-400">
                This action cannot be undone. The product will be permanently
                removed from your product list.
              </p>
            </div>

            {/* Actions */}
            <div className="flex flex-col-reverse gap-2 border-t border-gray-200 p-6 sm:flex-row sm:justify-end dark:border-gray-800">
              <button
                type="button"
                onClick={() => setDeleteProduct(null)}
                className="h-10 rounded-lg border border-gray-200 px-4 text-sm font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white">
                Cancel
              </button>

              <button
                type="button"
                onClick={handleDeleteProduct}
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-red-500 px-4 text-sm font-semibold text-white transition hover:bg-red-600">
                <Trash2 size={16} />
                Delete Product
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AllProducts;
