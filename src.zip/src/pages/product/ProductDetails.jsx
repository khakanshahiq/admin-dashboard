import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Edit3,
  Package,
  Tag,
  DollarSign,
  ShoppingCart,
  TrendingUp,
  CalendarDays,
  User,
  CheckCircle2,
  Clock3,
  XCircle,
  Printer,
  MoreHorizontal,
} from "lucide-react";

const products = {
  1: {
    id: 1,
    name: "Premium Wireless Headphones",
    sku: "WH-1001",
    category: "Electronics",
    price: 149.99,
    stock: 48,
    status: "Active",
    description:
      "Premium wireless headphones with active noise cancellation, comfortable ear cushions, and long-lasting battery life. Designed for music, calls, travel, and everyday use.",
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80",
    sales: 328,
    revenue: 49196.72,
    created: "August 12, 2026",
    updated: "August 28, 2026",
    seller: "NOVA Store",
  },

  2: {
    id: 2,
    name: "Minimal Leather Backpack",
    sku: "BP-2042",
    category: "Accessories",
    price: 89.99,
    stock: 24,
    status: "Active",
    description:
      "A clean and minimal leather backpack designed for work, travel, and everyday use. Features a spacious interior and dedicated laptop compartment.",
    image:
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80",
    sales: 214,
    revenue: 19257.86,
    created: "August 8, 2026",
    updated: "August 25, 2026",
    seller: "NOVA Store",
  },

  3: {
    id: 3,
    name: "Smart Fitness Watch",
    sku: "FW-3021",
    category: "Wearables",
    price: 129.99,
    stock: 31,
    status: "Active",
    description:
      "Modern fitness smartwatch with health tracking, activity monitoring, notifications, and a bright high-resolution display.",
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80",
    sales: 187,
    revenue: 24308.13,
    created: "July 29, 2026",
    updated: "August 23, 2026",
    seller: "NOVA Store",
  },

  4: {
    id: 4,
    name: "Classic Running Shoes",
    sku: "RS-4018",
    category: "Fashion",
    price: 74.99,
    stock: 12,
    status: "Low Stock",
    description:
      "Lightweight running shoes designed for daily training and comfortable everyday movement. Breathable construction with responsive cushioning.",
    image:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80",
    sales: 156,
    revenue: 11698.44,
    created: "July 18, 2026",
    updated: "August 20, 2026",
    seller: "NOVA Store",
  },

  5: {
    id: 5,
    name: "Ceramic Coffee Mug",
    sku: "CM-5092",
    category: "Home & Living",
    price: 24.99,
    stock: 0,
    status: "Out of Stock",
    description:
      "Minimal ceramic coffee mug with a smooth matte finish. Perfect for coffee, tea, and everyday home or office use.",
    image:
      "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=900&q=80",
    sales: 98,
    revenue: 2449.02,
    created: "July 10, 2026",
    updated: "August 18, 2026",
    seller: "NOVA Store",
  },
};

const recentActivity = [
  {
    id: 1,
    icon: ShoppingCart,
    title: "New order received",
    description: "Order #ORD-1008 included this product.",
    time: "2 hours ago",
  },
  {
    id: 2,
    icon: Package,
    title: "Stock updated",
    description: "Stock quantity was updated by Admin.",
    time: "5 hours ago",
  },
  {
    id: 3,
    icon: Edit3,
    title: "Product information updated",
    description: "Product details were modified.",
    time: "Yesterday",
  },
  {
    id: 4,
    icon: CheckCircle2,
    title: "Product published",
    description: "Product became available in the store.",
    time: "Aug 12, 2026",
  },
];

const ProductDetails = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const product = products[id] || products[1];

  const [activeImage, setActiveImage] = useState(product.image);
  const [showMore, setShowMore] = useState(false);

  const statusStyles = {
    Active: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-200",
    "Low Stock":
      "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-200",
    "Out of Stock":
      "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
  };

  const handleEdit = () => {
    navigate(`/admin/product?edit=${product.id}`);
  };

  const handlePrint = () => {
    window.print();
  };

  const thumbnails = [product.image, product.image, product.image];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <button
            type="button"
            onClick={() => navigate("/admin/all/products")}
            className="mb-3 inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">
            <ArrowLeft size={16} />
            Back to Products
          </button>

          <h1 className="text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
            Product Details
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            View product information, performance, and recent activity.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-200 dark:hover:bg-gray-800">
            <Printer size={16} />
            <span className="hidden sm:inline">Print</span>
          </button>

          <button
            type="button"
            onClick={handleEdit}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-black px-4 text-sm font-medium text-white transition hover:bg-gray-800 dark:bg-white dark:text-black dark:hover:bg-gray-200">
            <Edit3 size={16} />
            Edit Product
          </button>
        </div>
      </div>

      {/* Main Product Card */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="grid lg:grid-cols-2">
          {/* Product Images */}
          <div className="border-b border-gray-200 p-5 sm:p-6 lg:border-b-0 lg:border-r dark:border-gray-800">
            <div className="flex aspect-square items-center justify-center overflow-hidden rounded-xl bg-gray-50 dark:bg-gray-950">
              <img
                src={activeImage}
                alt={product.name}
                className="h-full w-full object-cover"
              />
            </div>

            <div className="mt-4 grid grid-cols-3 gap-3">
              {thumbnails.map((image, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setActiveImage(image)}
                  className={`aspect-square overflow-hidden rounded-lg border-2 transition ${
                    activeImage === image && index === 0
                      ? "border-black dark:border-white"
                      : "border-transparent hover:border-gray-300 dark:hover:border-gray-700"
                  }`}>
                  <img
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    className="h-full w-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Information */}
          <div className="p-5 sm:p-6 lg:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  {product.category}
                </p>

                <h2 className="mt-1 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
                  {product.name}
                </h2>

                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  SKU: {product.sku}
                </p>
              </div>

              <button
                type="button"
                className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-gray-200">
                <MoreHorizontal size={20} />
              </button>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <span
                className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium ${
                  statusStyles[product.status]
                }`}>
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    product.status === "Active"
                      ? "bg-black dark:bg-white"
                      : "bg-gray-400"
                  }`}
                />
                {product.status}
              </span>

              <span className="inline-flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                <Tag size={15} />
                {product.category}
              </span>
            </div>

            <div className="mt-8">
              <p className="text-3xl font-semibold tracking-tight text-gray-900 dark:text-white">
                ${product.price.toFixed(2)}
              </p>

              <div className="mt-2 flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                <Package size={16} />
                {product.stock > 0
                  ? `${product.stock} units available`
                  : "Currently out of stock"}
              </div>
            </div>

            <div className="my-8 border-t border-gray-200 dark:border-gray-800" />

            <div>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                Description
              </h3>

              <p
                className={`mt-3 text-sm leading-6 text-gray-600 dark:text-gray-400 ${
                  showMore ? "" : "line-clamp-3"
                }`}>
                {product.description}
              </p>

              <button
                type="button"
                onClick={() => setShowMore(!showMore)}
                className="mt-2 text-sm font-medium text-gray-900 hover:underline dark:text-white">
                {showMore ? "Show less" : "Read more"}
              </button>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4">
              <InfoItem
                icon={CalendarDays}
                label="Created"
                value={product.created}
              />

              <InfoItem
                icon={Clock3}
                label="Last Updated"
                value={product.updated}
              />

              <InfoItem icon={User} label="Seller" value={product.seller} />

              <InfoItem
                icon={Package}
                label="Stock"
                value={`${product.stock} units`}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Performance Stats */}
      <div>
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Product Performance
          </h2>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Overview of this product's sales performance.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <PerformanceCard
            icon={ShoppingCart}
            label="Total Sales"
            value={product.sales.toLocaleString()}
            description="Units sold"
          />

          <PerformanceCard
            icon={DollarSign}
            label="Revenue"
            value={`$${product.revenue.toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}`}
            description="Total generated"
          />

          <PerformanceCard
            icon={TrendingUp}
            label="Avg. Price"
            value={`$${product.price.toFixed(2)}`}
            description="Per unit"
          />

          <PerformanceCard
            icon={Package}
            label="Current Stock"
            value={product.stock.toLocaleString()}
            description="Units available"
          />
        </div>
      </div>

      {/* Lower Content */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Product Information */}
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 lg:col-span-2">
          <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
            <h2 className="font-semibold text-gray-900 dark:text-white">
              Product Information
            </h2>
          </div>

          <div className="grid gap-x-8 gap-y-6 p-5 sm:grid-cols-2">
            <DetailRow label="Product Name" value={product.name} />
            <DetailRow label="SKU" value={product.sku} />
            <DetailRow label="Category" value={product.category} />
            <DetailRow label="Price" value={`$${product.price.toFixed(2)}`} />
            <DetailRow
              label="Stock Quantity"
              value={`${product.stock} units`}
            />
            <DetailRow label="Status" value={product.status} />
            <DetailRow label="Seller" value={product.seller} />
            <DetailRow label="Created" value={product.created} />
          </div>
        </div>

        {/* Activity */}
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
          <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
            <h2 className="font-semibold text-gray-900 dark:text-white">
              Recent Activity
            </h2>
          </div>

          <div className="divide-y divide-gray-200 dark:divide-gray-800">
            {recentActivity.map((activity) => {
              const Icon = activity.icon;

              return (
                <div key={activity.id} className="flex gap-3 p-4">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                    <Icon size={15} />
                  </div>

                  <div className="min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {activity.title}
                    </p>

                    <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
                      {activity.description}
                    </p>

                    <p className="mt-1 text-xs text-gray-400 dark:text-gray-500">
                      {activity.time}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="flex flex-col-reverse gap-3 border-t border-gray-200 pt-6 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
        <button
          type="button"
          onClick={() => navigate("/admin/all/products")}
          className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-200 dark:hover:bg-gray-800">
          <ArrowLeft size={16} />
          Back to Products
        </button>

        <button
          type="button"
          onClick={handleEdit}
          className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-black px-4 text-sm font-medium text-white transition hover:bg-gray-800 dark:bg-white dark:text-black dark:hover:bg-gray-200">
          <Edit3 size={16} />
          Edit Product
        </button>
      </div>
    </div>
  );
};

const InfoItem = ({ icon: Icon, label, value }) => {
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
        <Icon size={16} />
      </div>

      <div className="min-w-0">
        <p className="text-xs text-gray-500 dark:text-gray-400">{label}</p>
        <p className="mt-1 truncate text-sm font-medium text-gray-900 dark:text-white">
          {value}
        </p>
      </div>
    </div>
  );
};

const PerformanceCard = ({ icon: Icon, label, value, description }) => {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
          <Icon size={17} />
        </div>
      </div>

      <p className="mt-4 text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400">
        {label}
      </p>

      <p className="mt-1 text-xl font-semibold text-gray-900 dark:text-white">
        {value}
      </p>

      <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
        {description}
      </p>
    </div>
  );
};

const DetailRow = ({ label, value }) => {
  return (
    <div>
      <p className="text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400">
        {label}
      </p>

      <p className="mt-1.5 text-sm font-medium text-gray-900 dark:text-white">
        {value}
      </p>
    </div>
  );
};

export default ProductDetails;
