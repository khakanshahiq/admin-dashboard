import { useEffect, useState } from "react";
import { ArrowLeft, ImagePlus, Package, Save, X } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";

const productsData = [
  {
    id: 1,
    name: "Wireless Headphones",
    sku: "WH-001",
    category: "Electronics",
    price: "129.00",
    stock: 48,
    status: "Active",
    description:
      "Premium wireless headphones with clear sound, comfortable ear cushions, and long-lasting battery life.",
    image: null,
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    sku: "SW-002",
    category: "Electronics",
    price: "249.00",
    stock: 24,
    status: "Active",
    description:
      "A modern smart watch with fitness tracking, notifications, and a premium display.",
    image: null,
  },
  {
    id: 3,
    name: "Minimal Backpack",
    sku: "MB-003",
    category: "Fashion",
    price: "79.00",
    stock: 0,
    status: "Inactive",
    description:
      "Minimal everyday backpack with a clean design and spacious storage.",
    image: null,
  },
  {
    id: 4,
    name: "Premium Desk Lamp",
    sku: "DL-004",
    category: "Home",
    price: "59.00",
    stock: 32,
    status: "Active",
    description:
      "Elegant desk lamp designed for comfortable and focused workspace lighting.",
    image: null,
  },
  {
    id: 5,
    name: "Leather Wallet",
    sku: "LW-005",
    category: "Fashion",
    price: "45.00",
    stock: 18,
    status: "Draft",
    description:
      "Classic leather wallet with multiple card slots and a compact design.",
    image: null,
  },
  {
    id: 6,
    name: "Mechanical Keyboard",
    sku: "MK-006",
    category: "Electronics",
    price: "149.00",
    stock: 12,
    status: "Active",
    description:
      "Mechanical keyboard with responsive switches and a comfortable typing experience.",
    image: null,
  },
  {
    id: 7,
    name: "Ceramic Coffee Mug",
    sku: "CM-007",
    category: "Home",
    price: "24.00",
    stock: 65,
    status: "Active",
    description: "Minimal ceramic coffee mug suitable for everyday use.",
    image: null,
  },
  {
    id: 8,
    name: "Running Shoes",
    sku: "RS-008",
    category: "Fashion",
    price: "119.00",
    stock: 7,
    status: "Active",
    description:
      "Lightweight running shoes designed for everyday training and comfort.",
    image: null,
  },
];

const EditProduct = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const product = productsData.find((item) => String(item.id) === String(id));

  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    category: "",
    price: "",
    stock: "",
    status: "Active",
    description: "",
  });

  const [image, setImage] = useState(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!product) return;

    setFormData({
      name: product.name,
      sku: product.sku,
      category: product.category,
      price: product.price,
      stock: String(product.stock),
      status:
        product.status === "Low stock" || product.status === "Out of stock"
          ? "Active"
          : product.status,
      description: product.description,
    });

    setImage(product.image ? { preview: product.image } : null);
  }, [product]);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleImageChange = (event) => {
    const file = event.target.files?.[0];

    if (!file) return;

    setImage({
      file,
      preview: URL.createObjectURL(file),
    });
  };

  const removeImage = () => {
    setImage(null);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const updatedProduct = {
      id: product.id,
      ...formData,
      image,
    };

    console.log("Product updated:", updatedProduct);

    setSaved(true);

    setTimeout(() => {
      navigate(`/admin/all/products/${product.id}`);
    }, 800);
  };

  if (!product) {
    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-gray-200 bg-white p-8 text-center dark:border-gray-800 dark:bg-gray-900">
          <Package
            size={32}
            className="mx-auto text-gray-300 dark:text-gray-600"
          />

          <h2 className="mt-4 text-lg font-semibold text-gray-900 dark:text-white">
            Product not found
          </h2>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            The product you are trying to edit does not exist.
          </p>

          <button
            type="button"
            onClick={() => navigate("/admin/all/products")}
            className="mt-5 inline-flex h-10 items-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
            <ArrowLeft size={16} />
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <button
            type="button"
            onClick={() => navigate(`/admin/all/products/${product.id}`)}
            className="mt-0.5 rounded-lg p-2 text-gray-500 transition hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
            aria-label="Back to product">
            <ArrowLeft size={19} />
          </button>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
                Edit Product
              </h1>

              <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-medium text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                #{String(product.id).padStart(4, "0")}
              </span>
            </div>

            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Update your product information and inventory.
            </p>
          </div>
        </div>
      </div>

      {/* Success Message */}
      {saved && (
        <div className="flex items-center gap-3 rounded-xl border border-gray-200 bg-white px-4 py-3 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800">
            <Save size={15} className="text-gray-700 dark:text-gray-300" />
          </div>

          <div>
            <p className="text-sm font-semibold text-gray-900 dark:text-white">
              Product updated successfully
            </p>

            <p className="text-xs text-gray-500 dark:text-gray-400">
              Redirecting to product details...
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          {/* Main Information */}
          <div className="space-y-6 xl:col-span-2">
            <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                  Product information
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Update the basic information for your product.
                </p>
              </div>

              <div className="space-y-5 p-5">
                {/* Product Name */}
                <div>
                  <label
                    htmlFor="name"
                    className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Product name
                  </label>

                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="e.g. Wireless Headphones"
                    className="h-11 w-full rounded-lg border border-gray-200 bg-white px-3.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                  />
                </div>

                {/* SKU + Category */}
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="sku"
                      className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                      SKU
                    </label>

                    <input
                      id="sku"
                      name="sku"
                      type="text"
                      value={formData.sku}
                      onChange={handleChange}
                      placeholder="e.g. WH-001"
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white px-3.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="category"
                      className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Category
                    </label>

                    <select
                      id="category"
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white px-3.5 text-sm text-gray-700 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 dark:focus:border-gray-300">
                      <option value="">Select category</option>
                      <option value="Electronics">Electronics</option>
                      <option value="Fashion">Fashion</option>
                      <option value="Home">Home</option>
                      <option value="Sports">Sports</option>
                    </select>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label
                    htmlFor="description"
                    className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Description
                  </label>

                  <textarea
                    id="description"
                    name="description"
                    rows="6"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Write a description for your product..."
                    className="w-full resize-none rounded-lg border border-gray-200 bg-white px-3.5 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                  />

                  <p className="mt-2 text-xs text-gray-400">
                    Describe the product, its features, and key benefits.
                  </p>
                </div>
              </div>
            </section>

            {/* Pricing & Inventory */}
            <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                  Pricing & inventory
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Update the price and available stock.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-5 p-5 sm:grid-cols-2">
                {/* Price */}
                <div>
                  <label
                    htmlFor="price"
                    className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Price
                  </label>

                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-gray-400">
                      $
                    </span>

                    <input
                      id="price"
                      name="price"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.price}
                      onChange={handleChange}
                      placeholder="0.00"
                      className="h-11 w-full rounded-lg border border-gray-200 bg-white pl-8 pr-3.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                    />
                  </div>
                </div>

                {/* Stock */}
                <div>
                  <label
                    htmlFor="stock"
                    className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Stock quantity
                  </label>

                  <input
                    id="stock"
                    name="stock"
                    type="number"
                    min="0"
                    value={formData.stock}
                    onChange={handleChange}
                    placeholder="0"
                    className="h-11 w-full rounded-lg border border-gray-200 bg-white px-3.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
                  />
                </div>
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Product Image */}
            <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                  Product image
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Replace the main product image if needed.
                </p>
              </div>

              <div className="p-5">
                {image ? (
                  <div className="relative overflow-hidden rounded-xl border border-gray-200 dark:border-gray-700">
                    <img
                      src={image.preview}
                      alt={formData.name}
                      className="aspect-square w-full object-cover"
                    />

                    <button
                      type="button"
                      onClick={removeImage}
                      className="absolute right-3 top-3 rounded-lg bg-white p-2 text-gray-700 shadow-md transition hover:bg-gray-100 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800"
                      aria-label="Remove image">
                      <X size={16} />
                    </button>
                  </div>
                ) : (
                  <label className="flex aspect-square cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-gray-200 bg-gray-50 transition hover:border-gray-400 hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-950 dark:hover:border-gray-500 dark:hover:bg-gray-900">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-white text-gray-500 shadow-sm dark:bg-gray-900 dark:text-gray-400">
                      <ImagePlus size={20} />
                    </div>

                    <p className="mt-4 text-sm font-semibold text-gray-700 dark:text-gray-300">
                      Upload image
                    </p>

                    <p className="mt-1 text-xs text-gray-400">
                      PNG, JPG or WEBP
                    </p>

                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
            </section>

            {/* Status */}
            <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                  Product status
                </h2>
              </div>

              <div className="p-5">
                <label
                  htmlFor="status"
                  className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Status
                </label>

                <select
                  id="status"
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="h-11 w-full rounded-lg border border-gray-200 bg-white px-3.5 text-sm text-gray-700 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 dark:focus:border-gray-300">
                  <option value="Active">Active</option>
                  <option value="Draft">Draft</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </section>

            {/* Product Summary */}
            <section className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                  Product summary
                </h2>
              </div>

              <div className="space-y-3 p-5">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    Product ID
                  </span>

                  <span className="text-xs font-medium text-gray-900 dark:text-white">
                    #{String(product.id).padStart(4, "0")}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    SKU
                  </span>

                  <span className="text-xs font-medium text-gray-900 dark:text-white">
                    {formData.sku || "—"}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    Current stock
                  </span>

                  <span className="text-xs font-medium text-gray-900 dark:text-white">
                    {formData.stock || "0"}
                  </span>
                </div>
              </div>
            </section>
          </div>
        </div>

        {/* Form Actions */}
        <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={() => navigate(`/admin/all/products/${product.id}`)}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white px-5 text-sm font-semibold text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
            Cancel
          </button>

          <button
            type="submit"
            disabled={saved}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-gray-950 px-5 text-sm font-semibold text-white transition hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-950/20 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
            <Save size={17} />
            {saved ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditProduct;
