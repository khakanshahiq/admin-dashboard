import {
  Users,
  Package,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  TrendingDown,
} from "lucide-react";

const Card = ({ stat }) => {
  const isNegative = stat.avg.startsWith("↓");

  const icons = {
    "Total Users": Users,
    Products: Package,
    Orders: ShoppingCart,
    Revenue: DollarSign,
  };

  const Icon = icons[stat.title] || Package;

  return (
    <div className="group rounded-xl border border-gray-200 bg-white p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-gray-800 dark:bg-gray-900">
      {/* Top */}
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
            {stat.title}
          </p>

          <p className="mt-3 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
            {stat.count}
          </p>
        </div>

        {/* Icon */}
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 transition-colors group-hover:bg-gray-200 dark:bg-gray-800 dark:group-hover:bg-gray-700">
          <Icon size={19} className="text-gray-700 dark:text-gray-300" />
        </div>
      </div>

      {/* Bottom */}
      <div className="mt-4 flex items-center gap-2">
        <div
          className={`flex items-center gap-1 text-sm font-semibold ${
            isNegative
              ? "text-gray-500 dark:text-gray-400"
              : "text-gray-900 dark:text-white"
          }`}>
          {isNegative ? <TrendingDown size={15} /> : <TrendingUp size={15} />}

          <span>{stat.avg.replace("↑", "").replace("↓", "")}</span>
        </div>

        <span className="text-xs text-gray-400 dark:text-gray-500">
          vs last month
        </span>
      </div>
    </div>
  );
};

export default Card;
