import { Link } from "react-router-dom";
import {
  UserPlus,
  PackagePlus,
  ShoppingCart,
  Settings,
  ArrowUpRight,
} from "lucide-react";

const QuickActions = () => {
  const actions = [
    {
      id: 1,
      title: "Add User",
      description: "Create a new user account",
      path: "/users/create",
      icon: UserPlus,
    },
    {
      id: 2,
      title: "Add Product",
      description: "Add a new product",
      path: "/products/create",
      icon: PackagePlus,
    },
    {
      id: 3,
      title: "Manage Orders",
      description: "View and manage orders",
      path: "/orders",
      icon: ShoppingCart,
    },
    {
      id: 4,
      title: "Settings",
      description: "Manage store settings",
      path: "/settings",
      icon: Settings,
    },
  ];

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
      {/* Header */}
      <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
          Quick Actions
        </h2>

        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Common actions to manage your store.
        </p>
      </div>

      {/* Actions */}
      <div className="p-4">
        <div className="space-y-2">
          {actions.map((action) => {
            const Icon = action.icon;

            return (
              <Link
                key={action.id}
                to={action.path}
                className="group flex items-center gap-3 rounded-lg border border-gray-200 p-3.5 transition-all duration-200 hover:-translate-y-0.5 hover:bg-gray-50 hover:shadow-sm dark:border-gray-800 dark:hover:bg-gray-800/70">
                {/* Icon */}
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 transition-colors group-hover:bg-gray-200 dark:bg-gray-800 dark:group-hover:bg-gray-700">
                  <Icon
                    size={18}
                    className="text-gray-700 dark:text-gray-300"
                  />
                </div>

                {/* Text */}
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">
                    {action.title}
                  </p>

                  <p className="mt-0.5 truncate text-xs text-gray-500 dark:text-gray-400">
                    {action.description}
                  </p>
                </div>

                {/* Arrow */}
                <ArrowUpRight
                  size={16}
                  className="shrink-0 text-gray-400 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-gray-700 dark:text-gray-500 dark:group-hover:text-gray-300"
                />
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default QuickActions;
