const RecentUsers = ({ users }) => {
  const getStatusClasses = (status) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-gray-900 text-white dark:bg-white dark:text-gray-900";

      case "inactive":
        return "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400";

      default:
        return "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400";
    }
  };

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
      {/* Header */}
      <div className="flex flex-col gap-3 border-b border-gray-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Recent Users
          </h2>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Recently registered users.
          </p>
        </div>

        <button
          type="button"
          className="w-fit text-sm font-medium text-gray-500 transition hover:text-black dark:text-gray-400 dark:hover:text-white">
          View all →
        </button>
      </div>

      {/* Users */}
      <div>
        {users.length > 0 ? (
          users.map((user) => (
            <div
              key={user.id}
              className="flex flex-col gap-4 border-b border-gray-100 px-5 py-4 last:border-b-0 transition-colors hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/50 sm:flex-row sm:items-center sm:justify-between">
              {/* User Info */}
              <div className="flex min-w-0 items-center gap-3">
                {/* Avatar */}
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gray-100 text-sm font-semibold text-gray-700 dark:bg-gray-800 dark:text-gray-300">
                  {user.name.charAt(0).toUpperCase()}
                </div>

                <div className="min-w-0">
                  <h3 className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                    {user.name}
                  </h3>

                  <p className="truncate text-sm text-gray-500 dark:text-gray-400">
                    {user.email}
                  </p>
                </div>
              </div>

              {/* Role + Status */}
              <div className="flex items-center justify-between gap-4 sm:justify-end">
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  {user.role}
                </p>

                <span
                  className={`inline-flex rounded-full px-3 py-1 text-xs font-medium ${getStatusClasses(
                    user.status,
                  )}`}>
                  {user.status}
                </span>
              </div>
            </div>
          ))
        ) : (
          /* Empty State */
          <div className="px-5 py-12 text-center">
            <p className="text-sm font-medium text-gray-900 dark:text-white">
              No users found
            </p>

            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              There are no recent users to display.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default RecentUsers;
