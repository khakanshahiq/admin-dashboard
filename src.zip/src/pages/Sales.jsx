import { useMemo, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  ChevronDown,
  DollarSign,
  Download,
  ShoppingBag,
  TrendingUp,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

/* ================================================= */
/* MOCK DATA */
/* ================================================= */

const salesData = [
  { month: "Jan", revenue: 4200, orders: 42 },
  { month: "Feb", revenue: 5100, orders: 51 },
  { month: "Mar", revenue: 4700, orders: 47 },
  { month: "Apr", revenue: 6200, orders: 62 },
  { month: "May", revenue: 5800, orders: 58 },
  { month: "Jun", revenue: 7100, orders: 71 },
  { month: "Jul", revenue: 6800, orders: 68 },
  { month: "Aug", revenue: 8245, orders: 82 },
];

const categoryData = [
  { category: "Electronics", sales: 8240 },
  { category: "Clothing", sales: 6380 },
  { category: "Home", sales: 4920 },
  { category: "Beauty", sales: 3180 },
  { category: "Sports", sales: 2450 },
];

const recentSales = [
  {
    id: "#ORD-1001",
    customer: "Alex Morgan",
    product: "Wireless Headphones",
    category: "Electronics",
    amount: 249.99,
    date: "Aug 28, 2026",
  },
  {
    id: "#ORD-1002",
    customer: "Sophia Carter",
    product: "Premium Hoodie",
    category: "Clothing",
    amount: 129.5,
    date: "Aug 27, 2026",
  },
  {
    id: "#ORD-1003",
    customer: "Daniel Wilson",
    product: "Smart Watch",
    category: "Electronics",
    amount: 79.99,
    date: "Aug 26, 2026",
  },
  {
    id: "#ORD-1004",
    customer: "Emma Johnson",
    product: "Home Decor Set",
    category: "Home",
    amount: 349.0,
    date: "Aug 25, 2026",
  },
  {
    id: "#ORD-1005",
    customer: "Michael Brown",
    product: "Running Shoes",
    category: "Sports",
    amount: 189.75,
    date: "Aug 24, 2026",
  },
];

/* ================================================= */
/* SALES PAGE */
/* ================================================= */

const Sales = () => {
  const [period, setPeriod] = useState("This year");

  const totalRevenue = useMemo(
    () => salesData.reduce((total, item) => total + item.revenue, 0),
    [],
  );

  const totalOrders = useMemo(
    () => salesData.reduce((total, item) => total + item.orders, 0),
    [],
  );

  const averageOrderValue = totalRevenue / totalOrders;

  return (
    <div className="space-y-6">
      {/* ================================================= */}
      {/* PAGE HEADER */}
      {/* ================================================= */}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            Sales
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Monitor revenue, orders, and sales performance.
          </p>
        </div>

        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative">
            <select
              value={period}
              onChange={(event) => setPeriod(event.target.value)}
              className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-4 pr-9 text-sm font-medium text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 dark:focus:border-gray-300 sm:w-36">
              <option>This week</option>
              <option>This month</option>
              <option>This year</option>
            </select>

            <ChevronDown
              size={15}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
            />
          </div>

          <button
            type="button"
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white px-4 text-sm font-semibold text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
            <Download size={16} />
            Export
          </button>
        </div>
      </div>

      {/* ================================================= */}
      {/* STATS */}
      {/* ================================================= */}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <SummaryCard
          icon={<DollarSign size={16} />}
          label="Total revenue"
          value={`$${totalRevenue.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}`}
          change="+12.8%"
          positive
        />

        <SummaryCard
          icon={<ShoppingBag size={16} />}
          label="Total orders"
          value={totalOrders}
          change="+8.4%"
          positive
        />

        <SummaryCard
          icon={<TrendingUp size={16} />}
          label="Avg. order value"
          value={`$${averageOrderValue.toFixed(2)}`}
          change="+4.2%"
          positive
        />

        <SummaryCard
          icon={<BarChart3 size={16} />}
          label="Growth"
          value="18.6%"
          change="+2.1%"
          positive
        />
      </div>

      {/* ================================================= */}
      {/* REVENUE CHART */}
      {/* ================================================= */}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="flex flex-col gap-3 border-b border-gray-200 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          <div>
            <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
              Revenue overview
            </h2>

            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Monthly revenue performance
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
            <span className="h-2 w-2 rounded-full bg-gray-900 dark:bg-white" />
            Revenue
          </div>
        </div>

        <div className="h-[320px] w-full p-4 sm:p-5">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={salesData}
              margin={{
                top: 10,
                right: 10,
                left: -15,
                bottom: 0,
              }}>
              <defs>
                <linearGradient
                  id="revenueGradient"
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1">
                  <stop
                    offset="0%"
                    stopColor="currentColor"
                    stopOpacity={0.18}
                  />
                  <stop
                    offset="100%"
                    stopColor="currentColor"
                    stopOpacity={0}
                  />
                </linearGradient>
              </defs>

              <CartesianGrid
                vertical={false}
                strokeDasharray="3 3"
                className="stroke-gray-200 dark:stroke-gray-800"
              />

              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{
                  fontSize: 12,
                  fill: "currentColor",
                }}
                className="text-gray-400"
              />

              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{
                  fontSize: 12,
                  fill: "currentColor",
                }}
                className="text-gray-400"
                tickFormatter={(value) => `$${value / 1000}k`}
              />

              <Tooltip
                formatter={(value) => [
                  `$${Number(value).toLocaleString()}`,
                  "Revenue",
                ]}
                contentStyle={{
                  borderRadius: "10px",
                  border: "1px solid #e5e7eb",
                  backgroundColor: "#ffffff",
                  fontSize: "12px",
                }}
              />

              <Area
                type="monotone"
                dataKey="revenue"
                stroke="currentColor"
                strokeWidth={2}
                fill="url(#revenueGradient)"
                className="text-gray-900 dark:text-white"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ================================================= */}
      {/* LOWER SECTION */}
      {/* ================================================= */}

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-5">
        {/* ================================================= */}
        {/* CATEGORY SALES */}
        {/* ================================================= */}

        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white xl:col-span-2 dark:border-gray-800 dark:bg-gray-900">
          <div className="border-b border-gray-200 p-4 dark:border-gray-800">
            <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
              Sales by category
            </h2>

            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Revenue generated by category
            </p>
          </div>

          <div className="h-[320px] p-4 sm:p-5">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={categoryData}
                layout="vertical"
                margin={{
                  top: 0,
                  right: 10,
                  left: 10,
                  bottom: 0,
                }}>
                <CartesianGrid
                  horizontal={false}
                  strokeDasharray="3 3"
                  className="stroke-gray-200 dark:stroke-gray-800"
                />

                <XAxis
                  type="number"
                  axisLine={false}
                  tickLine={false}
                  tick={{
                    fontSize: 11,
                    fill: "currentColor",
                  }}
                  className="text-gray-400"
                  tickFormatter={(value) => `$${value / 1000}k`}
                />

                <YAxis
                  type="category"
                  dataKey="category"
                  axisLine={false}
                  tickLine={false}
                  width={75}
                  tick={{
                    fontSize: 11,
                    fill: "currentColor",
                  }}
                  className="text-gray-500 dark:text-gray-400"
                />

                <Tooltip
                  formatter={(value) => [
                    `$${Number(value).toLocaleString()}`,
                    "Sales",
                  ]}
                  contentStyle={{
                    borderRadius: "10px",
                    border: "1px solid #e5e7eb",
                    backgroundColor: "#ffffff",
                    fontSize: "12px",
                  }}
                />

                <Bar
                  dataKey="sales"
                  radius={[0, 5, 5, 0]}
                  fill="currentColor"
                  className="text-gray-900 dark:text-white"
                  barSize={20}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* ================================================= */}
        {/* RECENT SALES */}
        {/* ================================================= */}

        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white xl:col-span-3 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex flex-col gap-2 border-b border-gray-200 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
            <div>
              <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                Recent sales
              </h2>

              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Latest completed transactions
              </p>
            </div>

            <button
              type="button"
              className="text-xs font-semibold text-gray-600 transition hover:text-gray-950 dark:text-gray-400 dark:hover:text-white">
              View all
            </button>
          </div>

          {/* Desktop */}

          <div className="hidden overflow-x-auto md:block">
            <table className="w-full min-w-[650px]">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50/70 dark:border-gray-800 dark:bg-gray-950/40">
                  <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                    Customer
                  </th>

                  <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                    Product
                  </th>

                  <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                    Amount
                  </th>

                  <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                    Date
                  </th>
                </tr>
              </thead>

              <tbody>
                {recentSales.map((sale) => (
                  <tr
                    key={sale.id}
                    className="border-b border-gray-100 transition hover:bg-gray-50 last:border-b-0 dark:border-gray-800 dark:hover:bg-gray-800/40">
                    <td className="px-5 py-4">
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">
                          {sale.customer}
                        </p>

                        <p className="mt-0.5 text-xs text-gray-400">
                          {sale.id}
                        </p>
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          {sale.product}
                        </p>

                        <p className="mt-0.5 text-xs text-gray-400">
                          {sale.category}
                        </p>
                      </div>
                    </td>

                    <td className="px-5 py-4 text-sm font-semibold text-gray-900 dark:text-white">
                      ${sale.amount.toFixed(2)}
                    </td>

                    <td className="px-5 py-4 text-sm text-gray-500 dark:text-gray-400">
                      {sale.date}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile */}

          <div className="divide-y divide-gray-100 md:hidden dark:divide-gray-800">
            {recentSales.map((sale) => (
              <div key={sale.id} className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white">
                      {sale.customer}
                    </p>

                    <p className="mt-0.5 text-xs text-gray-400">{sale.id}</p>
                  </div>

                  <p className="shrink-0 text-sm font-bold text-gray-900 dark:text-white">
                    ${sale.amount.toFixed(2)}
                  </p>
                </div>

                <div className="mt-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-gray-600 dark:text-gray-300">
                      {sale.product}
                    </p>

                    <p className="mt-0.5 text-xs text-gray-400">
                      {sale.category}
                    </p>
                  </div>

                  <p className="shrink-0 text-xs text-gray-400">{sale.date}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-200 px-4 py-4 dark:border-gray-800">
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Showing latest{" "}
              <span className="font-medium text-gray-700 dark:text-gray-300">
                {recentSales.length}
              </span>{" "}
              sales
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ================================================= */
/* SUMMARY CARD */
/* ================================================= */

const SummaryCard = ({ icon, label, value, change, positive }) => {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
          {label}
        </p>

        <span className="text-gray-400">{icon}</span>
      </div>

      <div className="mt-2 flex items-end justify-between gap-2">
        <p className="text-xl font-bold text-gray-950 dark:text-white">
          {value}
        </p>

        <span
          className={`inline-flex items-center gap-0.5 text-xs font-semibold ${
            positive
              ? "text-gray-700 dark:text-gray-300"
              : "text-gray-500 dark:text-gray-400"
          }`}>
          {positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}

          {change}
        </span>
      </div>
    </div>
  );
};

export default Sales;
