import { useMemo, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  ChevronDown,
  Download,
  FileText,
  Package,
  ShoppingCart,
  Users,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

/* ================================================= */
/* MOCK DATA */
/* ================================================= */

const performanceData = [
  {
    month: "Jan",
    revenue: 4200,
    orders: 42,
    customers: 28,
  },
  {
    month: "Feb",
    revenue: 5100,
    orders: 51,
    customers: 34,
  },
  {
    month: "Mar",
    revenue: 4700,
    orders: 47,
    customers: 31,
  },
  {
    month: "Apr",
    revenue: 6200,
    orders: 62,
    customers: 40,
  },
  {
    month: "May",
    revenue: 5800,
    orders: 58,
    customers: 37,
  },
  {
    month: "Jun",
    revenue: 7100,
    orders: 71,
    customers: 46,
  },
  {
    month: "Jul",
    revenue: 6800,
    orders: 68,
    customers: 44,
  },
  {
    month: "Aug",
    revenue: 8245,
    orders: 82,
    customers: 53,
  },
];

const productPerformance = [
  {
    product: "Wireless Headphones",
    category: "Electronics",
    units: 128,
    revenue: 31998.72,
    growth: 18.4,
  },
  {
    product: "Premium Hoodie",
    category: "Clothing",
    units: 96,
    revenue: 12432.0,
    growth: 12.7,
  },
  {
    product: "Smart Watch",
    category: "Electronics",
    units: 84,
    revenue: 8399.16,
    growth: 9.8,
  },
  {
    product: "Home Decor Set",
    category: "Home",
    units: 71,
    revenue: 7455.0,
    growth: 7.2,
  },
  {
    product: "Running Shoes",
    category: "Sports",
    units: 63,
    revenue: 5985.0,
    growth: -2.4,
  },
];

const categoryPerformance = [
  {
    category: "Electronics",
    revenue: 8240,
    orders: 126,
  },
  {
    category: "Clothing",
    revenue: 6380,
    orders: 98,
  },
  {
    category: "Home",
    revenue: 4920,
    orders: 72,
  },
  {
    category: "Beauty",
    revenue: 3180,
    orders: 54,
  },
  {
    category: "Sports",
    revenue: 2450,
    orders: 41,
  },
];

/* ================================================= */
/* REPORTS PAGE */
/* ================================================= */

const Reports = () => {
  const [period, setPeriod] = useState("This year");

  const totalRevenue = useMemo(
    () => performanceData.reduce((total, item) => total + item.revenue, 0),
    [],
  );

  const totalOrders = useMemo(
    () => performanceData.reduce((total, item) => total + item.orders, 0),
    [],
  );

  const totalCustomers = useMemo(
    () => performanceData.reduce((total, item) => total + item.customers, 0),
    [],
  );

  const averageOrderValue = totalRevenue / totalOrders;

  return (
    <div className="space-y-6">
      {/* ================================================= */}
      {/* PAGE HEADER */}
      {/* ================================================= */}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            Reports
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Analyze business performance and generate reports.
          </p>
        </div>

        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative">
            <select
              value={period}
              onChange={(event) => setPeriod(event.target.value)}
              className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-4 pr-9 text-sm font-medium text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 dark:focus:border-gray-300 sm:w-36">
              <option>This week</option>
              <option>This month</option>
              <option>This year</option>
            </select>

            <ChevronDown
              size={15}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
            />
          </div>

          <button
            type="button"
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
            <Download size={16} />
            Export report
          </button>
        </div>
      </div>

      {/* ================================================= */}
      {/* SUMMARY STATS */}
      {/* ================================================= */}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <SummaryCard
          icon={<BarChart3 size={16} />}
          label="Total revenue"
          value={`$${totalRevenue.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}`}
          change="+12.8%"
          positive
        />

        <SummaryCard
          icon={<ShoppingCart size={16} />}
          label="Total orders"
          value={totalOrders}
          change="+8.4%"
          positive
        />

        <SummaryCard
          icon={<Users size={16} />}
          label="Customers"
          value={totalCustomers}
          change="+10.2%"
          positive
        />

        <SummaryCard
          icon={<FileText size={16} />}
          label="Avg. order"
          value={`$${averageOrderValue.toFixed(2)}`}
          change="+4.2%"
          positive
        />
      </div>

      {/* ================================================= */}
      {/* PERFORMANCE OVERVIEW */}
      {/* ================================================= */}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="flex flex-col gap-3 border-b border-gray-200 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          <div>
            <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
              Performance overview
            </h2>

            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Revenue, orders, and customer growth
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 dark:text-gray-400">
            <LegendItem
              label="Revenue"
              className="text-gray-950 dark:text-white"
            />

            <LegendItem label="Orders" />

            <LegendItem label="Customers" />
          </div>
        </div>

        <div className="h-[340px] w-full p-4 sm:p-5">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={performanceData}
              margin={{
                top: 10,
                right: 10,
                left: -15,
                bottom: 0,
              }}>
              <CartesianGrid
                vertical={false}
                strokeDasharray="3 3"
                className="stroke-gray-200 dark:stroke-gray-800"
              />

              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{
                  fontSize: 12,
                  fill: "currentColor",
                }}
                className="text-gray-400"
              />

              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{
                  fontSize: 12,
                  fill: "currentColor",
                }}
                className="text-gray-400"
                tickFormatter={(value) =>
                  value > 1000 ? `$${value / 1000}k` : value
                }
              />

              <Tooltip
                contentStyle={{
                  borderRadius: "10px",
                  border: "1px solid #e5e7eb",
                  backgroundColor: "#ffffff",
                  fontSize: "12px",
                }}
                formatter={(value, name) => {
                  if (name === "revenue") {
                    return [`$${Number(value).toLocaleString()}`, "Revenue"];
                  }

                  if (name === "orders") {
                    return [value, "Orders"];
                  }

                  return [value, "Customers"];
                }}
              />

              <Line
                type="monotone"
                dataKey="revenue"
                stroke="currentColor"
                strokeWidth={2.5}
                dot={false}
                className="text-gray-950 dark:text-white"
              />

              <Line
                type="monotone"
                dataKey="orders"
                stroke="currentColor"
                strokeWidth={2}
                dot={false}
                strokeDasharray="5 5"
                className="text-gray-500 dark:text-gray-400"
              />

              <Line
                type="monotone"
                dataKey="customers"
                stroke="currentColor"
                strokeWidth={2}
                dot={false}
                strokeDasharray="2 4"
                className="text-gray-300 dark:text-gray-600"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ================================================= */}
      {/* CATEGORY REPORT */}
      {/* ================================================= */}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="border-b border-gray-200 p-4 dark:border-gray-800">
          <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
            Category performance
          </h2>

          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
            Revenue and orders by product category
          </p>
        </div>

        <div className="hidden overflow-x-auto md:block">
          <table className="w-full min-w-[650px]">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50/70 dark:border-gray-800 dark:bg-gray-950/40">
                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Category
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Revenue
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Orders
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Performance
                </th>
              </tr>
            </thead>

            <tbody>
              {categoryPerformance.map((category) => (
                <tr
                  key={category.category}
                  className="border-b border-gray-100 transition hover:bg-gray-50 last:border-b-0 dark:border-gray-800 dark:hover:bg-gray-800/40">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                        <Package size={16} />
                      </div>

                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {category.category}
                      </p>
                    </div>
                  </td>

                  <td className="px-5 py-4 text-sm font-semibold text-gray-900 dark:text-white">
                    ${category.revenue.toLocaleString()}
                  </td>

                  <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                    {category.orders}
                  </td>

                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="h-2 w-24 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
                        <div
                          className="h-full rounded-full bg-gray-900 dark:bg-white"
                          style={{
                            width: `${Math.min(
                              (category.revenue / 8240) * 100,
                              100,
                            )}%`,
                          }}
                        />
                      </div>

                      <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                        {Math.round((category.revenue / 8240) * 100)}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile */}

        <div className="divide-y divide-gray-100 md:hidden dark:divide-gray-800">
          {categoryPerformance.map((category) => (
            <div key={category.category} className="p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                    <Package size={16} />
                  </div>

                  <p className="text-sm font-semibold text-gray-900 dark:text-white">
                    {category.category}
                  </p>
                </div>

                <p className="text-sm font-bold text-gray-900 dark:text-white">
                  ${category.revenue.toLocaleString()}
                </p>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div>
                  <p className="text-[11px] uppercase tracking-wide text-gray-400">
                    Orders
                  </p>

                  <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                    {category.orders}
                  </p>
                </div>

                <div className="text-right">
                  <p className="text-[11px] uppercase tracking-wide text-gray-400">
                    Share
                  </p>

                  <p className="mt-1 text-sm font-medium text-gray-600 dark:text-gray-300">
                    {Math.round((category.revenue / 8240) * 100)}%
                  </p>
                </div>
              </div>

              <div className="mt-3 h-2 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
                <div
                  className="h-full rounded-full bg-gray-900 dark:bg-white"
                  style={{
                    width: `${Math.min((category.revenue / 8240) * 100, 100)}%`,
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-200 px-4 py-4 dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Showing{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {categoryPerformance.length}
            </span>{" "}
            categories
          </p>
        </div>
      </div>

      {/* ================================================= */}
      {/* PRODUCT PERFORMANCE */}
      {/* ================================================= */}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="flex flex-col gap-2 border-b border-gray-200 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          <div>
            <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
              Product performance
            </h2>

            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Top performing products
            </p>
          </div>

          <button
            type="button"
            className="inline-flex items-center gap-1 text-xs font-semibold text-gray-600 transition hover:text-gray-950 dark:text-gray-400 dark:hover:text-white">
            View all
            <ArrowUpRight size={13} />
          </button>
        </div>

        {/* Desktop */}

        <div className="hidden overflow-x-auto md:block">
          <table className="w-full min-w-[750px]">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50/70 dark:border-gray-800 dark:bg-gray-950/40">
                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Product
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Category
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Units sold
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Revenue
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Growth
                </th>
              </tr>
            </thead>

            <tbody>
              {productPerformance.map((product) => (
                <tr
                  key={product.product}
                  className="border-b border-gray-100 transition hover:bg-gray-50 last:border-b-0 dark:border-gray-800 dark:hover:bg-gray-800/40">
                  <td className="px-5 py-4">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {product.product}
                    </p>
                  </td>

                  <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                    {product.category}
                  </td>

                  <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                    {product.units}
                  </td>

                  <td className="px-5 py-4 text-sm font-semibold text-gray-900 dark:text-white">
                    ${product.revenue.toLocaleString()}
                  </td>

                  <td className="px-5 py-4">
                    <GrowthBadge value={product.growth} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile */}

        <div className="divide-y divide-gray-100 md:hidden dark:divide-gray-800">
          {productPerformance.map((product) => (
            <div key={product.product} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                    {product.product}
                  </p>

                  <p className="mt-0.5 text-xs text-gray-400">
                    {product.category}
                  </p>
                </div>

                <GrowthBadge value={product.growth} />
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[11px] uppercase tracking-wide text-gray-400">
                    Units sold
                  </p>

                  <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                    {product.units}
                  </p>
                </div>

                <div>
                  <p className="text-[11px] uppercase tracking-wide text-gray-400">
                    Revenue
                  </p>

                  <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                    ${product.revenue.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}

        <div className="border-t border-gray-200 px-4 py-4 dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Showing top{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {productPerformance.length}
            </span>{" "}
            products
          </p>
        </div>
      </div>
    </div>
  );
};

/* ================================================= */
/* SUMMARY CARD */
/* ================================================= */

const SummaryCard = ({ icon, label, value, change, positive }) => {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
          {label}
        </p>

        <span className="text-gray-400">{icon}</span>
      </div>

      <div className="mt-2 flex items-end justify-between gap-2">
        <p className="text-xl font-bold text-gray-950 dark:text-white">
          {value}
        </p>

        <span
          className={`inline-flex items-center gap-0.5 text-xs font-semibold ${
            positive
              ? "text-gray-700 dark:text-gray-300"
              : "text-gray-500 dark:text-gray-400"
          }`}>
          {positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}

          {change}
        </span>
      </div>
    </div>
  );
};

/* ================================================= */
/* LEGEND ITEM */
/* ================================================= */

const LegendItem = ({ label, className = "" }) => {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span
        className={`h-2 w-2 rounded-full bg-gray-400 dark:bg-gray-500 ${className}`}
      />

      {label}
    </span>
  );
};

/* ================================================= */
/* GROWTH BADGE */
/* ================================================= */

const GrowthBadge = ({ value }) => {
  const positive = value >= 0;

  return (
    <span
      className={`inline-flex items-center gap-0.5 text-xs font-semibold ${
        positive
          ? "text-gray-700 dark:text-gray-300"
          : "text-gray-500 dark:text-gray-400"
      }`}>
      {positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
      {Math.abs(value)}%
    </span>
  );
};

export default Reports;
