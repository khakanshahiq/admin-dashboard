import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Check,
  Circle,
  Clock3,
  MapPin,
  Package,
  Truck,
  User,
} from "lucide-react";

const ordersData = [
  {
    id: "#ORD-1001",
    customer: "Alex Morgan",
    email: "alex.morgan@example.com",
    phone: "+1 202 555 0147",
    amount: 249.99,
    status: "Delivered",
    payment: "Paid",
    date: "Aug 28, 2026",
    trackingNumber: "TRK-784512963",
    estimatedDelivery: "Aug 31, 2026",
    shippingAddress: "123 Main Street, New York, NY 10001",
  },
  {
    id: "#ORD-1002",
    customer: "Sophia Carter",
    email: "sophia.carter@example.com",
    phone: "+1 202 555 0182",
    amount: 129.5,
    status: "Processing",
    payment: "Paid",
    date: "Aug 27, 2026",
    trackingNumber: "TRK-784512964",
    estimatedDelivery: "Sep 02, 2026",
    shippingAddress: "45 Park Avenue, New York, NY 10002",
  },
  {
    id: "#ORD-1003",
    customer: "Daniel Wilson",
    email: "daniel.wilson@example.com",
    phone: "+1 202 555 0116",
    amount: 79.99,
    status: "Shipped",
    payment: "Paid",
    date: "Aug 26, 2026",
    trackingNumber: "TRK-784512965",
    estimatedDelivery: "Sep 01, 2026",
    shippingAddress: "88 Madison Avenue, New York, NY 10003",
  },
  {
    id: "#ORD-1004",
    customer: "Emma Johnson",
    email: "emma.johnson@example.com",
    phone: "+1 202 555 0194",
    amount: 349.0,
    status: "Pending",
    payment: "Pending",
    date: "Aug 25, 2026",
    trackingNumber: "TRK-784512966",
    estimatedDelivery: "Sep 04, 2026",
    shippingAddress: "72 Broadway, New York, NY 10004",
  },
  {
    id: "#ORD-1005",
    customer: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "+1 202 555 0163",
    amount: 189.75,
    status: "Delivered",
    payment: "Paid",
    date: "Aug 24, 2026",
    trackingNumber: "TRK-784512967",
    estimatedDelivery: "Aug 29, 2026",
    shippingAddress: "19 West Street, New York, NY 10005",
  },
  {
    id: "#ORD-1006",
    customer: "Olivia Davis",
    email: "olivia.davis@example.com",
    phone: "+1 202 555 0135",
    amount: 499.99,
    status: "Cancelled",
    payment: "Refunded",
    date: "Aug 23, 2026",
    trackingNumber: "TRK-784512968",
    estimatedDelivery: "Cancelled",
    shippingAddress: "54 Lexington Avenue, New York, NY 10006",
  },
  {
    id: "#ORD-1007",
    customer: "James Miller",
    email: "james.miller@example.com",
    phone: "+1 202 555 0171",
    amount: 59.99,
    status: "Processing",
    payment: "Paid",
    date: "Aug 22, 2026",
    trackingNumber: "TRK-784512969",
    estimatedDelivery: "Sep 03, 2026",
    shippingAddress: "91 Lexington Avenue, New York, NY 10007",
  },
  {
    id: "#ORD-1008",
    customer: "Isabella Moore",
    email: "isabella.moore@example.com",
    phone: "+1 202 555 0128",
    amount: 219.25,
    status: "Shipped",
    payment: "Paid",
    date: "Aug 21, 2026",
    trackingNumber: "TRK-784512970",
    estimatedDelivery: "Aug 30, 2026",
    shippingAddress: "31 5th Avenue, New York, NY 10008",
  },
  {
    id: "#ORD-1009",
    customer: "Noah Taylor",
    email: "noah.taylor@example.com",
    phone: "+1 202 555 0109",
    amount: 145.0,
    status: "Delivered",
    payment: "Paid",
    date: "Aug 20, 2026",
    trackingNumber: "TRK-784512971",
    estimatedDelivery: "Aug 25, 2026",
    shippingAddress: "14 Hudson Street, New York, NY 10009",
  },
  {
    id: "#ORD-1010",
    customer: "Ava Anderson",
    email: "ava.anderson@example.com",
    phone: "+1 202 555 0158",
    amount: 89.99,
    status: "Pending",
    payment: "Pending",
    date: "Aug 19, 2026",
    trackingNumber: "TRK-784512972",
    estimatedDelivery: "Sep 05, 2026",
    shippingAddress: "67 East 10th Street, New York, NY 10010",
  },
];

const trackingSteps = [
  {
    title: "Order Placed",
    description: "Your order has been placed successfully.",
    icon: Package,
  },
  {
    title: "Processing",
    description: "Your order is being prepared.",
    icon: Clock3,
  },
  {
    title: "Shipped",
    description: "Your package has left the warehouse.",
    icon: Truck,
  },
  {
    title: "Out for Delivery",
    description: "Your package is on its way to you.",
    icon: MapPin,
  },
  {
    title: "Delivered",
    description: "Your package has been delivered.",
    icon: Check,
  },
];

const statusIndex = {
  Pending: 0,
  Processing: 1,
  Shipped: 2,
  Delivered: 4,
  Cancelled: -1,
};

const OrderTracking = () => {
  const { id } = useParams();

  const order = useMemo(() => {
    return ordersData.find((item) => item.id.replace("#", "") === id);
  }, [id]);

  if (!order) {
    return (
      <div className="flex min-h-[500px] items-center justify-center">
        <div className="text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-gray-100 text-gray-400 dark:bg-gray-800">
            <Package size={24} />
          </div>

          <h1 className="mt-4 text-lg font-semibold text-gray-950 dark:text-white">
            Order not found
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            The order you are trying to track does not exist.
          </p>

          <Link
            to="/admin/orders"
            className="mt-5 inline-flex h-10 items-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
            <ArrowLeft size={16} />
            Back to Orders
          </Link>
        </div>
      </div>
    );
  }

  const currentStep = statusIndex[order.status];

  return (
    <div className="space-y-6">
      {/* PAGE HEADER */}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <Link
            to="/admin/orders"
            className="inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">
            <ArrowLeft size={16} />
            Back to Orders
          </Link>

          <h1 className="mt-3 text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            Track Order
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Track the fulfillment progress of {order.id}.
          </p>
        </div>

        <div className="inline-flex w-fit items-center rounded-full bg-gray-100 px-3 py-1.5 text-xs font-semibold text-gray-700 dark:bg-gray-800 dark:text-gray-300">
          {order.status}
        </div>
      </div>

      {/* ORDER SUMMARY */}

      <div className="grid gap-4 md:grid-cols-3">
        <InfoCard
          icon={<Package size={18} />}
          label="Order"
          value={order.id}
          description={`Placed on ${order.date}`}
        />

        <InfoCard
          icon={<Truck size={18} />}
          label="Tracking number"
          value={order.trackingNumber}
          description="Carrier tracking reference"
        />

        <InfoCard
          icon={<MapPin size={18} />}
          label="Estimated delivery"
          value={order.estimatedDelivery}
          description="Expected delivery date"
        />
      </div>

      {/* TRACKING + CUSTOMER */}

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        {/* TRACKING TIMELINE */}

        <div className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
          <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
            <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
              Shipment progress
            </h2>

            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Follow the current status of your order.
            </p>
          </div>

          <div className="p-5 sm:p-6">
            {order.status === "Cancelled" ? (
              <div className="rounded-xl border border-gray-200 bg-gray-50 p-5 dark:border-gray-700 dark:bg-gray-950">
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gray-200 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                    <Package size={18} />
                  </div>

                  <div>
                    <p className="text-sm font-semibold text-gray-900 dark:text-white">
                      Order cancelled
                    </p>

                    <p className="mt-1 text-sm leading-6 text-gray-500 dark:text-gray-400">
                      This order was cancelled and the payment has been
                      refunded.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                {trackingSteps.map((step, index) => {
                  const Icon = step.icon;
                  const completed = index <= currentStep;
                  const active = index === currentStep;

                  return (
                    <div
                      key={step.title}
                      className="relative flex gap-4 pb-8 last:pb-0">
                      {/* CONNECTOR */}

                      {index < trackingSteps.length - 1 && (
                        <div
                          className={`absolute left-5 top-10 h-[calc(100%-16px)] w-px ${
                            index < currentStep
                              ? "bg-gray-950 dark:bg-white"
                              : "bg-gray-200 dark:bg-gray-700"
                          }`}
                        />
                      )}

                      {/* ICON */}

                      <div
                        className={`relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border ${
                          completed
                            ? "border-gray-950 bg-gray-950 text-white dark:border-white dark:bg-white dark:text-gray-950"
                            : "border-gray-200 bg-white text-gray-400 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-600"
                        }`}>
                        {completed ? <Icon size={17} /> : <Circle size={10} />}
                      </div>

                      {/* CONTENT */}

                      <div className="pt-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p
                            className={`text-sm font-semibold ${
                              completed
                                ? "text-gray-950 dark:text-white"
                                : "text-gray-400 dark:text-gray-500"
                            }`}>
                            {step.title}
                          </p>

                          {active && (
                            <span className="rounded-full bg-gray-100 px-2 py-0.5 text-[10px] font-semibold text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                              Current
                            </span>
                          )}
                        </div>

                        <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
                          {step.description}
                        </p>

                        {completed && (
                          <p className="mt-2 text-[11px] font-medium text-gray-400">
                            Completed
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* CUSTOMER / SHIPPING */}

        <div className="space-y-6">
          {/* CUSTOMER */}

          <div className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                Customer
              </h2>
            </div>

            <div className="p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                  <User size={18} />
                </div>

                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                    {order.customer}
                  </p>

                  <p className="mt-0.5 truncate text-xs text-gray-500 dark:text-gray-400">
                    {order.email}
                  </p>
                </div>
              </div>

              <div className="mt-5 border-t border-gray-100 pt-4 dark:border-gray-800">
                <p className="text-[11px] font-medium uppercase tracking-wide text-gray-400">
                  Phone
                </p>

                <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                  {order.phone}
                </p>
              </div>
            </div>
          </div>

          {/* SHIPPING ADDRESS */}

          <div className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                Shipping address
              </h2>
            </div>

            <div className="p-5">
              <div className="flex items-start gap-3">
                <MapPin size={18} className="mt-0.5 shrink-0 text-gray-400" />

                <p className="text-sm leading-6 text-gray-600 dark:text-gray-300">
                  {order.shippingAddress}
                </p>
              </div>
            </div>
          </div>

          {/* PAYMENT */}

          <div className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-950 dark:text-white">
                Payment
              </h2>
            </div>

            <div className="flex items-center justify-between p-5">
              <div>
                <p className="text-xs text-gray-400">Total amount</p>

                <p className="mt-1 text-lg font-bold text-gray-950 dark:text-white">
                  ${order.amount.toFixed(2)}
                </p>
              </div>

              <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-medium text-gray-700 dark:bg-gray-800 dark:text-gray-300">
                {order.payment}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ================================================= */
/* INFO CARD */
/* ================================================= */

const InfoCard = ({ icon, label, value, description }) => {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-start gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
          {icon}
        </div>

        <div className="min-w-0">
          <p className="text-xs font-medium text-gray-400">{label}</p>

          <p className="mt-1 truncate text-sm font-semibold text-gray-950 dark:text-white">
            {value}
          </p>

          <p className="mt-1 text-[11px] text-gray-400">{description}</p>
        </div>
      </div>
    </div>
  );
};

export default OrderTracking;
