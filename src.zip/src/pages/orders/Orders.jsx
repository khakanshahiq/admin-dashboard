import { useMemo, useState } from "react";
import {
  ChevronDown,
  MoreHorizontal,
  PackageCheck,
  Search,
  ShoppingCart,
  Clock3,
  DollarSign,
  X,
  Trash2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const ordersData = [
  {
    id: "#ORD-1001",
    customer: "Alex Morgan",
    email: "alex.morgan@example.com",
    items: 3,
    amount: 249.99,
    status: "Delivered",
    payment: "Paid",
    date: "Aug 28, 2026",
  },
  {
    id: "#ORD-1002",
    customer: "Sophia Carter",
    email: "sophia.carter@example.com",
    items: 2,
    amount: 129.5,
    status: "Processing",
    payment: "Paid",
    date: "Aug 27, 2026",
  },
  {
    id: "#ORD-1003",
    customer: "Daniel Wilson",
    email: "daniel.wilson@example.com",
    items: 1,
    amount: 79.99,
    status: "Shipped",
    payment: "Paid",
    date: "Aug 26, 2026",
  },
  {
    id: "#ORD-1004",
    customer: "Emma Johnson",
    email: "emma.johnson@example.com",
    items: 4,
    amount: 349.0,
    status: "Pending",
    payment: "Pending",
    date: "Aug 25, 2026",
  },
  {
    id: "#ORD-1005",
    customer: "Michael Brown",
    email: "michael.brown@example.com",
    items: 2,
    amount: 189.75,
    status: "Delivered",
    payment: "Paid",
    date: "Aug 24, 2026",
  },
  {
    id: "#ORD-1006",
    customer: "Olivia Davis",
    email: "olivia.davis@example.com",
    items: 5,
    amount: 499.99,
    status: "Cancelled",
    payment: "Refunded",
    date: "Aug 23, 2026",
  },
  {
    id: "#ORD-1007",
    customer: "James Miller",
    email: "james.miller@example.com",
    items: 1,
    amount: 59.99,
    status: "Processing",
    payment: "Paid",
    date: "Aug 22, 2026",
  },
  {
    id: "#ORD-1008",
    customer: "Isabella Moore",
    email: "isabella.moore@example.com",
    items: 3,
    amount: 219.25,
    status: "Shipped",
    payment: "Paid",
    date: "Aug 21, 2026",
  },
  {
    id: "#ORD-1009",
    customer: "Noah Taylor",
    email: "noah.taylor@example.com",
    items: 2,
    amount: 145.0,
    status: "Delivered",
    payment: "Paid",
    date: "Aug 20, 2026",
  },
  {
    id: "#ORD-1010",
    customer: "Ava Anderson",
    email: "ava.anderson@example.com",
    items: 1,
    amount: 89.99,
    status: "Pending",
    payment: "Pending",
    date: "Aug 19, 2026",
  },
];

const statusStyles = {
  Delivered: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",

  Processing: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",

  Shipped: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300",

  Pending: "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400",

  Cancelled: "bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-400",
};

const paymentStyles = {
  Paid: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",

  Pending: "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400",

  Refunded: "bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-400",
};

const Orders = () => {
  const navigate = useNavigate();

  /* =============================== */
  /* STATE */
  /* =============================== */

  const [orders, setOrders] = useState(ordersData);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [paymentFilter, setPaymentFilter] = useState("All");
  const [openMenu, setOpenMenu] = useState(null);

  // Selected order for cancellation
  const [cancelOrder, setCancelOrder] = useState(null);

  /* =============================== */
  /* FILTER OPTIONS */
  /* =============================== */

  const statuses = [
    "All",
    "Pending",
    "Processing",
    "Shipped",
    "Delivered",
    "Cancelled",
  ];

  const payments = ["All", "Paid", "Pending", "Refunded"];

  /* =============================== */
  /* FILTERED ORDERS */
  /* =============================== */

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const searchValue = search.toLowerCase().trim();

      const matchesSearch =
        order.id.toLowerCase().includes(searchValue) ||
        order.customer.toLowerCase().includes(searchValue) ||
        order.email.toLowerCase().includes(searchValue);

      const matchesStatus =
        statusFilter === "All" || order.status === statusFilter;

      const matchesPayment =
        paymentFilter === "All" || order.payment === paymentFilter;

      return matchesSearch && matchesStatus && matchesPayment;
    });
  }, [orders, search, statusFilter, paymentFilter]);

  /* =============================== */
  /* STATISTICS */
  /* =============================== */

  const totalOrders = orders.length;

  const deliveredOrders = orders.filter(
    (order) => order.status === "Delivered",
  ).length;

  const processingOrders = orders.filter(
    (order) => order.status === "Processing",
  ).length;

  const revenue = orders
    .filter((order) => order.payment === "Paid")
    .reduce((total, order) => total + order.amount, 0);

  /* =============================== */
  /* FILTER STATE */
  /* =============================== */

  const hasFilters =
    search || statusFilter !== "All" || paymentFilter !== "All";

  const clearFilters = () => {
    setSearch("");
    setStatusFilter("All");
    setPaymentFilter("All");
  };

  /* =============================== */
  /* VIEW ORDER */
  /* =============================== */

  const handleViewOrder = (orderId) => {
    setOpenMenu(null);

    const cleanId = orderId.replace("#", "");

    navigate(`/admin/orders/${cleanId}`);
  };

  /* =============================== */
  /* NEW ORDER */
  /* =============================== */

  const handleNewOrder = () => {
    navigate("/admin/orders/add");
  };

  /* =============================== */
  /* EDIT ORDER */
  /* =============================== */

  const handleEditOrder = (orderId) => {
    setOpenMenu(null);

    const cleanId = orderId.replace("#", "");

    navigate(`/admin/order/${cleanId}/edit`);
  };

  /* =============================== */
  /* TRACK ORDER */
  /* =============================== */

  const handleTrackOrder = (orderId) => {
    setOpenMenu(null);

    const cleanId = orderId.replace("#", "");

    navigate(`/admin/order/${cleanId}/track`);
  };

  /* =============================== */
  /* OPEN CANCEL MODAL */
  /* =============================== */

  const handleCancelOrder = (orderId) => {
    setOpenMenu(null);

    const selectedOrder = orders.find((order) => order.id === orderId);

    if (!selectedOrder) {
      return;
    }

    // Don't allow cancelling an already cancelled order
    if (selectedOrder.status === "Cancelled") {
      return;
    }

    setCancelOrder(selectedOrder);
  };

  /* =============================== */
  /* CONFIRM CANCEL */
  /* =============================== */

  const confirmCancelOrder = () => {
    if (!cancelOrder) {
      return;
    }

    setOrders((currentOrders) =>
      currentOrders.map((order) =>
        order.id === cancelOrder.id
          ? {
              ...order,
              status: "Cancelled",
              payment: "Refunded",
            }
          : order,
      ),
    );

    setCancelOrder(null);
    setOpenMenu(null);
  };

  return (
    <div className="space-y-6">
      {/* =============================== */}
      {/* PAGE HEADER */}
      {/* =============================== */}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            Orders
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Track orders, payments, and fulfillment status.
          </p>
        </div>

        <button
          type="button"
          onClick={handleNewOrder}
          className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
          <ShoppingCart size={17} />
          New Order
        </button>
      </div>

      {/* =============================== */}
      {/* STATS */}
      {/* =============================== */}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <SummaryCard
          icon={<ShoppingCart size={16} />}
          label="Total orders"
          value={totalOrders}
        />

        <SummaryCard
          icon={<PackageCheck size={16} />}
          label="Delivered"
          value={deliveredOrders}
        />

        <SummaryCard
          icon={<Clock3 size={16} />}
          label="Processing"
          value={processingOrders}
        />

        <SummaryCard
          icon={<DollarSign size={16} />}
          label="Revenue"
          value={`$${revenue.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}`}
        />
      </div>

      {/* =============================== */}
      {/* MAIN CARD */}
      {/* =============================== */}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        {/* =============================== */}
        {/* TOOLBAR */}
        {/* =============================== */}

        <div className="flex flex-col gap-3 border-b border-gray-200 p-4 dark:border-gray-800 lg:flex-row lg:items-center lg:justify-between">
          {/* SEARCH */}

          <div className="relative w-full lg:max-w-sm">
            <Search
              size={17}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
            />

            <input
              type="text"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search orders..."
              className="h-10 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-4 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
            />
          </div>

          {/* FILTERS */}

          <div className="flex flex-col gap-2 sm:flex-row">
            {/* STATUS */}

            <div className="relative">
              <select
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
                className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-4 pr-9 text-sm text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 sm:w-40">
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status === "All" ? "All statuses" : status}
                  </option>
                ))}
              </select>

              <ChevronDown
                size={15}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
            </div>

            {/* PAYMENT */}

            <div className="relative">
              <select
                value={paymentFilter}
                onChange={(event) => setPaymentFilter(event.target.value)}
                className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-4 pr-9 text-sm text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 sm:w-36">
                {payments.map((payment) => (
                  <option key={payment} value={payment}>
                    {payment === "All" ? "All payments" : payment}
                  </option>
                ))}
              </select>

              <ChevronDown
                size={15}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
            </div>

            {/* CLEAR */}

            {hasFilters && (
              <button
                type="button"
                onClick={clearFilters}
                className="h-10 rounded-lg border border-gray-200 px-4 text-sm font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white">
                Clear
              </button>
            )}
          </div>
        </div>

        {/* =============================== */}
        {/* RESULTS INFO */}
        {/* =============================== */}

        <div className="border-b border-gray-200 px-4 py-3 dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Showing{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {filteredOrders.length}
            </span>{" "}
            of{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {orders.length}
            </span>{" "}
            orders
          </p>
        </div>

        {/* =============================== */}
        {/* DESKTOP TABLE */}
        {/* =============================== */}

        <div className="hidden overflow-x-auto md:block">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50/70 dark:border-gray-800 dark:bg-gray-950/40">
                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Order
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Customer
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Items
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Amount
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Status
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Payment
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Date
                </th>

                <th className="w-16 px-5 py-3.5"></th>
              </tr>
            </thead>

            <tbody>
              {filteredOrders.length > 0 ? (
                filteredOrders.map((order) => (
                  <tr
                    key={order.id}
                    className="border-b border-gray-100 transition hover:bg-gray-50 last:border-b-0 dark:border-gray-800 dark:hover:bg-gray-800/40">
                    {/* ORDER */}

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                          <PackageCheck size={18} />
                        </div>

                        <div>
                          <p className="text-sm font-semibold text-gray-900 dark:text-white">
                            {order.id}
                          </p>

                          <p className="mt-0.5 text-xs text-gray-400">Order</p>
                        </div>
                      </div>
                    </td>

                    {/* CUSTOMER */}

                    <td className="px-5 py-4">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-gray-900 dark:text-white">
                          {order.customer}
                        </p>

                        <p className="mt-0.5 truncate text-xs text-gray-400">
                          {order.email}
                        </p>
                      </div>
                    </td>

                    {/* ITEMS */}

                    <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                      {order.items} {order.items === 1 ? "item" : "items"}
                    </td>

                    {/* AMOUNT */}

                    <td className="px-5 py-4 text-sm font-semibold text-gray-900 dark:text-white">
                      ${order.amount.toFixed(2)}
                    </td>

                    {/* STATUS */}

                    <td className="px-5 py-4">
                      <OrderStatusBadge status={order.status} />
                    </td>

                    {/* PAYMENT */}

                    <td className="px-5 py-4">
                      <PaymentBadge payment={order.payment} />
                    </td>

                    {/* DATE */}

                    <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                      {order.date}
                    </td>

                    {/* ACTION */}

                    <td className="relative px-5 py-4 text-right">
                      <button
                        type="button"
                        onClick={() =>
                          setOpenMenu(openMenu === order.id ? null : order.id)
                        }
                        className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                        aria-label={`Actions for ${order.id}`}>
                        <MoreHorizontal size={18} />
                      </button>

                      {openMenu === order.id && (
                        <ActionMenu
                          order={order}
                          onView={handleViewOrder}
                          onEdit={handleEditOrder}
                          onTrack={handleTrackOrder}
                          onCancel={handleCancelOrder}
                        />
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="px-5 py-14 text-center">
                    <PackageCheck
                      size={28}
                      className="mx-auto text-gray-300 dark:text-gray-600"
                    />

                    <p className="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
                      No orders found
                    </p>

                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      Try changing your search or filters.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* =============================== */}
        {/* MOBILE CARDS */}
        {/* =============================== */}

        <div className="divide-y divide-gray-100 md:hidden dark:divide-gray-800">
          {filteredOrders.length > 0 ? (
            filteredOrders.map((order) => (
              <div key={order.id} className="p-4">
                {/* MOBILE HEADER */}

                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                      <PackageCheck size={18} />
                    </div>

                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-gray-900 dark:text-white">
                        {order.id}
                      </p>

                      <p className="mt-0.5 truncate text-xs text-gray-400">
                        {order.customer}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      setOpenMenu(openMenu === order.id ? null : order.id)
                    }
                    className="shrink-0 rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                    aria-label={`Actions for ${order.id}`}>
                    <MoreHorizontal size={18} />
                  </button>
                </div>

                {/* MOBILE INFORMATION */}

                <div className="mt-4 grid grid-cols-2 gap-4">
                  {/* AMOUNT */}

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Amount
                    </p>

                    <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                      ${order.amount.toFixed(2)}
                    </p>
                  </div>

                  {/* ITEMS */}

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Items
                    </p>

                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                      {order.items} {order.items === 1 ? "item" : "items"}
                    </p>
                  </div>

                  {/* STATUS */}

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Status
                    </p>

                    <div className="mt-1.5">
                      <OrderStatusBadge status={order.status} />
                    </div>
                  </div>

                  {/* PAYMENT */}

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Payment
                    </p>

                    <div className="mt-1.5">
                      <PaymentBadge payment={order.payment} />
                    </div>
                  </div>

                  {/* EMAIL */}

                  <div className="min-w-0">
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Email
                    </p>

                    <p className="mt-1 truncate text-sm text-gray-600 dark:text-gray-400">
                      {order.email}
                    </p>
                  </div>

                  {/* DATE */}

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Date
                    </p>

                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                      {order.date}
                    </p>
                  </div>
                </div>

                {/* MOBILE ACTIONS */}

                {openMenu === order.id && (
                  <div className="mt-4 grid grid-cols-2 gap-2 border-t border-gray-100 pt-3 dark:border-gray-800">
                    {/* VIEW */}

                    <button
                      type="button"
                      onClick={() => handleViewOrder(order.id)}
                      className="rounded-lg border border-gray-200 px-3 py-2.5 text-xs font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white">
                      View
                    </button>

                    {/* EDIT */}

                    <button
                      type="button"
                      onClick={() => handleEditOrder(order.id)}
                      className="rounded-lg border border-gray-200 px-3 py-2.5 text-xs font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white">
                      Edit
                    </button>

                    {/* TRACK */}

                    <button
                      type="button"
                      onClick={() => handleTrackOrder(order.id)}
                      className="rounded-lg border border-gray-200 px-3 py-2.5 text-xs font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white">
                      Track
                    </button>

                    {/* CANCEL */}

                    {order.status !== "Cancelled" ? (
                      <button
                        type="button"
                        onClick={() => handleCancelOrder(order.id)}
                        className="rounded-lg border border-red-200 px-3 py-2.5 text-xs font-medium text-red-500 transition hover:bg-red-50 dark:border-red-900/50 dark:hover:bg-red-950/30">
                        Cancel
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled
                        className="cursor-not-allowed rounded-lg border border-gray-200 px-3 py-2.5 text-xs font-medium text-gray-400 dark:border-gray-700 dark:text-gray-600">
                        Cancelled
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="px-5 py-14 text-center">
              <PackageCheck
                size={28}
                className="mx-auto text-gray-300 dark:text-gray-600"
              />

              <p className="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
                No orders found
              </p>

              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Try changing your search or filters.
              </p>
            </div>
          )}
        </div>

        {/* =============================== */}
        {/* FOOTER / PAGINATION */}
        {/* =============================== */}

        <div className="flex flex-col gap-3 border-t border-gray-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Showing{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {filteredOrders.length}
            </span>{" "}
            of{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {orders.length}
            </span>{" "}
            orders
          </p>

          <div className="flex items-center gap-1">
            <button
              type="button"
              disabled
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-400 dark:border-gray-700">
              Previous
            </button>

            <button
              type="button"
              className="rounded-lg bg-gray-950 px-3 py-2 text-xs font-semibold text-white dark:bg-white dark:text-gray-950">
              1
            </button>

            <button
              type="button"
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
              2
            </button>

            <button
              type="button"
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
              Next
            </button>
          </div>
        </div>
      </div>

      {/* =============================== */}
      {/* CANCEL ORDER MODAL */}
      {/* =============================== */}

      {cancelOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white shadow-2xl dark:border-gray-800 dark:bg-gray-900">
            {/* MODAL HEADER */}

            <div className="flex items-start justify-between gap-4 p-6">
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-300">
                  <Trash2 size={20} />
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                    Cancel order?
                  </h2>

                  <p className="mt-1 text-sm leading-5 text-gray-500 dark:text-gray-400">
                    Are you sure you want to cancel{" "}
                    <span className="font-medium text-gray-800 dark:text-gray-200">
                      {cancelOrder.id}
                    </span>{" "}
                    for{" "}
                    <span className="font-medium text-gray-800 dark:text-gray-200">
                      {cancelOrder.customer}
                    </span>
                    ?
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCancelOrder(null)}
                className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                aria-label="Close cancel confirmation">
                <X size={18} />
              </button>
            </div>

            {/* WARNING */}

            <div className="mx-6 rounded-lg border border-gray-200 bg-gray-50 px-4 py-3 dark:border-gray-700 dark:bg-gray-950">
              <p className="text-xs leading-5 text-gray-500 dark:text-gray-400">
                The order will be marked as cancelled and its payment status
                will change to refunded.
              </p>
            </div>

            {/* MODAL ACTIONS */}

            <div className="flex flex-col-reverse gap-2 border-t border-gray-200 p-6 sm:flex-row sm:justify-end dark:border-gray-800">
              <button
                type="button"
                onClick={() => setCancelOrder(null)}
                className="h-10 rounded-lg border border-gray-200 px-4 text-sm font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white">
                Keep Order
              </button>

              <button
                type="button"
                onClick={confirmCancelOrder}
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
                <Trash2 size={16} />
                Cancel Order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ================================================= */
/* SUMMARY CARD */
/* ================================================= */

const SummaryCard = ({ icon, label, value }) => {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
          {label}
        </p>

        <span className="text-gray-400">{icon}</span>
      </div>

      <p className="mt-2 text-xl font-bold text-gray-950 dark:text-white">
        {value}
      </p>
    </div>
  );
};

/* ================================================= */
/* ORDER STATUS BADGE */
/* ================================================= */

const OrderStatusBadge = ({ status }) => {
  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${
        statusStyles[status]
      }`}>
      {status}
    </span>
  );
};

/* ================================================= */
/* PAYMENT BADGE */
/* ================================================= */

const PaymentBadge = ({ payment }) => {
  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${
        paymentStyles[payment]
      }`}>
      {payment}
    </span>
  );
};

/* ================================================= */
/* ACTION MENU */
/* ================================================= */

const ActionMenu = ({ order, onView, onEdit, onTrack, onCancel }) => {
  return (
    <div className="absolute right-5 top-12 z-20 w-36 overflow-hidden rounded-lg border border-gray-200 bg-white p-1 text-left shadow-lg dark:border-gray-700 dark:bg-gray-900">
      {/* VIEW */}

      <button
        type="button"
        onClick={() => onView(order.id)}
        className="w-full rounded-md px-3 py-2 text-left text-sm text-gray-600 transition hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
        View
      </button>

      {/* EDIT */}

      <button
        type="button"
        onClick={() => onEdit(order.id)}
        className="w-full rounded-md px-3 py-2 text-left text-sm text-gray-600 transition hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
        Edit
      </button>

      {/* TRACK */}

      <button
        type="button"
        onClick={() => onTrack(order.id)}
        className="w-full rounded-md px-3 py-2 text-left text-sm text-gray-600 transition hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
        Track
      </button>

      {/* CANCEL */}

      {order.status !== "Cancelled" && (
        <button
          type="button"
          onClick={() => onCancel(order.id)}
          className="w-full rounded-md px-3 py-2 text-left text-sm text-red-500 transition hover:bg-red-50 dark:hover:bg-red-950/30">
          Cancel
        </button>
      )}
    </div>
  );
};

export default Orders;
