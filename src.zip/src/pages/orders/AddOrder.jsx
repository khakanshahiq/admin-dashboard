import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Minus,
  Plus,
  ShoppingCart,
  Trash2,
  X,
} from "lucide-react";

const customers = [
  {
    id: 1,
    name: "Alex Morgan",
    email: "alex.morgan@example.com",
  },
  {
    id: 2,
    name: "Sophia Carter",
    email: "sophia.carter@example.com",
  },
  {
    id: 3,
    name: "Daniel Wilson",
    email: "daniel.wilson@example.com",
  },
  {
    id: 4,
    name: "Emma Johnson",
    email: "emma.johnson@example.com",
  },
  {
    id: 5,
    name: "Michael Brown",
    email: "michael.brown@example.com",
  },
];

const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    sku: "WH-1001",
    price: 79.99,
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    sku: "SW-2001",
    price: 129.5,
  },
  {
    id: 3,
    name: "Premium Backpack",
    sku: "PB-3001",
    price: 59.99,
  },
  {
    id: 4,
    name: "Mechanical Keyboard",
    sku: "MK-4001",
    price: 99.0,
  },
  {
    id: 5,
    name: "USB-C Hub",
    sku: "UH-5001",
    price: 39.99,
  },
];

const AddOrder = () => {
  const navigate = useNavigate();

  const [customer, setCustomer] = useState("");
  const [status, setStatus] = useState("Pending");
  const [payment, setPayment] = useState("Pending");
  const [shippingAddress, setShippingAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [selectedProduct, setSelectedProduct] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [items, setItems] = useState([]);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const addProduct = () => {
    if (!selectedProduct) return;

    const product = products.find(
      (item) => item.id === Number(selectedProduct),
    );

    if (!product) return;

    const existingItem = items.find((item) => item.id === product.id);

    if (existingItem) {
      setItems((prev) =>
        prev.map((item) =>
          item.id === product.id
            ? {
                ...item,
                quantity: item.quantity + quantity,
              }
            : item,
        ),
      );
    } else {
      setItems((prev) => [
        ...prev,
        {
          ...product,
          quantity,
        },
      ]);
    }

    setSelectedProduct("");
    setQuantity(1);
  };

  const updateQuantity = (id, value) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              quantity: Math.max(1, item.quantity + value),
            }
          : item,
      ),
    );
  };

  const removeItem = (id) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const subtotal = items.reduce(
    (total, item) => total + item.price * item.quantity,
    0,
  );

  const shipping = items.length > 0 ? 10 : 0;
  const tax = subtotal * 0.05;
  const total = subtotal + shipping + tax;

  const validate = () => {
    const newErrors = {};

    if (!customer) {
      newErrors.customer = "Please select a customer.";
    }

    if (items.length === 0) {
      newErrors.items = "Please add at least one product.";
    }

    if (!shippingAddress.trim()) {
      newErrors.shippingAddress = "Shipping address is required.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    const order = {
      customer,
      status,
      payment,
      shippingAddress,
      notes,
      items,
      subtotal,
      shipping,
      tax,
      total,
    };

    console.log("New order:", order);

    setSuccess(true);

    setTimeout(() => {
      navigate("/admin/orders");
    }, 1000);
  };

  const inputClass =
    "mt-1 block h-11 w-full rounded-lg border border-gray-200 bg-white px-3.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-400 focus:ring-2 focus:ring-gray-100 dark:border-gray-800 dark:bg-gray-950 dark:text-white dark:placeholder:text-gray-500 dark:focus:border-gray-600 dark:focus:ring-gray-900";

  const selectClass =
    "mt-1 block h-11 w-full appearance-none rounded-lg border border-gray-200 bg-white px-3.5 pr-10 text-sm text-gray-900 outline-none transition focus:border-gray-400 focus:ring-2 focus:ring-gray-100 dark:border-gray-800 dark:bg-gray-950 dark:text-white dark:focus:border-gray-600 dark:focus:ring-gray-900";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate("/admin/orders")}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-600 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
            <ArrowLeft size={18} />
          </button>

          <div>
            <h1 className="text-xl font-semibold tracking-tight text-gray-900 dark:text-white sm:text-2xl">
              Add Order
            </h1>

            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Create a new customer order.
            </p>
          </div>
        </div>
      </div>

      {/* Success */}
      {success && (
        <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-400">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/50">
            <Check size={15} />
          </div>
          Order created successfully. Redirecting to orders...
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          {/* Main */}
          <div className="space-y-6 xl:col-span-2">
            {/* Customer */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Customer Information
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Select the customer placing this order.
                </p>
              </div>

              <div className="p-5">
                <div className="max-w-xl">
                  <label
                    htmlFor="customer"
                    className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Customer
                  </label>

                  <div className="relative">
                    <select
                      id="customer"
                      value={customer}
                      onChange={(e) => {
                        setCustomer(e.target.value);
                        setErrors((prev) => ({
                          ...prev,
                          customer: "",
                        }));
                      }}
                      className={selectClass}>
                      <option value="">Select customer</option>

                      {customers.map((item) => (
                        <option key={item.id} value={item.name}>
                          {item.name} — {item.email}
                        </option>
                      ))}
                    </select>

                    <ChevronDown
                      size={16}
                      className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />
                  </div>

                  {errors.customer && (
                    <p className="mt-1.5 text-xs text-red-500">
                      {errors.customer}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Products */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Order Items
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Add products to this order.
                </p>
              </div>

              <div className="p-5">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_120px_auto]">
                  <div className="relative">
                    <select
                      value={selectedProduct}
                      onChange={(e) => setSelectedProduct(e.target.value)}
                      className={selectClass}>
                      <option value="">Select product</option>

                      {products.map((product) => (
                        <option key={product.id} value={product.id}>
                          {product.name} — ${product.price.toFixed(2)}
                        </option>
                      ))}
                    </select>

                    <ChevronDown
                      size={16}
                      className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />
                  </div>

                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) =>
                      setQuantity(Math.max(1, Number(e.target.value)))
                    }
                    className={inputClass}
                    placeholder="Quantity"
                  />

                  <button
                    type="button"
                    onClick={addProduct}
                    disabled={!selectedProduct}
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-gray-900 px-4 text-sm font-medium text-white transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-200">
                    <Plus size={16} />
                    Add
                  </button>
                </div>

                {errors.items && (
                  <p className="mt-2 text-xs text-red-500">{errors.items}</p>
                )}

                {items.length === 0 ? (
                  <div className="mt-5 rounded-lg border border-dashed border-gray-200 px-5 py-10 text-center dark:border-gray-800">
                    <ShoppingCart
                      size={24}
                      className="mx-auto text-gray-300 dark:text-gray-600"
                    />

                    <p className="mt-3 text-sm font-medium text-gray-700 dark:text-gray-300">
                      No products added
                    </p>

                    <p className="mt-1 text-xs text-gray-400">
                      Select a product above to add it to the order.
                    </p>
                  </div>
                ) : (
                  <div className="mt-5 overflow-hidden rounded-lg border border-gray-200 dark:border-gray-800">
                    <div className="hidden grid-cols-[1fr_120px_120px_50px] border-b border-gray-200 bg-gray-50/70 px-4 py-3 text-xs font-semibold uppercase tracking-wide text-gray-500 md:grid dark:border-gray-800 dark:bg-gray-950/40 dark:text-gray-400">
                      <span>Product</span>
                      <span>Quantity</span>
                      <span>Price</span>
                      <span />
                    </div>

                    <div className="divide-y divide-gray-200 dark:divide-gray-800">
                      {items.map((item) => (
                        <div
                          key={item.id}
                          className="grid gap-3 px-4 py-4 md:grid-cols-[1fr_120px_120px_50px] md:items-center">
                          <div>
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              {item.name}
                            </p>

                            <p className="mt-1 text-xs text-gray-400">
                              SKU: {item.sku}
                            </p>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, -1)}
                              className="flex h-8 w-8 items-center justify-center rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800">
                              <Minus size={14} />
                            </button>

                            <span className="w-6 text-center text-sm font-medium text-gray-900 dark:text-white">
                              {item.quantity}
                            </span>

                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, 1)}
                              className="flex h-8 w-8 items-center justify-center rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800">
                              <Plus size={14} />
                            </button>
                          </div>

                          <p className="text-sm font-semibold text-gray-900 dark:text-white">
                            ${(item.price * item.quantity).toFixed(2)}
                          </p>

                          <button
                            type="button"
                            onClick={() => removeItem(item.id)}
                            className="flex h-8 w-8 items-center justify-center rounded-md text-gray-400 transition hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-950/30">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Shipping */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Shipping Information
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Enter the delivery information for this order.
                </p>
              </div>

              <div className="p-5">
                <label
                  htmlFor="shippingAddress"
                  className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Shipping Address
                </label>

                <textarea
                  id="shippingAddress"
                  value={shippingAddress}
                  onChange={(e) => {
                    setShippingAddress(e.target.value);
                    setErrors((prev) => ({
                      ...prev,
                      shippingAddress: "",
                    }));
                  }}
                  rows={4}
                  placeholder="Enter complete shipping address"
                  className={`mt-1 block w-full resize-none rounded-lg border bg-white px-3.5 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-400 focus:ring-2 focus:ring-gray-100 dark:bg-gray-950 dark:text-white dark:placeholder:text-gray-500 dark:focus:border-gray-600 dark:focus:ring-gray-900 ${
                    errors.shippingAddress
                      ? "border-red-300 dark:border-red-800"
                      : "border-gray-200 dark:border-gray-800"
                  }`}
                />

                {errors.shippingAddress && (
                  <p className="mt-1.5 text-xs text-red-500">
                    {errors.shippingAddress}
                  </p>
                )}

                <div className="mt-5">
                  <label
                    htmlFor="notes"
                    className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Order Notes
                    <span className="ml-1 text-xs font-normal text-gray-400">
                      (Optional)
                    </span>
                  </label>

                  <textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={3}
                    placeholder="Add any special instructions..."
                    className="mt-1 block w-full resize-none rounded-lg border border-gray-200 bg-white px-3.5 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-400 focus:ring-2 focus:ring-gray-100 dark:border-gray-800 dark:bg-gray-950 dark:text-white dark:placeholder:text-gray-500 dark:focus:border-gray-600 dark:focus:ring-gray-900"
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => navigate("/admin/orders")}
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
                <X size={16} />
                Cancel
              </button>

              <button
                type="submit"
                disabled={success}
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-900 px-4 text-sm font-medium text-white transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-200">
                <ShoppingCart size={16} />
                Create Order
              </button>
            </div>
          </div>

          {/* Summary Sidebar */}
          <div className="space-y-6">
            {/* Order Summary */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Order Summary
                </h2>
              </div>

              <div className="p-5">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">
                      Subtotal
                    </span>

                    <span className="font-medium text-gray-900 dark:text-white">
                      ${subtotal.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">
                      Shipping
                    </span>

                    <span className="font-medium text-gray-900 dark:text-white">
                      ${shipping.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">
                      Tax
                    </span>

                    <span className="font-medium text-gray-900 dark:text-white">
                      ${tax.toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="my-4 border-t border-gray-200 dark:border-gray-800" />

                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-gray-900 dark:text-white">
                    Total
                  </span>

                  <span className="text-lg font-semibold text-gray-900 dark:text-white">
                    ${total.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Status */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Order Status
                </h2>
              </div>

              <div className="space-y-4 p-5">
                <div>
                  <label
                    htmlFor="status"
                    className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Status
                  </label>

                  <div className="relative">
                    <select
                      id="status"
                      value={status}
                      onChange={(e) => setStatus(e.target.value)}
                      className={selectClass}>
                      <option value="Pending">Pending</option>
                      <option value="Processing">Processing</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Delivered">Delivered</option>
                    </select>

                    <ChevronDown
                      size={16}
                      className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="payment"
                    className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Payment Status
                  </label>

                  <div className="relative">
                    <select
                      id="payment"
                      value={payment}
                      onChange={(e) => setPayment(e.target.value)}
                      className={selectClass}>
                      <option value="Pending">Pending</option>
                      <option value="Paid">Paid</option>
                      <option value="Refunded">Refunded</option>
                    </select>

                    <ChevronDown
                      size={16}
                      className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Tip */}
            <div className="rounded-xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
              <div className="flex gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                  <ShoppingCart size={16} />
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Quick tip
                  </p>

                  <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
                    Add all products before creating the order. The total will
                    update automatically.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddOrder;
