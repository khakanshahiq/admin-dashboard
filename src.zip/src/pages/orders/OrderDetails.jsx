import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Check,
  Clock3,
  CreditCard,
  Download,
  MapPin,
  Package,
  Printer,
  ShoppingBag,
  Truck,
  User,
} from "lucide-react";

const orders = {
  "ORD-1001": {
    id: "#ORD-1001",
    customer: "Alex Morgan",
    email: "alex.morgan@example.com",
    phone: "+1 555-0123",
    date: "Aug 28, 2026",
    status: "Delivered",
    payment: "Paid",
    paymentMethod: "Visa ending in 4242",
    shippingAddress: "245 Market Street, San Francisco, CA 94105",
    notes: "Please leave the package at the front door.",
    items: [
      {
        id: 1,
        name: "Wireless Headphones",
        sku: "WH-1001",
        price: 79.99,
        quantity: 2,
      },
      {
        id: 2,
        name: "USB-C Hub",
        sku: "UH-5001",
        price: 39.99,
        quantity: 1,
      },
    ],
    timeline: [
      {
        title: "Order delivered",
        description: "Package was delivered successfully.",
        date: "Aug 28, 2026 · 2:45 PM",
        completed: true,
      },
      {
        title: "Out for delivery",
        description: "Your package is on the way.",
        date: "Aug 28, 2026 · 8:20 AM",
        completed: true,
      },
      {
        title: "Shipped",
        description: "Package has left the fulfillment center.",
        date: "Aug 27, 2026 · 4:10 PM",
        completed: true,
      },
      {
        title: "Order confirmed",
        description: "Payment confirmed and order is being prepared.",
        date: "Aug 27, 2026 · 10:32 AM",
        completed: true,
      },
      {
        title: "Order placed",
        description: "Order was placed successfully.",
        date: "Aug 27, 2026 · 10:30 AM",
        completed: true,
      },
    ],
  },

  "ORD-1002": {
    id: "#ORD-1002",
    customer: "Sophia Carter",
    email: "sophia.carter@example.com",
    phone: "+1 555-0187",
    date: "Aug 27, 2026",
    status: "Processing",
    payment: "Paid",
    paymentMethod: "Mastercard ending in 8821",
    shippingAddress: "88 Madison Avenue, New York, NY 10016",
    notes: "Call before delivery.",
    items: [
      {
        id: 1,
        name: "Smart Watch Pro",
        sku: "SW-2001",
        price: 129.5,
        quantity: 1,
      },
    ],
    timeline: [
      {
        title: "Order is processing",
        description: "Your order is being prepared.",
        date: "Aug 27, 2026 · 1:25 PM",
        completed: true,
      },
      {
        title: "Order confirmed",
        description: "Payment confirmed successfully.",
        date: "Aug 27, 2026 · 11:12 AM",
        completed: true,
      },
      {
        title: "Order placed",
        description: "Order was placed successfully.",
        date: "Aug 27, 2026 · 11:10 AM",
        completed: true,
      },
    ],
  },

  "ORD-1003": {
    id: "#ORD-1003",
    customer: "Daniel Wilson",
    email: "daniel.wilson@example.com",
    phone: "+1 555-0198",
    date: "Aug 26, 2026",
    status: "Shipped",
    payment: "Paid",
    paymentMethod: "Visa ending in 1098",
    shippingAddress: "17 Oak Street, Austin, TX 78701",
    notes: "No special instructions.",
    items: [
      {
        id: 1,
        name: "Premium Backpack",
        sku: "PB-3001",
        price: 59.99,
        quantity: 1,
      },
      {
        id: 2,
        name: "USB-C Hub",
        sku: "UH-5001",
        price: 39.99,
        quantity: 1,
      },
    ],
    timeline: [
      {
        title: "Shipped",
        description: "Package has been handed to the carrier.",
        date: "Aug 26, 2026 · 5:15 PM",
        completed: true,
      },
      {
        title: "Order confirmed",
        description: "Payment confirmed successfully.",
        date: "Aug 26, 2026 · 12:20 PM",
        completed: true,
      },
      {
        title: "Order placed",
        description: "Order was placed successfully.",
        date: "Aug 26, 2026 · 12:18 PM",
        completed: true,
      },
    ],
  },
};

const fallbackOrder = {
  id: "#ORD-1004",
  customer: "Emma Johnson",
  email: "emma.johnson@example.com",
  phone: "+1 555-0166",
  date: "Aug 25, 2026",
  status: "Pending",
  payment: "Pending",
  paymentMethod: "Not paid",
  shippingAddress: "120 King Street, Chicago, IL 60601",
  notes: "No special instructions.",
  items: [
    {
      id: 1,
      name: "Mechanical Keyboard",
      sku: "MK-4001",
      price: 99,
      quantity: 1,
    },
  ],
  timeline: [
    {
      title: "Order placed",
      description: "Order was placed successfully.",
      date: "Aug 25, 2026 · 9:30 AM",
      completed: true,
    },
  ],
};

const getStatusClasses = (status) => {
  const classes = {
    Delivered:
      "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400",
    Processing:
      "bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400",
    Shipped:
      "bg-violet-50 text-violet-700 dark:bg-violet-950/30 dark:text-violet-400",
    Pending:
      "bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400",
    Cancelled: "bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-400",
  };

  return (
    classes[status] ||
    "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300"
  );
};

const getPaymentClasses = (payment) => {
  if (payment === "Paid") {
    return "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400";
  }

  if (payment === "Refunded") {
    return "bg-violet-50 text-violet-700 dark:bg-violet-950/30 dark:text-violet-400";
  }

  return "bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400";
};

const OrderDetails = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const orderKey = id?.replace("#", "");
  const order = orders[orderKey] || fallbackOrder;

  const subtotal = order.items.reduce(
    (total, item) => total + item.price * item.quantity,
    0,
  );

  const shipping = 10;
  const tax = subtotal * 0.05;
  const total = subtotal + shipping + tax;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate("/admin/orders")}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-600 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
            <ArrowLeft size={18} />
          </button>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl font-semibold tracking-tight text-gray-900 dark:text-white sm:text-2xl">
                Order {order.id}
              </h1>

              <span
                className={`rounded-full px-2.5 py-1 text-xs font-medium ${getStatusClasses(
                  order.status,
                )}`}>
                {order.status}
              </span>
            </div>

            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Placed on {order.date}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white px-3.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
            <Printer size={16} />
            <span className="hidden sm:inline">Print</span>
          </button>

          <button
            type="button"
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-900 px-3.5 text-sm font-medium text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-200">
            <Download size={16} />
            <span className="hidden sm:inline">Invoice</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        {/* Left */}
        <div className="space-y-6 xl:col-span-2">
          {/* Products */}
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="flex items-center justify-between border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <div>
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Order Items
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  {order.items.length}{" "}
                  {order.items.length === 1 ? "product" : "products"}
                </p>
              </div>

              <Package size={18} className="text-gray-400 dark:text-gray-500" />
            </div>

            <div className="divide-y divide-gray-200 dark:divide-gray-800">
              {order.items.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                    <ShoppingBag size={22} />
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white">
                      {item.name}
                    </p>

                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      SKU: {item.sku}
                    </p>

                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400 sm:hidden">
                      Qty: {item.quantity}
                    </p>
                  </div>

                  <div className="hidden text-center sm:block">
                    <p className="text-xs text-gray-400">Quantity</p>
                    <p className="mt-1 text-sm font-medium text-gray-900 dark:text-white">
                      {item.quantity}
                    </p>
                  </div>

                  <div className="text-left sm:w-28 sm:text-right">
                    <p className="text-xs text-gray-400">Price</p>
                    <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="border-t border-gray-200 bg-gray-50/50 p-5 dark:border-gray-800 dark:bg-gray-950/30">
              <div className="ml-auto max-w-sm space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">
                    Subtotal
                  </span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    ${subtotal.toFixed(2)}
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">
                    Shipping
                  </span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    ${shipping.toFixed(2)}
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">Tax</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    ${tax.toFixed(2)}
                  </span>
                </div>

                <div className="border-t border-gray-200 pt-3 dark:border-gray-800">
                  <div className="flex justify-between">
                    <span className="text-sm font-semibold text-gray-900 dark:text-white">
                      Total
                    </span>

                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      ${total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Order Timeline
              </h2>

              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Track the progress of this order.
              </p>
            </div>

            <div className="p-5">
              <div className="relative">
                {order.timeline.map((event, index) => (
                  <div
                    key={`${event.title}-${index}`}
                    className="relative flex gap-4 pb-6 last:pb-0">
                    {index !== order.timeline.length - 1 && (
                      <div className="absolute left-[11px] top-6 h-full w-px bg-gray-200 dark:bg-gray-800" />
                    )}

                    <div className="relative z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gray-900 text-white dark:bg-white dark:text-gray-900">
                      {event.title.toLowerCase().includes("delivered") ? (
                        <Check size={13} />
                      ) : event.title.toLowerCase().includes("shipped") ||
                        event.title.toLowerCase().includes("delivery") ? (
                        <Truck size={12} />
                      ) : (
                        <Clock3 size={12} />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">
                          {event.title}
                        </p>

                        <p className="text-xs text-gray-400">{event.date}</p>
                      </div>

                      <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
                        {event.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Order Notes
              </h2>
            </div>

            <div className="p-5">
              <p className="text-sm leading-6 text-gray-600 dark:text-gray-400">
                {order.notes}
              </p>
            </div>
          </div>
        </div>

        {/* Right */}
        <div className="space-y-6">
          {/* Customer */}
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Customer
              </h2>
            </div>

            <div className="p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gray-100 text-sm font-semibold text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                  {order.customer
                    .split(" ")
                    .map((name) => name[0])
                    .join("")}
                </div>

                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                    {order.customer}
                  </p>

                  <p className="truncate text-xs text-gray-500 dark:text-gray-400">
                    {order.email}
                  </p>
                </div>
              </div>

              <div className="mt-5 space-y-3 border-t border-gray-200 pt-4 dark:border-gray-800">
                <div className="flex gap-3">
                  <User size={16} className="mt-0.5 shrink-0 text-gray-400" />

                  <div>
                    <p className="text-xs text-gray-400">Phone</p>
                    <p className="mt-0.5 text-sm text-gray-700 dark:text-gray-300">
                      {order.phone}
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <MapPin size={16} className="mt-0.5 shrink-0 text-gray-400" />

                  <div>
                    <p className="text-xs text-gray-400">Shipping address</p>
                    <p className="mt-0.5 text-sm leading-5 text-gray-700 dark:text-gray-300">
                      {order.shippingAddress}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Payment */}
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Payment Information
              </h2>
            </div>

            <div className="p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                  <CreditCard size={18} />
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {order.paymentMethod}
                  </p>

                  <span
                    className={`mt-1 inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${getPaymentClasses(
                      order.payment,
                    )}`}>
                    {order.payment}
                  </span>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between border-t border-gray-200 pt-4 dark:border-gray-800">
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  Amount
                </span>

                <span className="text-sm font-semibold text-gray-900 dark:text-white">
                  ${total.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Shipping */}
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Shipping
              </h2>
            </div>

            <div className="p-5">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                  <Truck size={18} />
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Standard Delivery
                  </p>

                  <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
                    Estimated delivery within 3–5 business days.
                  </p>
                </div>
              </div>

              <div className="mt-4 flex items-start gap-3 border-t border-gray-200 pt-4 dark:border-gray-800">
                <MapPin size={16} className="mt-0.5 shrink-0 text-gray-400" />

                <p className="text-sm leading-5 text-gray-600 dark:text-gray-400">
                  {order.shippingAddress}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Back */}
      <div className="flex justify-start">
        <button
          type="button"
          onClick={() => navigate("/admin/orders")}
          className="inline-flex h-10 items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
          <ArrowLeft size={16} />
          Back to Orders
        </button>
      </div>
    </div>
  );
};

export default OrderDetails;
