import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Package,
  Save,
  ShoppingCart,
  User,
} from "lucide-react";

const ordersData = [
  {
    id: "ORD-1001",
    customerName: "Alex Morgan",
    customerEmail: "alex.morgan@example.com",
    customerPhone: "+1 202 555 0147",
    product: "Premium Wireless Headphones",
    quantity: 3,
    price: 249.99,
    paymentMethod: "Credit Card",
    paymentStatus: "Paid",
    orderStatus: "Delivered",
    orderDate: "2026-08-28",
    shippingAddress: "123 Main Street, New York, NY 10001",
    notes: "Leave the package at the front door.",
  },
  {
    id: "ORD-1002",
    customerName: "Sophia Carter",
    customerEmail: "sophia.carter@example.com",
    customerPhone: "+1 202 555 0182",
    product: "Smart Watch Pro",
    quantity: 2,
    price: 129.5,
    paymentMethod: "PayPal",
    paymentStatus: "Paid",
    orderStatus: "Processing",
    orderDate: "2026-08-27",
    shippingAddress: "45 Park Avenue, New York, NY 10016",
    notes: "",
  },
  {
    id: "ORD-1003",
    customerName: "Daniel Wilson",
    customerEmail: "daniel.wilson@example.com",
    customerPhone: "+1 202 555 0116",
    product: "Mechanical Keyboard",
    quantity: 1,
    price: 79.99,
    paymentMethod: "Credit Card",
    paymentStatus: "Paid",
    orderStatus: "Shipped",
    orderDate: "2026-08-26",
    shippingAddress: "88 Oak Street, Chicago, IL 60601",
    notes: "Customer requested fast delivery.",
  },
  {
    id: "ORD-1004",
    customerName: "Emma Johnson",
    customerEmail: "emma.johnson@example.com",
    customerPhone: "+1 202 555 0194",
    product: "4K Monitor",
    quantity: 4,
    price: 349,
    paymentMethod: "Bank Transfer",
    paymentStatus: "Pending",
    orderStatus: "Pending",
    orderDate: "2026-08-25",
    shippingAddress: "22 Lake Road, Boston, MA 02108",
    notes: "",
  },
  {
    id: "ORD-1005",
    customerName: "Michael Brown",
    customerEmail: "michael.brown@example.com",
    customerPhone: "+1 202 555 0163",
    product: "Wireless Mouse",
    quantity: 2,
    price: 189.75,
    paymentMethod: "Credit Card",
    paymentStatus: "Paid",
    orderStatus: "Delivered",
    orderDate: "2026-08-24",
    shippingAddress: "17 Washington Street, Austin, TX 78701",
    notes: "",
  },
  {
    id: "ORD-1006",
    customerName: "Olivia Davis",
    customerEmail: "olivia.davis@example.com",
    customerPhone: "+1 202 555 0135",
    product: "Laptop Pro 15",
    quantity: 5,
    price: 499.99,
    paymentMethod: "Credit Card",
    paymentStatus: "Refunded",
    orderStatus: "Cancelled",
    orderDate: "2026-08-23",
    shippingAddress: "64 River Road, Seattle, WA 98101",
    notes: "Order cancelled by customer.",
  },
  {
    id: "ORD-1007",
    customerName: "James Miller",
    customerEmail: "james.miller@example.com",
    customerPhone: "+1 202 555 0171",
    product: "USB-C Hub",
    quantity: 1,
    price: 59.99,
    paymentMethod: "PayPal",
    paymentStatus: "Paid",
    orderStatus: "Processing",
    orderDate: "2026-08-22",
    shippingAddress: "91 Pine Street, Denver, CO 80202",
    notes: "",
  },
  {
    id: "ORD-1008",
    customerName: "Isabella Moore",
    customerEmail: "isabella.moore@example.com",
    customerPhone: "+1 202 555 0128",
    product: "Bluetooth Speaker",
    quantity: 3,
    price: 219.25,
    paymentMethod: "Credit Card",
    paymentStatus: "Paid",
    orderStatus: "Shipped",
    orderDate: "2026-08-21",
    shippingAddress: "31 King Street, Miami, FL 33101",
    notes: "Call before delivery.",
  },
  {
    id: "ORD-1009",
    customerName: "Noah Taylor",
    customerEmail: "noah.taylor@example.com",
    customerPhone: "+1 202 555 0158",
    product: "Gaming Controller",
    quantity: 2,
    price: 145,
    paymentMethod: "Credit Card",
    paymentStatus: "Paid",
    orderStatus: "Delivered",
    orderDate: "2026-08-20",
    shippingAddress: "75 Hill Street, Dallas, TX 75201",
    notes: "",
  },
  {
    id: "ORD-1010",
    customerName: "Ava Anderson",
    customerEmail: "ava.anderson@example.com",
    customerPhone: "+1 202 555 0168",
    product: "Portable SSD",
    quantity: 1,
    price: 89.99,
    paymentMethod: "Bank Transfer",
    paymentStatus: "Pending",
    orderStatus: "Pending",
    orderDate: "2026-08-19",
    shippingAddress: "14 Market Street, Portland, OR 97201",
    notes: "",
  },
];

const EditOrder = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState({
    orderNumber: "",
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    product: "",
    quantity: 1,
    price: "",
    paymentMethod: "Credit Card",
    paymentStatus: "Paid",
    orderStatus: "Processing",
    orderDate: "",
    shippingAddress: "",
    notes: "",
  });

  const [errors, setErrors] = useState({});
  const [saved, setSaved] = useState(false);

  const order = useMemo(() => {
    return ordersData.find((item) => item.id === id);
  }, [id]);

  useEffect(() => {
    if (order) {
      setFormData({
        orderNumber: order.id,
        customerName: order.customerName,
        customerEmail: order.customerEmail,
        customerPhone: order.customerPhone,
        product: order.product,
        quantity: order.quantity,
        price: order.price,
        paymentMethod: order.paymentMethod,
        paymentStatus: order.paymentStatus,
        orderStatus: order.orderStatus,
        orderDate: order.orderDate,
        shippingAddress: order.shippingAddress,
        notes: order.notes,
      });
    }
  }, [order]);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((previous) => ({
        ...previous,
        [name]: "",
      }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.customerName.trim()) {
      newErrors.customerName = "Customer name is required.";
    }

    if (!formData.customerEmail.trim()) {
      newErrors.customerEmail = "Customer email is required.";
    }

    if (!formData.customerPhone.trim()) {
      newErrors.customerPhone = "Customer phone is required.";
    }

    if (!formData.product.trim()) {
      newErrors.product = "Product name is required.";
    }

    if (!formData.quantity || Number(formData.quantity) < 1) {
      newErrors.quantity = "Quantity must be at least 1.";
    }

    if (!formData.price || Number(formData.price) <= 0) {
      newErrors.price = "Price must be greater than 0.";
    }

    if (!formData.orderDate) {
      newErrors.orderDate = "Order date is required.";
    }

    if (!formData.shippingAddress.trim()) {
      newErrors.shippingAddress = "Shipping address is required.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!validate()) {
      return;
    }

    console.log("Updated order:", {
      ...formData,
      quantity: Number(formData.quantity),
      price: Number(formData.price),
    });

    setSaved(true);

    setTimeout(() => {
      navigate(`/admin/orders/${id}`);
    }, 1000);
  };

  const total = Number(formData.quantity || 0) * Number(formData.price || 0);

  if (!order) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="text-center">
          <Package
            size={32}
            className="mx-auto text-gray-300 dark:text-gray-600"
          />

          <h2 className="mt-4 text-lg font-semibold text-gray-900 dark:text-white">
            Order not found
          </h2>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            The order you are trying to edit does not exist.
          </p>

          <button
            type="button"
            onClick={() => navigate("/admin/orders")}
            className="mt-5 rounded-lg bg-gray-950 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* PAGE HEADER */}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <button
            type="button"
            onClick={() => navigate(`/admin/orders/${id}`)}
            className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-gray-200 text-gray-500 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
            aria-label="Back to order details">
            <ArrowLeft size={17} />
          </button>

          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
              Edit Order
            </h1>

            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Update order information, payment, and fulfillment details.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => navigate(`/admin/orders/${id}`)}
            className="h-10 rounded-lg border border-gray-200 px-4 text-sm font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white">
            Cancel
          </button>

          <button
            type="submit"
            form="edit-order-form"
            disabled={saved}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
            {saved ? <Check size={17} /> : <Save size={17} />}
            {saved ? "Saved" : "Save Changes"}
          </button>
        </div>
      </div>

      {/* SUCCESS MESSAGE */}

      {saved && (
        <div className="flex items-center gap-3 rounded-xl border border-gray-200 bg-white px-4 py-3 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300">
            <Check size={16} />
          </div>

          <div>
            <p className="text-sm font-semibold text-gray-900 dark:text-white">
              Order updated successfully
            </p>

            <p className="text-xs text-gray-500 dark:text-gray-400">
              Redirecting to order details...
            </p>
          </div>
        </div>
      )}

      {/* FORM */}

      <form
        id="edit-order-form"
        onSubmit={handleSubmit}
        className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        {/* LEFT COLUMN */}

        <div className="space-y-6">
          {/* CUSTOMER */}

          <section className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="flex items-center gap-3 border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                <User size={17} />
              </div>

              <div>
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Customer Information
                </h2>

                <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                  Customer details associated with this order.
                </p>
              </div>
            </div>

            <div className="grid gap-5 p-5 md:grid-cols-2">
              <InputField
                label="Customer Name"
                name="customerName"
                value={formData.customerName}
                onChange={handleChange}
                error={errors.customerName}
                required
              />

              <InputField
                label="Email Address"
                name="customerEmail"
                type="email"
                value={formData.customerEmail}
                onChange={handleChange}
                error={errors.customerEmail}
                required
              />

              <InputField
                label="Phone Number"
                name="customerPhone"
                value={formData.customerPhone}
                onChange={handleChange}
                error={errors.customerPhone}
                required
              />

              <InputField
                label="Order Number"
                name="orderNumber"
                value={formData.orderNumber}
                onChange={handleChange}
                disabled
              />
            </div>
          </section>

          {/* ORDER INFORMATION */}

          <section className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="flex items-center gap-3 border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                <ShoppingCart size={17} />
              </div>

              <div>
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Order Information
                </h2>

                <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                  Product and order pricing details.
                </p>
              </div>
            </div>

            <div className="grid gap-5 p-5 md:grid-cols-2">
              <div className="md:col-span-2">
                <InputField
                  label="Product"
                  name="product"
                  value={formData.product}
                  onChange={handleChange}
                  error={errors.product}
                  required
                />
              </div>

              <InputField
                label="Quantity"
                name="quantity"
                type="number"
                min="1"
                value={formData.quantity}
                onChange={handleChange}
                error={errors.quantity}
                required
              />

              <InputField
                label="Price per Item"
                name="price"
                type="number"
                min="0"
                step="0.01"
                value={formData.price}
                onChange={handleChange}
                error={errors.price}
                required
              />

              <InputField
                label="Order Date"
                name="orderDate"
                type="date"
                value={formData.orderDate}
                onChange={handleChange}
                error={errors.orderDate}
                required
              />
            </div>
          </section>

          {/* PAYMENT */}

          <section className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Payment & Order Status
              </h2>

              <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                Manage payment and fulfillment status.
              </p>
            </div>

            <div className="grid gap-5 p-5 md:grid-cols-3">
              <SelectField
                label="Payment Method"
                name="paymentMethod"
                value={formData.paymentMethod}
                onChange={handleChange}
                options={[
                  "Credit Card",
                  "Debit Card",
                  "PayPal",
                  "Bank Transfer",
                  "Cash on Delivery",
                ]}
              />

              <SelectField
                label="Payment Status"
                name="paymentStatus"
                value={formData.paymentStatus}
                onChange={handleChange}
                options={["Paid", "Pending", "Refunded"]}
              />

              <SelectField
                label="Order Status"
                name="orderStatus"
                value={formData.orderStatus}
                onChange={handleChange}
                options={[
                  "Pending",
                  "Processing",
                  "Shipped",
                  "Delivered",
                  "Cancelled",
                ]}
              />
            </div>
          </section>

          {/* SHIPPING */}

          <section className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Shipping & Notes
              </h2>

              <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                Delivery address and additional order notes.
              </p>
            </div>

            <div className="space-y-5 p-5">
              <TextareaField
                label="Shipping Address"
                name="shippingAddress"
                value={formData.shippingAddress}
                onChange={handleChange}
                error={errors.shippingAddress}
                rows={3}
                required
              />

              <TextareaField
                label="Order Notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={4}
                placeholder="Add any additional notes..."
              />
            </div>
          </section>
        </div>

        {/* RIGHT COLUMN */}

        <div className="space-y-6">
          {/* ORDER SUMMARY */}

          <section className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Order Summary
              </h2>
            </div>

            <div className="p-5">
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-300">
                  <Package size={19} />
                </div>

                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                    {formData.product || "Product"}
                  </p>

                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    {formData.quantity || 0}{" "}
                    {Number(formData.quantity) === 1 ? "item" : "items"}
                  </p>
                </div>
              </div>

              <div className="mt-5 space-y-3 border-t border-gray-100 pt-4 dark:border-gray-800">
                <SummaryRow
                  label="Price"
                  value={`$${Number(formData.price || 0).toFixed(2)}`}
                />

                <SummaryRow label="Quantity" value={formData.quantity || 0} />

                <div className="border-t border-gray-100 pt-3 dark:border-gray-800">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-gray-900 dark:text-white">
                      Total
                    </span>

                    <span className="text-lg font-bold text-gray-950 dark:text-white">
                      ${total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* CURRENT STATUS */}

          <section className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
            <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                Current Status
              </h2>
            </div>

            <div className="space-y-4 p-5">
              <StatusPreview label="Order" value={formData.orderStatus} />

              <StatusPreview label="Payment" value={formData.paymentStatus} />
            </div>
          </section>

          {/* SAVE CARD */}

          <section className="rounded-xl border border-gray-200 bg-gray-50 p-5 dark:border-gray-800 dark:bg-gray-950">
            <p className="text-sm font-semibold text-gray-900 dark:text-white">
              Ready to save?
            </p>

            <p className="mt-1 text-xs leading-5 text-gray-500 dark:text-gray-400">
              Review the order information before saving your changes.
            </p>

            <button
              type="submit"
              form="edit-order-form"
              disabled={saved}
              className="mt-4 inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
              {saved ? <Check size={17} /> : <Save size={17} />}
              {saved ? "Changes Saved" : "Save Changes"}
            </button>
          </section>
        </div>
      </form>
    </div>
  );
};

/* ================================================= */
/* INPUT FIELD */
/* ================================================= */

const InputField = ({
  label,
  name,
  type = "text",
  value,
  onChange,
  error,
  required = false,
  disabled = false,
  min,
  step,
}) => {
  return (
    <div>
      <label
        htmlFor={name}
        className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-300">
        {label}

        {required && <span className="ml-1 text-gray-400">*</span>}
      </label>

      <input
        id={name}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        disabled={disabled}
        min={min}
        step={step}
        className={`h-10 w-full rounded-lg border bg-white px-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:ring-2 focus:ring-gray-900/10 disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-400 dark:bg-gray-950 dark:text-white dark:disabled:bg-gray-900 ${
          error
            ? "border-red-300 focus:border-red-500"
            : "border-gray-200 focus:border-gray-900 dark:border-gray-700 dark:focus:border-gray-300"
        }`}
      />

      {error && <p className="mt-1.5 text-xs text-red-500">{error}</p>}
    </div>
  );
};

/* ================================================= */
/* SELECT FIELD */
/* ================================================= */

const SelectField = ({ label, name, value, onChange, options }) => {
  return (
    <div>
      <label
        htmlFor={name}
        className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-300">
        {label}
      </label>

      <div className="relative">
        <select
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-3 pr-9 text-sm text-gray-900 outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300">
          {options.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>

        <ChevronDown
          size={15}
          className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
        />
      </div>
    </div>
  );
};

/* ================================================= */
/* TEXTAREA FIELD */
/* ================================================= */

const TextareaField = ({
  label,
  name,
  value,
  onChange,
  error,
  rows = 4,
  placeholder = "",
  required = false,
}) => {
  return (
    <div>
      <label
        htmlFor={name}
        className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-300">
        {label}

        {required && <span className="ml-1 text-gray-400">*</span>}
      </label>

      <textarea
        id={name}
        name={name}
        value={value}
        onChange={onChange}
        rows={rows}
        placeholder={placeholder}
        className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:ring-2 focus:ring-gray-900/10 dark:bg-gray-950 dark:text-white ${
          error
            ? "border-red-300 focus:border-red-500"
            : "border-gray-200 focus:border-gray-900 dark:border-gray-700 dark:focus:border-gray-300"
        }`}
      />

      {error && <p className="mt-1.5 text-xs text-red-500">{error}</p>}
    </div>
  );
};

/* ================================================= */
/* SUMMARY ROW */
/* ================================================= */

const SummaryRow = ({ label, value }) => {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-xs text-gray-500 dark:text-gray-400">{label}</span>

      <span className="text-sm font-medium text-gray-900 dark:text-white">
        {value}
      </span>
    </div>
  );
};

/* ================================================= */
/* STATUS PREVIEW */
/* ================================================= */

const StatusPreview = ({ label, value }) => {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-xs text-gray-500 dark:text-gray-400">{label}</span>

      <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-medium text-gray-700 dark:bg-gray-800 dark:text-gray-300">
        {value}
      </span>
    </div>
  );
};

export default EditOrder;
