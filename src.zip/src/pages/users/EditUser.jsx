import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Check,
  Eye,
  EyeOff,
  ImagePlus,
  Lock,
  Save,
  Shield,
  X,
} from "lucide-react";

// Temporary frontend data.
// Later this can come from your API/database.
const usersData = [
  {
    id: 1,
    name: "Alex Morgan",
    email: "alex.morgan@example.com",
    phone: "+1 202 555 0147",
    role: "Administrator",
    status: "Active",
    avatar: "https://i.pravatar.cc/150?img=12",
  },
  {
    id: 2,
    name: "Sophia Carter",
    email: "sophia.carter@example.com",
    phone: "+1 202 555 0182",
    role: "Manager",
    status: "Active",
    avatar: "https://i.pravatar.cc/150?img=47",
  },
  {
    id: 3,
    name: "Daniel Wilson",
    email: "daniel.wilson@example.com",
    phone: "+1 202 555 0116",
    role: "Editor",
    status: "Active",
    avatar: "https://i.pravatar.cc/150?img=11",
  },
  {
    id: 4,
    name: "Emma Johnson",
    email: "emma.johnson@example.com",
    phone: "+1 202 555 0194",
    role: "User",
    status: "Inactive",
    avatar: "https://i.pravatar.cc/150?img=32",
  },
  {
    id: 5,
    name: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "+1 202 555 0163",
    role: "User",
    status: "Active",
    avatar: "https://i.pravatar.cc/150?img=68",
  },
  {
    id: 6,
    name: "Olivia Davis",
    email: "olivia.davis@example.com",
    phone: "+1 202 555 0135",
    role: "Manager",
    status: "Active",
    avatar: "https://i.pravatar.cc/150?img=44",
  },
  {
    id: 7,
    name: "James Miller",
    email: "james.miller@example.com",
    phone: "+1 202 555 0171",
    role: "User",
    status: "Inactive",
    avatar: "https://i.pravatar.cc/150?img=53",
  },
  {
    id: 8,
    name: "Isabella Moore",
    email: "isabella.moore@example.com",
    phone: "+1 202 555 0128",
    role: "Editor",
    status: "Active",
    avatar: "https://i.pravatar.cc/150?img=45",
  },
];

const EditUser = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const existingUser =
    usersData.find((user) => user.id === Number(id)) || usersData[0];

  const [formData, setFormData] = useState({
    name: existingUser.name,
    email: existingUser.email,
    phone: existingUser.phone,
    role: existingUser.role,
    status: existingUser.status,
    password: "",
    confirmPassword: "",
  });

  const [avatar, setAvatar] = useState(existingUser.avatar);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrors((prev) => ({
        ...prev,
        avatar: "Please select a valid image.",
      }));
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setErrors((prev) => ({
        ...prev,
        avatar: "Image must be smaller than 2MB.",
      }));
      return;
    }

    const imageUrl = URL.createObjectURL(file);

    setAvatar(imageUrl);

    setErrors((prev) => ({
      ...prev,
      avatar: "",
    }));
  };

  const removeAvatar = () => {
    setAvatar(null);
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is required.";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Enter a valid email address.";
    }

    if (!formData.phone.trim()) {
      newErrors.phone = "Phone number is required.";
    }

    // Password is optional when editing.
    // If user enters one, validate it.
    if (formData.password && formData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters.";
    }

    if (formData.password && formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    const updatedUser = {
      id: Number(id),
      ...formData,
      avatar,
    };

    console.log("Updated user:", updatedUser);

    setSuccess(true);

    setTimeout(() => {
      navigate(`/admin/users/${id}`);
    }, 1000);
  };

  const inputClass = (field) =>
    `mt-1 block h-11 w-full rounded-lg border bg-white px-3.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-400 focus:ring-2 focus:ring-gray-100 dark:bg-gray-950 dark:text-white dark:placeholder:text-gray-500 dark:focus:border-gray-600 dark:focus:ring-gray-900 ${
      errors[field]
        ? "border-red-300 focus:border-red-400 dark:border-red-800"
        : "border-gray-200 dark:border-gray-800"
    }`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate(`/admin/users/${id}`)}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-600 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
            <ArrowLeft size={18} />
          </button>

          <div>
            <h1 className="text-xl font-semibold tracking-tight text-gray-900 dark:text-white sm:text-2xl">
              Edit User
            </h1>

            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Update {existingUser.name}'s account information.
            </p>
          </div>
        </div>
      </div>

      {/* Success */}
      {success && (
        <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-400">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/50">
            <Check size={15} />
          </div>
          User updated successfully. Redirecting...
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          {/* Main */}
          <div className="space-y-6 xl:col-span-2">
            {/* User Information */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  User Information
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Update the user's basic information.
                </p>
              </div>

              <div className="p-5">
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  {/* Name */}
                  <div>
                    <label
                      htmlFor="name"
                      className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Full Name
                    </label>

                    <input
                      id="name"
                      name="name"
                      type="text"
                      value={formData.name}
                      onChange={handleChange}
                      className={inputClass("name")}
                    />

                    {errors.name && (
                      <p className="mt-1.5 text-xs text-red-500">
                        {errors.name}
                      </p>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <label
                      htmlFor="email"
                      className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Email Address
                    </label>

                    <input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={inputClass("email")}
                    />

                    {errors.email && (
                      <p className="mt-1.5 text-xs text-red-500">
                        {errors.email}
                      </p>
                    )}
                  </div>

                  {/* Phone */}
                  <div>
                    <label
                      htmlFor="phone"
                      className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Phone Number
                    </label>

                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleChange}
                      className={inputClass("phone")}
                    />

                    {errors.phone && (
                      <p className="mt-1.5 text-xs text-red-500">
                        {errors.phone}
                      </p>
                    )}
                  </div>

                  {/* Role */}
                  <div>
                    <label
                      htmlFor="role"
                      className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Role
                    </label>

                    <select
                      id="role"
                      name="role"
                      value={formData.role}
                      onChange={handleChange}
                      className={inputClass("role")}>
                      <option value="User">User</option>
                      <option value="Administrator">Administrator</option>
                      <option value="Manager">Manager</option>
                      <option value="Editor">Editor</option>
                    </select>
                  </div>

                  {/* Status */}
                  <div>
                    <label
                      htmlFor="status"
                      className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Status
                    </label>

                    <select
                      id="status"
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      className={inputClass("status")}>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Password */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <div className="flex items-center gap-2">
                  <Lock
                    size={17}
                    className="text-gray-500 dark:text-gray-400"
                  />

                  <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                    Change Password
                  </h2>
                </div>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Leave these fields empty if you don't want to change the
                  password.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-5 p-5 sm:grid-cols-2">
                {/* Password */}
                <div>
                  <label
                    htmlFor="password"
                    className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    New Password
                  </label>

                  <div className="relative">
                    <input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      value={formData.password}
                      onChange={handleChange}
                      placeholder="Leave empty to keep current password"
                      className={`${inputClass("password")} pr-11`}
                    />

                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                      {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                    </button>
                  </div>

                  {errors.password && (
                    <p className="mt-1.5 text-xs text-red-500">
                      {errors.password}
                    </p>
                  )}
                </div>

                {/* Confirm */}
                <div>
                  <label
                    htmlFor="confirmPassword"
                    className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Confirm New Password
                  </label>

                  <div className="relative">
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      placeholder="Repeat new password"
                      className={`${inputClass("confirmPassword")} pr-11`}
                    />

                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword((prev) => !prev)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                      {showConfirmPassword ? (
                        <EyeOff size={17} />
                      ) : (
                        <Eye size={17} />
                      )}
                    </button>
                  </div>

                  {errors.confirmPassword && (
                    <p className="mt-1.5 text-xs text-red-500">
                      {errors.confirmPassword}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col-reverse gap-3 rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => navigate(`/admin/users/${id}`)}
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white px-4 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
                <X size={16} />
                Cancel
              </button>

              <button
                type="submit"
                disabled={success}
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-900 px-4 text-sm font-medium text-white transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-200">
                <Save size={16} />
                Save Changes
              </button>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Profile Image
                </h2>

                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Change the user's profile photo.
                </p>
              </div>

              <div className="p-5">
                <div className="flex flex-col items-center">
                  <div className="relative">
                    {avatar ? (
                      <img
                        src={avatar}
                        alt={formData.name}
                        className="h-28 w-28 rounded-full object-cover ring-4 ring-gray-100 dark:ring-gray-800"
                      />
                    ) : (
                      <div className="flex h-28 w-28 items-center justify-center rounded-full bg-gray-100 text-2xl font-semibold text-gray-400 ring-4 ring-gray-50 dark:bg-gray-800 dark:ring-gray-900">
                        {formData.name
                          .split(" ")
                          .map((word) => word[0])
                          .join("")
                          .slice(0, 2)
                          .toUpperCase()}
                      </div>
                    )}

                    {avatar && (
                      <button
                        type="button"
                        onClick={removeAvatar}
                        className="absolute -right-1 -top-1 flex h-7 w-7 items-center justify-center rounded-full border border-gray-200 bg-white text-gray-500 shadow-sm transition hover:text-red-500 dark:border-gray-700 dark:bg-gray-900">
                        <X size={14} />
                      </button>
                    )}
                  </div>

                  <label className="mt-4 inline-flex h-9 cursor-pointer items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 text-xs font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
                    <ImagePlus size={15} />
                    Change Image
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarChange}
                      className="hidden"
                    />
                  </label>

                  <p className="mt-3 text-center text-xs text-gray-400">
                    JPG, PNG or WEBP. Maximum 2MB.
                  </p>

                  {errors.avatar && (
                    <p className="mt-2 text-xs text-red-500">{errors.avatar}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Role Information */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
                <div className="flex items-center gap-2">
                  <Shield
                    size={17}
                    className="text-gray-500 dark:text-gray-400"
                  />

                  <h2 className="text-sm font-semibold text-gray-900 dark:text-white">
                    User Role
                  </h2>
                </div>
              </div>

              <div className="p-5">
                <p className="text-sm leading-6 text-gray-500 dark:text-gray-400">
                  The selected role determines what this user can access inside
                  the dashboard.
                </p>

                <div className="mt-4 rounded-lg bg-gray-50 p-3.5 dark:bg-gray-950">
                  <p className="text-xs font-medium text-gray-700 dark:text-gray-300">
                    Current role
                  </p>

                  <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                    {formData.role}
                  </p>
                </div>
              </div>
            </div>

            {/* User Status */}
            <div className="rounded-xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Account Status
                  </p>

                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    Current account state
                  </p>
                </div>

                <span
                  className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                    formData.status === "Active"
                      ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400"
                      : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"
                  }`}>
                  {formData.status}
                </span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default EditUser;
