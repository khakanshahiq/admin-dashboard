import { useMemo, useState } from "react";
import {
  ChevronDown,
  MoreHorizontal,
  Plus,
  Search,
  ShieldCheck,
  UserCheck,
  UserPlus,
  Users as UsersIcon,
  UserX,
  Trash2,
  X,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const initialUsers = [
  {
    id: 1,
    name: "Alex Morgan",
    email: "alex.morgan@example.com",
    phone: "+1 202 555 0147",
    role: "Administrator",
    status: "Active",
    joined: "Aug 28, 2026",
    avatar: "AM",
  },
  {
    id: 2,
    name: "Sophia Carter",
    email: "sophia.carter@example.com",
    phone: "+1 202 555 0182",
    role: "Manager",
    status: "Active",
    joined: "Aug 25, 2026",
    avatar: "SC",
  },
  {
    id: 3,
    name: "Daniel Wilson",
    email: "daniel.wilson@example.com",
    phone: "+1 202 555 0116",
    role: "Editor",
    status: "Active",
    joined: "Aug 21, 2026",
    avatar: "DW",
  },
  {
    id: 4,
    name: "Emma Johnson",
    email: "emma.johnson@example.com",
    phone: "+1 202 555 0194",
    role: "User",
    status: "Inactive",
    joined: "Aug 18, 2026",
    avatar: "EJ",
  },
  {
    id: 5,
    name: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "+1 202 555 0163",
    role: "User",
    status: "Active",
    joined: "Aug 15, 2026",
    avatar: "MB",
  },
  {
    id: 6,
    name: "Olivia Davis",
    email: "olivia.davis@example.com",
    phone: "+1 202 555 0135",
    role: "Manager",
    status: "Active",
    joined: "Aug 12, 2026",
    avatar: "OD",
  },
  {
    id: 7,
    name: "James Miller",
    email: "james.miller@example.com",
    phone: "+1 202 555 0171",
    role: "User",
    status: "Inactive",
    joined: "Aug 09, 2026",
    avatar: "JM",
  },
  {
    id: 8,
    name: "Isabella Moore",
    email: "isabella.moore@example.com",
    phone: "+1 202 555 0128",
    role: "Editor",
    status: "Active",
    joined: "Aug 05, 2026",
    avatar: "IM",
  },
];

const roleStyles = {
  Administrator:
    "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",

  Manager: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",

  Editor: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300",

  User: "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400",
};

const statusStyles = {
  Active: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",

  Inactive: "bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-500",
};

const Users = () => {
  const navigate = useNavigate();

  // =========================================
  // STATE
  // =========================================

  const [users, setUsers] = useState(initialUsers);

  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [openMenu, setOpenMenu] = useState(null);
  const [deleteUser, setDeleteUser] = useState(null);

  const roles = ["All", "Administrator", "Manager", "Editor", "User"];

  const statuses = ["All", "Active", "Inactive"];

  // =========================================
  // FILTER USERS
  // =========================================

  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      const searchValue = search.toLowerCase().trim();

      const matchesSearch =
        user.name.toLowerCase().includes(searchValue) ||
        user.email.toLowerCase().includes(searchValue) ||
        user.phone.toLowerCase().includes(searchValue);

      const matchesRole = roleFilter === "All" || user.role === roleFilter;

      const matchesStatus =
        statusFilter === "All" || user.status === statusFilter;

      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [users, search, roleFilter, statusFilter]);

  // =========================================
  // USER STATS
  // =========================================

  const totalUsers = users.length;

  const activeUsers = users.filter((user) => user.status === "Active").length;

  const inactiveUsers = users.filter(
    (user) => user.status === "Inactive",
  ).length;

  const newUsers = users.filter((user) =>
    ["Aug 28, 2026", "Aug 25, 2026", "Aug 21, 2026"].includes(user.joined),
  ).length;

  // =========================================
  // FILTER HELPERS
  // =========================================

  const hasFilters = search || roleFilter !== "All" || statusFilter !== "All";

  const clearFilters = () => {
    setSearch("");
    setRoleFilter("All");
    setStatusFilter("All");
  };

  // =========================================
  // VIEW USER
  // =========================================

  const handleViewUser = (userId) => {
    setOpenMenu(null);

    navigate(`/admin/user/${userId}`);
  };

  // =========================================
  // EDIT USER
  // =========================================

  const handleEditUser = (userId) => {
    setOpenMenu(null);

    navigate(`/admin/user/${userId}/edit`);
  };

  // =========================================
  // OPEN DELETE MODAL
  // =========================================

  const handleDeleteUser = (userId) => {
    setOpenMenu(null);

    const user = users.find((item) => item.id === userId);

    if (!user) return;

    setDeleteUser(user);
  };

  // =========================================
  // CONFIRM DELETE USER
  // =========================================

  const confirmDeleteUser = () => {
    if (!deleteUser) return;

    setUsers((currentUsers) =>
      currentUsers.filter((user) => user.id !== deleteUser.id),
    );

    setDeleteUser(null);
    setOpenMenu(null);
  };

  // =========================================
  // ADD USER
  // =========================================

  const handleAddUser = () => {
    navigate("/admin/add/user");
  };

  return (
    <div className="space-y-6">
      {/* ================================================= */}
      {/* PAGE HEADER */}
      {/* ================================================= */}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-950 dark:text-white">
            Users
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Manage users, roles, and account access.
          </p>
        </div>

        <button
          type="button"
          onClick={handleAddUser}
          className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-gray-950 px-4 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200">
          <Plus size={17} />
          Add User
        </button>
      </div>

      {/* ================================================= */}
      {/* STATS */}
      {/* ================================================= */}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <SummaryCard
          icon={<UsersIcon size={16} />}
          label="Total users"
          value={totalUsers}
        />

        <SummaryCard
          icon={<UserCheck size={16} />}
          label="Active"
          value={activeUsers}
        />

        <SummaryCard
          icon={<UserX size={16} />}
          label="Inactive"
          value={inactiveUsers}
        />

        <SummaryCard
          icon={<UserPlus size={16} />}
          label="New users"
          value={newUsers}
        />
      </div>

      {/* ================================================= */}
      {/* MAIN CARD */}
      {/* ================================================= */}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        {/* ================================================= */}
        {/* TOOLBAR */}
        {/* ================================================= */}

        <div className="flex flex-col gap-3 border-b border-gray-200 p-4 dark:border-gray-800 lg:flex-row lg:items-center lg:justify-between">
          {/* SEARCH */}

          <div className="relative w-full lg:max-w-sm">
            <Search
              size={17}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
            />

            <input
              type="text"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search users..."
              className="h-10 w-full rounded-lg border border-gray-200 bg-white pl-10 pr-4 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-950 dark:text-white dark:focus:border-gray-300"
            />
          </div>

          {/* FILTERS */}

          <div className="flex flex-col gap-2 sm:flex-row">
            {/* ROLE */}

            <div className="relative">
              <select
                value={roleFilter}
                onChange={(event) => setRoleFilter(event.target.value)}
                className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-4 pr-9 text-sm text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 sm:w-40">
                {roles.map((role) => (
                  <option key={role} value={role}>
                    {role === "All" ? "All roles" : role}
                  </option>
                ))}
              </select>

              <ChevronDown
                size={15}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
            </div>

            {/* STATUS */}

            <div className="relative">
              <select
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
                className="h-10 w-full appearance-none rounded-lg border border-gray-200 bg-white px-4 pr-9 text-sm text-gray-700 outline-none transition focus:border-gray-900 dark:border-gray-700 dark:bg-gray-950 dark:text-gray-300 sm:w-36">
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status === "All" ? "All status" : status}
                  </option>
                ))}
              </select>

              <ChevronDown
                size={15}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
            </div>

            {/* CLEAR */}

            {hasFilters && (
              <button
                type="button"
                onClick={clearFilters}
                className="h-10 rounded-lg border border-gray-200 px-4 text-sm font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white">
                Clear
              </button>
            )}
          </div>
        </div>

        {/* ================================================= */}
        {/* RESULTS INFO */}
        {/* ================================================= */}

        <div className="border-b border-gray-200 px-4 py-3 dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Showing{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {filteredUsers.length}
            </span>{" "}
            of{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {users.length}
            </span>{" "}
            users
          </p>
        </div>

        {/* ================================================= */}
        {/* DESKTOP TABLE */}
        {/* ================================================= */}

        <div className="hidden overflow-x-auto md:block">
          <table className="w-full min-w-[850px]">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50/70 dark:border-gray-800 dark:bg-gray-950/40">
                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  User
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Contact
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Role
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Status
                </th>

                <th className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Joined
                </th>

                <th className="w-16 px-5 py-3.5"></th>
              </tr>
            </thead>

            <tbody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                  <tr
                    key={user.id}
                    className="border-b border-gray-100 transition hover:bg-gray-50 last:border-b-0 dark:border-gray-800 dark:hover:bg-gray-800/40">
                    {/* USER */}

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <Avatar user={user} />

                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                            {user.name}
                          </p>

                          <p className="mt-0.5 text-xs text-gray-400">
                            User #{String(user.id).padStart(4, "0")}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* CONTACT */}

                    <td className="px-5 py-4">
                      <div className="min-w-0">
                        <p className="truncate text-sm text-gray-600 dark:text-gray-400">
                          {user.email}
                        </p>

                        <p className="mt-0.5 text-xs text-gray-400">
                          {user.phone}
                        </p>
                      </div>
                    </td>

                    {/* ROLE */}

                    <td className="px-5 py-4">
                      <RoleBadge role={user.role} />
                    </td>

                    {/* STATUS */}

                    <td className="px-5 py-4">
                      <StatusBadge status={user.status} />
                    </td>

                    {/* JOINED */}

                    <td className="px-5 py-4 text-sm text-gray-600 dark:text-gray-400">
                      {user.joined}
                    </td>

                    {/* ACTION */}

                    <td className="relative px-5 py-4 text-right">
                      <button
                        type="button"
                        onClick={() =>
                          setOpenMenu(openMenu === user.id ? null : user.id)
                        }
                        className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                        aria-label={`Actions for ${user.name}`}>
                        <MoreHorizontal size={18} />
                      </button>

                      {openMenu === user.id && (
                        <ActionMenu
                          user={user}
                          onView={handleViewUser}
                          onEdit={handleEditUser}
                          onDelete={handleDeleteUser}
                          onClose={() => setOpenMenu(null)}
                        />
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="px-5 py-14 text-center">
                    <UsersIcon
                      size={28}
                      className="mx-auto text-gray-300 dark:text-gray-600"
                    />

                    <p className="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
                      No users found
                    </p>

                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      Try changing your search or filters.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* ================================================= */}
        {/* MOBILE CARDS */}
        {/* ================================================= */}

        <div className="divide-y divide-gray-100 md:hidden dark:divide-gray-800">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <div key={user.id} className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <Avatar user={user} />

                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
                        {user.name}
                      </p>

                      <p className="mt-0.5 truncate text-xs text-gray-400">
                        {user.email}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      setOpenMenu(openMenu === user.id ? null : user.id)
                    }
                    className="shrink-0 rounded-lg p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
                    aria-label={`Actions for ${user.name}`}>
                    <MoreHorizontal size={18} />
                  </button>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Role
                    </p>

                    <div className="mt-1.5">
                      <RoleBadge role={user.role} />
                    </div>
                  </div>

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Status
                    </p>

                    <div className="mt-1.5">
                      <StatusBadge status={user.status} />
                    </div>
                  </div>

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Phone
                    </p>

                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                      {user.phone}
                    </p>
                  </div>

                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-gray-400">
                      Joined
                    </p>

                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                      {user.joined}
                    </p>
                  </div>
                </div>

                {/* MOBILE ACTIONS */}

                {openMenu === user.id && (
                  <div className="mt-3 flex gap-2 border-t border-gray-100 pt-3 dark:border-gray-800">
                    {/* View */}

                    <button
                      type="button"
                      onClick={() => handleViewUser(user.id)}
                      className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
                      View
                    </button>

                    {/* Edit */}

                    <button
                      type="button"
                      onClick={() => handleEditUser(user.id)}
                      className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
                      Edit
                    </button>

                    {/* Delete */}

                    <button
                      type="button"
                      onClick={() => handleDeleteUser(user.id)}
                      className="flex-1 rounded-lg border border-red-200 px-3 py-2 text-xs font-medium text-red-500 transition hover:bg-red-50 dark:border-red-900/50 dark:hover:bg-red-950/30">
                      Delete
                    </button>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="px-5 py-14 text-center">
              <UsersIcon
                size={28}
                className="mx-auto text-gray-300 dark:text-gray-600"
              />

              <p className="mt-3 text-sm font-semibold text-gray-900 dark:text-white">
                No users found
              </p>

              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Try changing your search or filters.
              </p>
            </div>
          )}
        </div>

        {/* ================================================= */}
        {/* FOOTER / PAGINATION */}
        {/* ================================================= */}

        <div className="flex flex-col gap-3 border-t border-gray-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Showing{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {filteredUsers.length}
            </span>{" "}
            of{" "}
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {users.length}
            </span>{" "}
            users
          </p>

          <div className="flex items-center gap-1">
            <button
              type="button"
              disabled
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-400 dark:border-gray-700">
              Previous
            </button>

            <button
              type="button"
              className="rounded-lg bg-gray-950 px-3 py-2 text-xs font-semibold text-white dark:bg-white dark:text-gray-950">
              1
            </button>

            <button
              type="button"
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
              2
            </button>

            <button
              type="button"
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
              Next
            </button>
          </div>
        </div>
      </div>

      {/* ================================================= */}
      {/* DELETE USER MODAL */}
      {/* ================================================= */}

      {deleteUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white shadow-2xl dark:border-gray-800 dark:bg-gray-900">
            {/* Modal Header */}

            <div className="flex items-start justify-between gap-4 p-6">
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-500 dark:bg-red-950/40">
                  <Trash2 size={20} />
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-gray-950 dark:text-white">
                    Delete user?
                  </h2>

                  <p className="mt-1 text-sm leading-5 text-gray-500 dark:text-gray-400">
                    Are you sure you want to delete{" "}
                    <span className="font-medium text-gray-800 dark:text-gray-200">
                      {deleteUser.name}
                    </span>
                    ?
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setDeleteUser(null)}
                className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-white"
                aria-label="Close delete confirmation">
                <X size={18} />
              </button>
            </div>

            {/* Warning */}

            <div className="mx-6 rounded-lg border border-red-100 bg-red-50 px-4 py-3 dark:border-red-900/40 dark:bg-red-950/20">
              <p className="text-xs leading-5 text-red-600 dark:text-red-400">
                This action cannot be undone. The user will be permanently
                removed from your user list.
              </p>
            </div>

            {/* Actions */}

            <div className="flex flex-col-reverse gap-2 border-t border-gray-200 p-6 sm:flex-row sm:justify-end dark:border-gray-800">
              <button
                type="button"
                onClick={() => setDeleteUser(null)}
                className="h-10 rounded-lg border border-gray-200 px-4 text-sm font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white">
                Cancel
              </button>

              <button
                type="button"
                onClick={confirmDeleteUser}
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-red-500 px-4 text-sm font-semibold text-white transition hover:bg-red-600">
                <Trash2 size={16} />
                Delete User
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ================================================= */
/* SUMMARY CARD */
/* ================================================= */

const SummaryCard = ({ icon, label, value }) => {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
          {label}
        </p>

        <span className="text-gray-400">{icon}</span>
      </div>

      <p className="mt-2 text-xl font-bold text-gray-950 dark:text-white">
        {value}
      </p>
    </div>
  );
};

/* ================================================= */
/* AVATAR */
/* ================================================= */

const Avatar = ({ user }) => {
  return (
    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-xs font-bold text-gray-700 dark:bg-gray-800 dark:text-gray-200">
      {user.avatar}
    </div>
  );
};

/* ================================================= */
/* ROLE BADGE */
/* ================================================= */

const RoleBadge = ({ role }) => {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${
        roleStyles[role] || roleStyles.User
      }`}>
      {role === "Administrator" && <ShieldCheck size={12} />}

      {role}
    </span>
  );
};

/* ================================================= */
/* STATUS BADGE */
/* ================================================= */

const StatusBadge = ({ status }) => {
  const isActive = status === "Active";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${
        statusStyles[status]
      }`}>
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          isActive
            ? "bg-gray-900 dark:bg-white"
            : "bg-gray-400 dark:bg-gray-600"
        }`}
      />

      {status}
    </span>
  );
};

/* ================================================= */
/* ACTION MENU */
/* ================================================= */

const ActionMenu = ({ user, onView, onEdit, onDelete, onClose }) => {
  return (
    <div className="absolute right-5 top-12 z-20 w-32 overflow-hidden rounded-lg border border-gray-200 bg-white p-1 text-left shadow-lg dark:border-gray-700 dark:bg-gray-900">
      {/* View */}

      <button
        type="button"
        onClick={() => onView(user.id)}
        className="w-full rounded-md px-3 py-2 text-left text-sm text-gray-600 transition hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
        View
      </button>

      {/* Edit */}

      <button
        type="button"
        onClick={() => onEdit(user.id)}
        className="w-full rounded-md px-3 py-2 text-left text-sm text-gray-600 transition hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
        Edit
      </button>

      {/* Delete */}

      <button
        type="button"
        onClick={() => onDelete(user.id)}
        className="w-full rounded-md px-3 py-2 text-left text-sm text-red-500 transition hover:bg-red-50 dark:hover:bg-red-950/30">
        Delete
      </button>
    </div>
  );
};

export default Users;
