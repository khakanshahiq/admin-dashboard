import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Shield,
  ShoppingBag,
  DollarSign,
  Package,
  Edit,
} from "lucide-react";

export default function UserDetails() {
  const { id } = useParams();

  // Temporary user data
  // Later we can replace this with API data.
  const user = {
    id,
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 234 567 890",
    location: "New York, USA",
    role: "Customer",
    status: "Active",
    joined: "January 15, 2026",
    avatar: "https://i.pravatar.cc/150?img=12",
    orders: 24,
    totalSpent: "$2,450",
    products: 8,
    lastOrder: "September 5, 2026",
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Link
            to="/users"
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-600 transition hover:bg-gray-50">
            <ArrowLeft size={20} />
          </Link>

          <div>
            <h1 className="text-2xl font-bold text-gray-900">User Details</h1>

            <p className="mt-1 text-sm text-gray-500">
              View customer information and activity
            </p>
          </div>
        </div>

        <Link
          to={`/users/${id}/edit`}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-gray-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-gray-800">
          <Edit size={17} />
          Edit User
        </Link>
      </div>

      {/* Profile Card */}
      <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <img
              src={user.avatar}
              alt={user.name}
              className="h-20 w-20 rounded-full object-cover"
            />

            <div>
              <div className="flex flex-wrap items-center gap-3">
                <h2 className="text-xl font-bold text-gray-900">{user.name}</h2>

                <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-medium text-green-600">
                  {user.status}
                </span>
              </div>

              <p className="mt-1 text-sm text-gray-500">User ID: #{user.id}</p>

              <div className="mt-3 flex flex-wrap gap-4 text-sm text-gray-500">
                <span className="flex items-center gap-1.5">
                  <Mail size={15} />
                  {user.email}
                </span>

                <span className="flex items-center gap-1.5">
                  <Phone size={15} />
                  {user.phone}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg bg-gray-50 px-4 py-3">
            <Shield size={18} className="text-gray-600" />

            <div>
              <p className="text-xs text-gray-500">Account Role</p>

              <p className="text-sm font-semibold text-gray-900">{user.role}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Orders</p>

              <p className="mt-2 text-2xl font-bold text-gray-900">
                {user.orders}
              </p>
            </div>

            <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
              <ShoppingBag size={21} />
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Spent</p>

              <p className="mt-2 text-2xl font-bold text-gray-900">
                {user.totalSpent}
              </p>
            </div>

            <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-green-50 text-green-600">
              <DollarSign size={21} />
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Products</p>

              <p className="mt-2 text-2xl font-bold text-gray-900">
                {user.products}
              </p>
            </div>

            <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
              <Package size={21} />
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Member Since</p>

              <p className="mt-2 text-sm font-bold text-gray-900">
                {user.joined}
              </p>
            </div>

            <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
              <Calendar size={21} />
            </div>
          </div>
        </div>
      </div>

      {/* User Information */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Personal Information */}
        <div className="rounded-xl border border-gray-200 bg-white shadow-sm lg:col-span-2">
          <div className="border-b border-gray-200 px-6 py-4">
            <h3 className="font-semibold text-gray-900">
              Personal Information
            </h3>
          </div>

          <div className="grid grid-cols-1 gap-6 p-6 sm:grid-cols-2">
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
                Full Name
              </p>

              <p className="mt-1 text-sm font-medium text-gray-900">
                {user.name}
              </p>
            </div>

            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
                Email Address
              </p>

              <p className="mt-1 text-sm font-medium text-gray-900">
                {user.email}
              </p>
            </div>

            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
                Phone Number
              </p>

              <p className="mt-1 text-sm font-medium text-gray-900">
                {user.phone}
              </p>
            </div>

            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
                Role
              </p>

              <p className="mt-1 text-sm font-medium text-gray-900">
                {user.role}
              </p>
            </div>

            <div className="sm:col-span-2">
              <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
                Location
              </p>

              <p className="mt-1 flex items-center gap-2 text-sm font-medium text-gray-900">
                <MapPin size={16} className="text-gray-400" />
                {user.location}
              </p>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="rounded-xl border border-gray-200 bg-white shadow-sm">
          <div className="border-b border-gray-200 px-6 py-4">
            <h3 className="font-semibold text-gray-900">Recent Activity</h3>
          </div>

          <div className="space-y-5 p-6">
            <div className="flex gap-3">
              <div className="mt-1 h-2.5 w-2.5 rounded-full bg-green-500" />

              <div>
                <p className="text-sm font-medium text-gray-900">
                  Order completed
                </p>

                <p className="mt-1 text-xs text-gray-500">Order #ORD-1024</p>

                <p className="mt-1 text-xs text-gray-400">2 days ago</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="mt-1 h-2.5 w-2.5 rounded-full bg-blue-500" />

              <div>
                <p className="text-sm font-medium text-gray-900">
                  Profile updated
                </p>

                <p className="mt-1 text-xs text-gray-400">5 days ago</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="mt-1 h-2.5 w-2.5 rounded-full bg-purple-500" />

              <div>
                <p className="text-sm font-medium text-gray-900">
                  New order placed
                </p>

                <p className="mt-1 text-xs text-gray-500">Order #ORD-1018</p>

                <p className="mt-1 text-xs text-gray-400">1 week ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Last Order */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
          <h3 className="font-semibold text-gray-900">Order Information</h3>

          <Link
            to="/orders"
            className="text-sm font-medium text-gray-900 hover:underline">
            View all orders
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-6 p-6 sm:grid-cols-3">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
              Last Order
            </p>

            <p className="mt-1 text-sm font-semibold text-gray-900">
              #ORD-1024
            </p>
          </div>

          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
              Order Date
            </p>

            <p className="mt-1 text-sm font-semibold text-gray-900">
              {user.lastOrder}
            </p>
          </div>

          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
              Status
            </p>

            <span className="mt-1 inline-flex rounded-full bg-green-50 px-3 py-1 text-xs font-medium text-green-600">
              Completed
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
