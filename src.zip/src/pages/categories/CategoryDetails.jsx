import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  CalendarDays,
  Edit,
  FolderTree,
  Package,
  Tag,
  TrendingUp,
  CheckCircle2,
  Clock3,
} from "lucide-react";

const categories = [
  {
    id: 1,
    name: "Electronics",
    description:
      "Electronic devices, gadgets, accessories, computers and related products.",
    products: 124,
    status: "Active",
    createdAt: "Jan 12, 2026",
    updatedAt: "Sep 04, 2026",
  },
  {
    id: 2,
    name: "Fashion",
    description:
      "Clothing, shoes, bags, accessories and other fashion products.",
    products: 98,
    status: "Active",
    createdAt: "Jan 18, 2026",
    updatedAt: "Sep 02, 2026",
  },
  {
    id: 3,
    name: "Home & Living",
    description:
      "Furniture, home decoration, kitchen items and household products.",
    products: 76,
    status: "Active",
    createdAt: "Feb 03, 2026",
    updatedAt: "Aug 29, 2026",
  },
  {
    id: 4,
    name: "Sports",
    description: "Sports equipment, fitness products and outdoor accessories.",
    products: 54,
    status: "Active",
    createdAt: "Feb 15, 2026",
    updatedAt: "Aug 27, 2026",
  },
  {
    id: 5,
    name: "Books",
    description:
      "Books, magazines, educational material and reading resources.",
    products: 42,
    status: "Inactive",
    createdAt: "Mar 01, 2026",
    updatedAt: "Aug 20, 2026",
  },
  {
    id: 6,
    name: "Beauty",
    description:
      "Beauty products, skincare, cosmetics and personal care products.",
    products: 38,
    status: "Active",
    createdAt: "Mar 12, 2026",
    updatedAt: "Aug 18, 2026",
  },
  {
    id: 7,
    name: "Automotive",
    description: "Cars, motorcycles, automotive parts and vehicle accessories.",
    products: 31,
    status: "Active",
    createdAt: "Apr 04, 2026",
    updatedAt: "Aug 15, 2026",
  },
  {
    id: 8,
    name: "Toys & Games",
    description:
      "Toys, games, puzzles and entertainment products for children.",
    products: 27,
    status: "Inactive",
    createdAt: "Apr 18, 2026",
    updatedAt: "Aug 10, 2026",
  },
];

const recentProducts = [
  {
    id: 1,
    name: "MacBook Pro 16",
    price: "$2,499",
    status: "Active",
  },
  {
    id: 2,
    name: "iPhone 17 Pro",
    price: "$1,199",
    status: "Active",
  },
  {
    id: 3,
    name: "Sony WH-1000XM6",
    price: "$449",
    status: "Active",
  },
  {
    id: 4,
    name: "Dell UltraSharp Monitor",
    price: "$699",
    status: "Pending",
  },
  {
    id: 5,
    name: "Apple iPad Pro",
    price: "$999",
    status: "Active",
  },
];

export default function CategoryDetails() {
  const { id } = useParams();

  const category = categories.find((item) => item.id === Number(id));

  if (!category) {
    return (
      <div className="min-h-screen bg-slate-50 p-4 sm:p-6 dark:bg-slate-950">
        <div className="mx-auto max-w-4xl">
          <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-red-100 text-red-600 dark:bg-red-500/10 dark:text-red-400">
              <FolderTree size={28} />
            </div>

            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              Category Not Found
            </h1>

            <p className="mx-auto mt-2 max-w-md text-sm text-slate-500 dark:text-slate-400">
              The category you are trying to view does not exist or may have
              been removed.
            </p>

            <Link
              to="/admin/categories"
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200">
              <ArrowLeft size={17} />
              Back to Categories
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-6 dark:bg-slate-950">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <Link
              to="/admin/categories"
              className="mb-3 inline-flex items-center gap-2 text-sm font-medium text-slate-500 transition hover:text-slate-900 dark:text-slate-400 dark:hover:text-white">
              <ArrowLeft size={16} />
              Back to Categories
            </Link>

            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-100 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
                <FolderTree size={22} />
              </div>

              <div>
                <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                  {category.name}
                </h1>

                <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                  Category details and product overview
                </p>
              </div>
            </div>
          </div>

          <Link
            to={`/admin/category/${category.id}/edit`}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200">
            <Edit size={17} />
            Edit Category
          </Link>
        </div>

        {/* Stats */}
        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* Products */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Total Products
                </p>

                <h2 className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
                  {category.products}
                </h2>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-100 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
                <Package size={20} />
              </div>
            </div>

            <div className="mt-4 flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
              <TrendingUp size={14} />
              12.5% this month
            </div>
          </div>

          {/* Status */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Category Status
                </p>

                <h2 className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
                  {category.status}
                </h2>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400">
                <CheckCircle2 size={20} />
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-400">
              Current visibility status
            </p>
          </div>

          {/* Created */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Created
                </p>

                <h2 className="mt-2 text-lg font-bold text-slate-900 dark:text-white">
                  {category.createdAt}
                </h2>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400">
                <CalendarDays size={20} />
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-400">
              Category creation date
            </p>
          </div>

          {/* Updated */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Last Updated
                </p>

                <h2 className="mt-2 text-lg font-bold text-slate-900 dark:text-white">
                  {category.updatedAt}
                </h2>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400">
                <Clock3 size={20} />
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-400">
              Most recent modification
            </p>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Category Information */}
          <div className="lg:col-span-1">
            <div className="rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="border-b border-slate-200 p-6 dark:border-slate-800">
                <h2 className="font-semibold text-slate-900 dark:text-white">
                  Category Information
                </h2>

                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  General information about this category.
                </p>
              </div>

              <div className="space-y-6 p-6">
                {/* Category icon */}
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
                    <Tag size={25} />
                  </div>

                  <div className="min-w-0">
                    <h3 className="truncate font-bold text-slate-900 dark:text-white">
                      {category.name}
                    </h3>

                    <span
                      className={`mt-1 inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${
                        category.status === "Active"
                          ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400"
                          : "bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                      }`}>
                      {category.status}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Description
                  </p>

                  <p className="text-sm leading-6 text-slate-600 dark:text-slate-300">
                    {category.description}
                  </p>
                </div>

                {/* Details */}
                <div className="space-y-4 border-t border-slate-200 pt-5 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">
                      Category ID
                    </span>

                    <span className="text-sm font-semibold text-slate-900 dark:text-white">
                      #{category.id}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">
                      Products
                    </span>

                    <span className="text-sm font-semibold text-slate-900 dark:text-white">
                      {category.products}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">
                      Status
                    </span>

                    <span
                      className={`text-sm font-semibold ${
                        category.status === "Active"
                          ? "text-emerald-600 dark:text-emerald-400"
                          : "text-slate-500"
                      }`}>
                      {category.status}
                    </span>
                  </div>
                </div>

                {/* Edit */}
                <Link
                  to={`/admin/category/${category.id}/edit`}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800">
                  <Edit size={16} />
                  Edit Category
                </Link>
              </div>
            </div>
          </div>

          {/* Products */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-col gap-3 border-b border-slate-200 p-6 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800">
                <div>
                  <h2 className="font-semibold text-slate-900 dark:text-white">
                    Recent Products
                  </h2>

                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    Recently added products in this category.
                  </p>
                </div>

                <Link
                  to="/admin/products"
                  className="text-sm font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400">
                  View All
                </Link>
              </div>

              {/* Desktop table */}
              <div className="hidden overflow-x-auto md:block">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-950">
                      <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Product
                      </th>

                      <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Price
                      </th>

                      <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Status
                      </th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                    {recentProducts.map((product) => (
                      <tr
                        key={product.id}
                        className="transition hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                              <Package size={18} />
                            </div>

                            <div>
                              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                                {product.name}
                              </p>

                              <p className="mt-0.5 text-xs text-slate-400">
                                Product #{product.id}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="px-6 py-4 text-sm font-semibold text-slate-700 dark:text-slate-200">
                          {product.price}
                        </td>

                        <td className="px-6 py-4">
                          <span
                            className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                              product.status === "Active"
                                ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400"
                                : "bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400"
                            }`}>
                            {product.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile cards */}
              <div className="divide-y divide-slate-200 md:hidden dark:divide-slate-800">
                {recentProducts.map((product) => (
                  <div key={product.id} className="p-5">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex min-w-0 items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                          <Package size={18} />
                        </div>

                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-slate-900 dark:text-white">
                            {product.name}
                          </p>

                          <p className="mt-1 text-xs text-slate-400">
                            Product #{product.id}
                          </p>
                        </div>
                      </div>

                      <span
                        className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                          product.status === "Active"
                            ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400"
                            : "bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400"
                        }`}>
                        {product.status}
                      </span>
                    </div>

                    <div className="mt-4 flex items-center justify-between">
                      <span className="text-xs text-slate-400">Price</span>

                      <span className="text-sm font-bold text-slate-900 dark:text-white">
                        {product.price}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Activity */}
            <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="mb-5">
                <h2 className="font-semibold text-slate-900 dark:text-white">
                  Category Activity
                </h2>

                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Recent activity related to this category.
                </p>
              </div>

              <div className="space-y-5">
                <div className="flex gap-4">
                  <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
                    <Edit size={15} />
                  </div>

                  <div>
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                      Category information updated
                    </p>

                    <p className="mt-1 text-xs text-slate-400">
                      {category.updatedAt}
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400">
                    <Package size={15} />
                  </div>

                  <div>
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                      Products are being managed in this category
                    </p>

                    <p className="mt-1 text-xs text-slate-400">
                      {category.products} products currently assigned
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
