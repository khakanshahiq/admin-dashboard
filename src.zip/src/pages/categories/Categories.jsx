import { useMemo, useState } from "react";
import {
  ChevronDown,
  Edit,
  FolderTree,
  MoreHorizontal,
  Plus,
  Search,
  Trash2,
  X,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const initialCategories = [
  {
    id: 1,
    name: "Electronics",
    description: "Phones, laptops, computers and electronic devices",
    products: 124,
    status: "Active",
    date: "Aug 28, 2026",
  },
  {
    id: 2,
    name: "Fashion",
    description: "Clothing, shoes, accessories and fashion items",
    products: 98,
    status: "Active",
    date: "Aug 27, 2026",
  },
  {
    id: 3,
    name: "Home & Living",
    description: "Furniture, home decor and household products",
    products: 76,
    status: "Active",
    date: "Aug 26, 2026",
  },
  {
    id: 4,
    name: "Sports",
    description: "Sports equipment, fitness and outdoor products",
    products: 54,
    status: "Active",
    date: "Aug 25, 2026",
  },
  {
    id: 5,
    name: "Books",
    description: "Books, magazines and educational materials",
    products: 42,
    status: "Inactive",
    date: "Aug 24, 2026",
  },
  {
    id: 6,
    name: "Beauty",
    description: "Beauty, skincare and personal care products",
    products: 38,
    status: "Active",
    date: "Aug 23, 2026",
  },
  {
    id: 7,
    name: "Automotive",
    description: "Cars, bikes, accessories and automotive products",
    products: 31,
    status: "Active",
    date: "Aug 22, 2026",
  },
  {
    id: 8,
    name: "Toys & Games",
    description: "Toys, games and entertainment products",
    products: 27,
    status: "Inactive",
    date: "Aug 21, 2026",
  },
];

const statusStyles = {
  Active: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  Inactive: "bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-400",
};

const Categories = () => {
  const navigate = useNavigate();

  const [categories, setCategories] = useState(initialCategories);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [openMenu, setOpenMenu] = useState(null);
  const [deleteCategory, setDeleteCategory] = useState(null);

  const statuses = ["All", "Active", "Inactive"];

  const filteredCategories = useMemo(() => {
    const searchValue = search.toLowerCase().trim();

    return categories.filter((category) => {
      const matchesSearch =
        category.name.toLowerCase().includes(searchValue) ||
        category.description.toLowerCase().includes(searchValue);

      const matchesStatus =
        statusFilter === "All" || category.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [categories, search, statusFilter]);

  const totalCategories = categories.length;

  const activeCategories = categories.filter(
    (category) => category.status === "Active",
  ).length;

  const inactiveCategories = categories.filter(
    (category) => category.status === "Inactive",
  ).length;

  const totalProducts = categories.reduce(
    (total, category) => total + category.products,
    0,
  );

  const hasFilters = search || statusFilter !== "All";

  const clearFilters = () => {
    setSearch("");
    setStatusFilter("All");
  };

  const handleAddCategory = () => {
    navigate("/admin/add/category");
  };

  const handleViewCategory = (id) => {
    setOpenMenu(null);
    navigate(`/admin/category/${id}`);
  };

  const handleEditCategory = (id) => {
    setOpenMenu(null);
    navigate(`/admin/category/${id}/edit`);
  };

  const handleDeleteCategory = (category) => {
    setOpenMenu(null);
    setDeleteCategory(category);
  };

  const confirmDeleteCategory = () => {
    if (!deleteCategory) return;

    setCategories((currentCategories) =>
      currentCategories.filter((category) => category.id !== deleteCategory.id),
    );

    setDeleteCategory(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
            Categories
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Manage your product categories and organize your catalog.
          </p>
        </div>

        <button
          type="button"
          onClick={handleAddCategory}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-gray-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100">
          <Plus size={18} />
          Add Category
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryCard
          title="Total Categories"
          value={totalCategories}
          icon={<FolderTree size={20} />}
        />

        <SummaryCard
          title="Active"
          value={activeCategories}
          icon={<FolderTree size={20} />}
        />

        <SummaryCard
          title="Inactive"
          value={inactiveCategories}
          icon={<FolderTree size={20} />}
        />

        <SummaryCard
          title="Total Products"
          value={totalProducts}
          icon={<FolderTree size={20} />}
        />
      </div>

      {/* Filters */}
      <div className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          {/* Search */}
          <div className="relative flex-1">
            <Search
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
            />

            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search categories..."
              className="w-full rounded-xl border border-gray-200 bg-gray-50 py-2.5 pl-10 pr-4 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-gray-400 focus:bg-white dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:placeholder:text-gray-500 dark:focus:border-gray-600 dark:focus:bg-gray-800"
            />
          </div>

          {/* Status */}
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full appearance-none rounded-xl border border-gray-200 bg-gray-50 py-2.5 pl-4 pr-10 text-sm text-gray-700 outline-none focus:border-gray-400 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 sm:w-44">
              {statuses.map((status) => (
                <option key={status} value={status}>
                  {status === "All" ? "All Statuses" : status}
                </option>
              ))}
            </select>

            <ChevronDown
              size={16}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
            />
          </div>

          {hasFilters && (
            <button
              type="button"
              onClick={clearFilters}
              className="rounded-xl px-3 py-2.5 text-sm font-medium text-gray-600 transition hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800">
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Results */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Showing{" "}
          <span className="font-medium text-gray-900 dark:text-white">
            {filteredCategories.length}
          </span>{" "}
          of{" "}
          <span className="font-medium text-gray-900 dark:text-white">
            {categories.length}
          </span>{" "}
          categories
        </p>
      </div>

      {/* Desktop Table */}
      <div className="hidden overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm dark:border-gray-800 dark:bg-gray-900 md:block">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50 dark:border-gray-800 dark:bg-gray-800/50">
                <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Category
                </th>

                <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Products
                </th>

                <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Status
                </th>

                <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Created
                </th>

                <th className="px-6 py-4 text-right text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filteredCategories.length > 0 ? (
                filteredCategories.map((category) => (
                  <tr
                    key={category.id}
                    className="transition hover:bg-gray-50 dark:hover:bg-gray-800/40">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                          <FolderTree size={19} />
                        </div>

                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">
                            {category.name}
                          </p>

                          <p className="mt-0.5 max-w-md truncate text-sm text-gray-500 dark:text-gray-400">
                            {category.description}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4 text-sm text-gray-700 dark:text-gray-300">
                      {category.products}
                    </td>

                    <td className="px-6 py-4">
                      <StatusBadge status={category.status} />
                    </td>

                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                      {category.date}
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex justify-end">
                        <ActionMenu
                          category={category}
                          openMenu={openMenu}
                          setOpenMenu={setOpenMenu}
                          onView={handleViewCategory}
                          onEdit={handleEditCategory}
                          onDelete={handleDeleteCategory}
                        />
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <EmptyState />
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile Cards */}
      <div className="space-y-4 md:hidden">
        {filteredCategories.length > 0 ? (
          filteredCategories.map((category) => (
            <div
              key={category.id}
              className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                    <FolderTree size={19} />
                  </div>

                  <div className="min-w-0">
                    <h3 className="truncate font-medium text-gray-900 dark:text-white">
                      {category.name}
                    </h3>

                    <p className="mt-1 truncate text-sm text-gray-500 dark:text-gray-400">
                      {category.description}
                    </p>
                  </div>
                </div>

                <ActionMenu
                  category={category}
                  openMenu={openMenu}
                  setOpenMenu={setOpenMenu}
                  onView={handleViewCategory}
                  onEdit={handleEditCategory}
                  onDelete={handleDeleteCategory}
                />
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 border-t border-gray-100 pt-4 dark:border-gray-800">
                <div>
                  <p className="text-xs text-gray-400">Products</p>
                  <p className="mt-1 text-sm font-medium text-gray-900 dark:text-white">
                    {category.products}
                  </p>
                </div>

                <div>
                  <p className="text-xs text-gray-400">Status</p>
                  <div className="mt-1">
                    <StatusBadge status={category.status} />
                  </div>
                </div>

                <div className="col-span-2">
                  <p className="text-xs text-gray-400">Created</p>
                  <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                    {category.date}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="rounded-2xl border border-gray-200 bg-white p-10 text-center dark:border-gray-800 dark:bg-gray-900">
            <EmptyStateContent />
          </div>
        )}
      </div>

      {/* Pagination */}
      {filteredCategories.length > 0 && (
        <div className="flex flex-col gap-3 border-t border-gray-200 pt-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Page 1 of 1
          </p>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled
              className="rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-400 dark:border-gray-800">
              Previous
            </button>

            <button
              type="button"
              className="rounded-lg bg-gray-900 px-3 py-2 text-sm font-medium text-white dark:bg-white dark:text-gray-900">
              1
            </button>

            <button
              type="button"
              disabled
              className="rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-400 dark:border-gray-800">
              Next
            </button>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {deleteCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-gray-900">
            <div className="flex items-start justify-between">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300">
                <Trash2 size={20} />
              </div>

              <button
                type="button"
                onClick={() => setDeleteCategory(null)}
                className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-800 dark:hover:text-gray-300">
                <X size={18} />
              </button>
            </div>

            <div className="mt-5">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Delete category?
              </h2>

              <p className="mt-2 text-sm leading-6 text-gray-500 dark:text-gray-400">
                Are you sure you want to delete{" "}
                <span className="font-medium text-gray-900 dark:text-white">
                  {deleteCategory.name}
                </span>
                ? This action cannot be undone in the demo.
              </p>
            </div>

            <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setDeleteCategory(null)}
                className="rounded-xl border border-gray-200 px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
                Keep Category
              </button>

              <button
                type="button"
                onClick={confirmDeleteCategory}
                className="rounded-xl bg-gray-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100">
                Delete Category
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* Summary Card */
const SummaryCard = ({ title, value, icon }) => {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>

          <p className="mt-2 text-2xl font-semibold text-gray-900 dark:text-white">
            {value.toLocaleString()}
          </p>
        </div>

        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
          {icon}
        </div>
      </div>
    </div>
  );
};

/* Status Badge */
const StatusBadge = ({ status }) => {
  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${
        statusStyles[status] || ""
      }`}>
      {status}
    </span>
  );
};

/* Action Menu */
const ActionMenu = ({
  category,
  openMenu,
  setOpenMenu,
  onView,
  onEdit,
  onDelete,
}) => {
  const isOpen = openMenu === category.id;

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpenMenu(isOpen ? null : category.id)}
        className="rounded-lg p-2 text-gray-500 transition hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-200"
        aria-label="Category actions">
        <MoreHorizontal size={19} />
      </button>

      {isOpen && (
        <div className="absolute right-0 z-20 mt-2 w-40 overflow-hidden rounded-xl border border-gray-200 bg-white py-1 shadow-lg dark:border-gray-700 dark:bg-gray-900">
          <button
            type="button"
            onClick={() => onView(category.id)}
            className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-gray-700 transition hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800">
            <FolderTree size={16} />
            View
          </button>

          <button
            type="button"
            onClick={() => onEdit(category.id)}
            className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-gray-700 transition hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800">
            <Edit size={16} />
            Edit
          </button>

          <button
            type="button"
            onClick={() => onDelete(category)}
            className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-gray-700 transition hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800">
            <Trash2 size={16} />
            Delete
          </button>
        </div>
      )}
    </div>
  );
};

/* Empty State */
const EmptyState = () => {
  return (
    <tr>
      <td colSpan="5">
        <EmptyStateContent />
      </td>
    </tr>
  );
};

const EmptyStateContent = () => {
  return (
    <div className="flex flex-col items-center justify-center py-14 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
        <FolderTree size={24} />
      </div>

      <h3 className="mt-4 text-sm font-semibold text-gray-900 dark:text-white">
        No categories found
      </h3>

      <p className="mt-1 max-w-sm text-sm text-gray-500 dark:text-gray-400">
        Try changing your search or filters to find what you're looking for.
      </p>
    </div>
  );
};

export default Categories;
