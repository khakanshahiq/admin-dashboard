import { useState } from "react";
import { ArrowLeft, FolderTree, Save } from "lucide-react";
import { useNavigate } from "react-router-dom";

const AddCategory = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    status: "Active",
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "Category name is required.";
    } else if (formData.name.trim().length < 2) {
      newErrors.name = "Category name must be at least 2 characters.";
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required.";
    } else if (formData.description.trim().length < 10) {
      newErrors.description = "Description must be at least 10 characters.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    setSubmitted(true);

    // Frontend demo only.
    // Later this will be replaced with an API request.

    setTimeout(() => {
      navigate("/admin/categories");
    }, 700);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate("/admin/categories")}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-gray-200 bg-white text-gray-600 transition hover:bg-gray-50 hover:text-black dark:border-gray-800 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
            aria-label="Back to categories">
            <ArrowLeft size={18} />
          </button>

          <div>
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
              Add Category
            </h1>

            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Create a new product category for your catalog.
            </p>
          </div>
        </div>
      </div>

      {/* Success Message */}
      {submitted && (
        <div className="rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">
          Category created successfully. Redirecting...
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          {/* Main Form */}
          <div className="xl:col-span-2">
            <div className="rounded-2xl border border-gray-200 bg-white shadow-sm dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-6 py-5 dark:border-gray-800">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                    <FolderTree size={19} />
                  </div>

                  <div>
                    <h2 className="font-semibold text-gray-900 dark:text-white">
                      Category Information
                    </h2>

                    <p className="mt-0.5 text-sm text-gray-500 dark:text-gray-400">
                      Enter the basic information for this category.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-6 p-6">
                {/* Category Name */}
                <div>
                  <label
                    htmlFor="name"
                    className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Category Name
                    <span className="ml-1 text-red-500">*</span>
                  </label>

                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="e.g. Electronics"
                    className={`w-full rounded-xl border bg-gray-50 px-4 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:bg-white dark:bg-gray-800 dark:text-white dark:focus:bg-gray-800 ${
                      errors.name
                        ? "border-red-300 focus:border-red-400 dark:border-red-700"
                        : "border-gray-200 focus:border-gray-400 dark:border-gray-700 dark:focus:border-gray-500"
                    }`}
                  />

                  {errors.name && (
                    <p className="mt-2 text-xs text-red-500">{errors.name}</p>
                  )}
                </div>

                {/* Description */}
                <div>
                  <label
                    htmlFor="description"
                    className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Description
                    <span className="ml-1 text-red-500">*</span>
                  </label>

                  <textarea
                    id="description"
                    name="description"
                    rows={5}
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Describe what products belong in this category..."
                    className={`w-full resize-none rounded-xl border bg-gray-50 px-4 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:bg-white dark:bg-gray-800 dark:text-white dark:focus:bg-gray-800 ${
                      errors.description
                        ? "border-red-300 focus:border-red-400 dark:border-red-700"
                        : "border-gray-200 focus:border-gray-400 dark:border-gray-700 dark:focus:border-gray-500"
                    }`}
                  />

                  <div className="mt-2 flex items-center justify-between">
                    {errors.description ? (
                      <p className="text-xs text-red-500">
                        {errors.description}
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400">
                        Keep the description clear and useful.
                      </p>
                    )}

                    <span className="text-xs text-gray-400">
                      {formData.description.length}/500
                    </span>
                  </div>
                </div>

                {/* Status */}
                <div>
                  <label
                    htmlFor="status"
                    className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Status
                  </label>

                  <select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm text-gray-900 outline-none transition focus:border-gray-400 focus:bg-white dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:focus:border-gray-500 dark:focus:bg-gray-800 sm:w-64">
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>

                  <p className="mt-2 text-xs text-gray-400">
                    Inactive categories won't be available for new products.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Preview */}
          <div>
            <div className="rounded-2xl border border-gray-200 bg-white shadow-sm dark:border-gray-800 dark:bg-gray-900">
              <div className="border-b border-gray-200 px-6 py-5 dark:border-gray-800">
                <h2 className="font-semibold text-gray-900 dark:text-white">
                  Preview
                </h2>

                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  See how your category will appear.
                </p>
              </div>

              <div className="p-6">
                <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                      <FolderTree size={20} />
                    </div>

                    <div className="min-w-0">
                      <h3 className="truncate font-semibold text-gray-900 dark:text-white">
                        {formData.name || "Category Name"}
                      </h3>

                      <p className="mt-1 text-xs text-gray-400">0 products</p>
                    </div>
                  </div>

                  <p className="mt-4 text-sm leading-6 text-gray-500 dark:text-gray-400">
                    {formData.description ||
                      "Your category description will appear here."}
                  </p>

                  <div className="mt-4">
                    <span className="inline-flex rounded-full bg-gray-100 px-2.5 py-1 text-xs font-medium text-gray-700 dark:bg-gray-800 dark:text-gray-300">
                      {formData.status}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Form Actions */}
        <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={() => navigate("/admin/categories")}
            className="rounded-xl border border-gray-200 bg-white px-5 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
            Cancel
          </button>

          <button
            type="submit"
            disabled={submitted}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gray-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100">
            <Save size={17} />
            {submitted ? "Creating..." : "Create Category"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddCategory;
