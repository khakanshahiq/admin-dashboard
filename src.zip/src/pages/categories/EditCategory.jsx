import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  FolderTree,
  Save,
  Tag,
} from "lucide-react";

const categories = [
  {
    id: 1,
    name: "Electronics",
    description:
      "Electronic devices, gadgets, accessories, computers and related products.",
    products: 124,
    status: "Active",
  },
  {
    id: 2,
    name: "Fashion",
    description:
      "Clothing, shoes, bags, accessories and other fashion products.",
    products: 98,
    status: "Active",
  },
  {
    id: 3,
    name: "Home & Living",
    description:
      "Furniture, home decoration, kitchen items and household products.",
    products: 76,
    status: "Active",
  },
  {
    id: 4,
    name: "Sports",
    description: "Sports equipment, fitness products and outdoor accessories.",
    products: 54,
    status: "Active",
  },
  {
    id: 5,
    name: "Books",
    description:
      "Books, magazines, educational material and reading resources.",
    products: 42,
    status: "Inactive",
  },
  {
    id: 6,
    name: "Beauty",
    description:
      "Beauty products, skincare, cosmetics and personal care products.",
    products: 38,
    status: "Active",
  },
  {
    id: 7,
    name: "Automotive",
    description: "Cars, motorcycles, automotive parts and vehicle accessories.",
    products: 31,
    status: "Active",
  },
  {
    id: 8,
    name: "Toys & Games",
    description:
      "Toys, games, puzzles and entertainment products for children.",
    products: 27,
    status: "Inactive",
  },
];

export default function EditCategory() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    status: "Active",
  });

  const [errors, setErrors] = useState({});
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const category = categories.find((item) => item.id === Number(id));

    if (category) {
      setFormData({
        name: category.name,
        description: category.description,
        status: category.status,
      });
    }
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "Category name is required.";
    } else if (formData.name.trim().length < 2) {
      newErrors.name = "Category name must be at least 2 characters.";
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required.";
    } else if (formData.description.trim().length < 10) {
      newErrors.description = "Description must be at least 10 characters.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    setSaved(true);

    setTimeout(() => {
      navigate("/admin/categories");
    }, 700);
  };

  const categoryExists = categories.some((item) => item.id === Number(id));

  if (!categoryExists) {
    return (
      <div className="min-h-screen bg-slate-50 p-6 dark:bg-slate-950">
        <div className="mx-auto max-w-3xl">
          <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-red-100 text-red-600 dark:bg-red-500/10 dark:text-red-400">
              <FolderTree size={26} />
            </div>

            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Category Not Found
            </h2>

            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
              The category you are trying to edit does not exist.
            </p>

            <Link
              to="/admin/categories"
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200">
              <ArrowLeft size={17} />
              Back to Categories
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-6 dark:bg-slate-950">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <Link
              to="/admin/categories"
              className="mb-3 inline-flex items-center gap-2 text-sm font-medium text-slate-500 transition hover:text-slate-900 dark:text-slate-400 dark:hover:text-white">
              <ArrowLeft size={16} />
              Back to Categories
            </Link>

            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Edit Category
            </h1>

            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Update category information and settings.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/admin/categories"
              className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800">
              Cancel
            </Link>

            <button
              onClick={handleSubmit}
              disabled={saved}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200">
              {saved ? <Check size={17} /> : <Save size={17} />}
              {saved ? "Saved" : "Save Changes"}
            </button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Form */}
          <div className="lg:col-span-2">
            <form
              onSubmit={handleSubmit}
              className="rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="border-b border-slate-200 p-6 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-100 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
                    <FolderTree size={20} />
                  </div>

                  <div>
                    <h2 className="font-semibold text-slate-900 dark:text-white">
                      Category Information
                    </h2>

                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Modify the details below.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-6 p-6">
                {/* Name */}
                <div>
                  <label className="mb-2 block text-sm font-semibold text-slate-700 dark:text-slate-200">
                    Category Name
                  </label>

                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter category name"
                    className={`w-full rounded-xl border bg-white px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:ring-2 dark:bg-slate-950 dark:text-white ${
                      errors.name
                        ? "border-red-400 focus:border-red-400 focus:ring-red-100 dark:border-red-500"
                        : "border-slate-200 focus:border-indigo-500 focus:ring-indigo-100 dark:border-slate-700 dark:focus:border-indigo-500"
                    }`}
                  />

                  {errors.name && (
                    <p className="mt-2 text-xs font-medium text-red-500">
                      {errors.name}
                    </p>
                  )}
                </div>

                {/* Description */}
                <div>
                  <label className="mb-2 block text-sm font-semibold text-slate-700 dark:text-slate-200">
                    Description
                  </label>

                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows={5}
                    placeholder="Enter category description"
                    className={`w-full resize-none rounded-xl border bg-white px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:ring-2 dark:bg-slate-950 dark:text-white ${
                      errors.description
                        ? "border-red-400 focus:border-red-400 focus:ring-red-100 dark:border-red-500"
                        : "border-slate-200 focus:border-indigo-500 focus:ring-indigo-100 dark:border-slate-700 dark:focus:border-indigo-500"
                    }`}
                  />

                  <div className="mt-2 flex items-center justify-between">
                    {errors.description ? (
                      <p className="text-xs font-medium text-red-500">
                        {errors.description}
                      </p>
                    ) : (
                      <p className="text-xs text-slate-400">
                        Describe what products belong to this category.
                      </p>
                    )}

                    <span className="text-xs text-slate-400">
                      {formData.description.length}/300
                    </span>
                  </div>
                </div>

                {/* Status */}
                <div>
                  <label className="mb-2 block text-sm font-semibold text-slate-700 dark:text-slate-200">
                    Status
                  </label>

                  <div className="relative">
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      className="w-full appearance-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-950 dark:text-white dark:focus:border-indigo-500">
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>

                    <ChevronDown
                      size={17}
                      className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"
                    />
                  </div>
                </div>
              </div>

              {/* Bottom actions */}
              <div className="flex flex-col-reverse gap-3 border-t border-slate-200 p-6 sm:flex-row sm:justify-end dark:border-slate-800">
                <Link
                  to="/admin/categories"
                  className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800">
                  Cancel
                </Link>

                <button
                  type="submit"
                  disabled={saved}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-70">
                  {saved ? <Check size={17} /> : <Save size={17} />}
                  {saved ? "Changes Saved" : "Save Changes"}
                </button>
              </div>
            </form>
          </div>

          {/* Preview */}
          <div>
            <div className="sticky top-6 rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="border-b border-slate-200 p-6 dark:border-slate-800">
                <h2 className="font-semibold text-slate-900 dark:text-white">
                  Live Preview
                </h2>

                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Preview how the category will appear.
                </p>
              </div>

              <div className="p-6">
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-700 dark:bg-slate-950">
                  <div className="mb-5 flex items-start justify-between">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-100 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
                      <Tag size={22} />
                    </div>

                    <span
                      className={`rounded-full px-3 py-1 text-xs font-semibold ${
                        formData.status === "Active"
                          ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400"
                          : "bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                      }`}>
                      {formData.status}
                    </span>
                  </div>

                  <h3 className="break-words text-lg font-bold text-slate-900 dark:text-white">
                    {formData.name || "Category Name"}
                  </h3>

                  <p className="mt-2 min-h-[72px] text-sm leading-6 text-slate-500 dark:text-slate-400">
                    {formData.description ||
                      "Category description will appear here."}
                  </p>

                  <div className="mt-5 flex items-center justify-between border-t border-slate-200 pt-4 dark:border-slate-800">
                    <span className="text-xs text-slate-400">Products</span>

                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                      124
                    </span>
                  </div>
                </div>

                {/* Info */}
                <div className="mt-5 rounded-xl bg-indigo-50 p-4 dark:bg-indigo-500/10">
                  <p className="text-xs leading-5 text-indigo-700 dark:text-indigo-300">
                    Changes made here are currently part of the frontend demo.
                    Backend persistence can be connected later.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Success message */}
        {saved && (
          <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3 rounded-xl border border-emerald-200 bg-white px-5 py-4 shadow-xl dark:border-emerald-500/20 dark:bg-slate-900">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400">
              <Check size={18} />
            </div>

            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                Category updated
              </p>

              <p className="text-xs text-slate-500 dark:text-slate-400">
                Returning to categories...
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
